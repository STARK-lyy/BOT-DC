import fs from "fs";
import { Client, Collection, GatewayIntentBits, REST, Routes, EmbedBuilder, Partials } from "discord.js";
import dotenv from "dotenv";
dotenv.config();

const OWNER_ID = process.env.OWNER_ID;

// ------------------- Simple Rate Limiter -------------------
class SimpleRateLimiter {
    constructor() {
        this.requests = new Map();
        this.maxRequests = 100;
        this.timeWindow = 10000;
        setInterval(() => this.cleanup(), 60000);
    }
    
    canRequest(key) {
        const now = Date.now();
        if (!this.requests.has(key)) {
            this.requests.set(key, [now]);
            return true;
        }
        const userRequests = this.requests.get(key);
        const recentRequests = userRequests.filter(time => now - time < this.timeWindow);
        if (recentRequests.length < this.maxRequests) {
            recentRequests.push(now);
            this.requests.set(key, recentRequests);
            return true;
        }
        return false;
    }
    
    cleanup() {
        const now = Date.now();
        for (const [key, requests] of this.requests.entries()) {
            const recentRequests = requests.filter(time => now - time < this.timeWindow);
            if (recentRequests.length === 0) {
                this.requests.delete(key);
            }
        }
    }
}

const rateLimiter = new SimpleRateLimiter();

// ------------------- Global Error Handlers -------------------
process.on('unhandledRejection', (error) => {
    console.error('❌ Unhandled Rejection:', error.message || error);
});

process.on('uncaughtException', (error) => {
    console.error('❌ Uncaught Exception:', error.message || error);
});

// ------------------- Client Setup -------------------
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildInvites,
        GatewayIntentBits.GuildPresences
    ],
    partials: [Partials.Channel],
    rest: {
        timeout: 60000,
        retries: 3
    }
});

client.commands = new Collection();
const cooldowns = new Map();

// Discord client error handlers
client.on('error', (error) => {
    console.error('❌ Discord Error:', error.message);
});

client.on('warn', (warning) => {
    console.warn('⚠️ Discord Warning:', warning);
});

client.on('rateLimit', (info) => {
    console.warn('⚠️ Rate Limited:', {
        timeout: info.timeout,
        limit: info.limit,
        method: info.method
    });
});

// ------------------- Ensure JSON -------------------
const dataFiles = {
    autoban: "./data/autoban.json",
    prefixes: "./data/prefixes.json",
    prefixLogs: "./data/prefixLogs.json",
    noPrefix: "./data/noPrefix.json"
};

for (const path of Object.values(dataFiles)) {
    try {
        if (!fs.existsSync(path)) {
            if (path === "./data/noPrefix.json") {
                // Whitelist system: servers and users
                fs.writeFileSync(path, JSON.stringify({ 
                    servers: [],
                    users: []
                }, null, 4));
            } else if (path === "./data/premium.json") {
                fs.writeFileSync(path, JSON.stringify({ users: {}, logChannel: null }, null, 4));
            } else {
                fs.writeFileSync(path, "{}");
            }
        }
    } catch (error) {
        console.error(`❌ Error creating ${path}:`, error.message);
    }
}

// ------------------- No-Prefix Helper Functions -------------------
function readNoPrefixData() {
    try {
        return JSON.parse(fs.readFileSync(dataFiles.noPrefix, "utf-8"));
    } catch (error) {
        return { servers: [], users: [] };
    }
}

function writeNoPrefixData(data) {
    fs.writeFileSync(dataFiles.noPrefix, JSON.stringify(data, null, 4));
}

// Check if server or user has no-prefix access
function hasNoPrefixAccess(guildId, userId) {
    const data = readNoPrefixData();
    return data.servers.includes(guildId) || data.users.includes(userId);
}

// ------------------- Helper Functions -------------------
function getAllFiles(dir, files = []) {
    try {
        if (!fs.existsSync(dir)) return files;
        const items = fs.readdirSync(dir, { withFileTypes: true });
        for (const item of items) {
            const fullPath = `${dir}/${item.name}`;
            if (item.isDirectory()) {
                getAllFiles(fullPath, files);
            } else if (item.name.endsWith(".js")) {
                files.push(fullPath);
            }
        }
    } catch (error) {
        console.error(`❌ Error reading directory ${dir}:`, error.message);
    }
    return files;
}

// ------------------- Load Commands -------------------
const commands = [];
const commandFiles = getAllFiles("./commands");

for (const file of commandFiles) {
    try {
        const command = await import(`./${file}`);
        if (!command.default) continue;
        client.commands.set(command.default.data.name, command.default);
        commands.push(command.default.data.toJSON());
        console.log(`✅ Loaded command: ${file}`);
    } catch (err) {
        console.log(`❌ Failed to load command ${file}: ${err.message}`);
    }
}

// ------------------- Load Events -------------------
const eventFiles = getAllFiles("./events");

for (const file of eventFiles) {
    try {
        const event = await import(`./${file}`);
        if (!event.default) continue;
        if (event.default.once) {
            client.once(event.default.name, (...args) => {
                try {
                    event.default.execute(...args, client);
                } catch (error) {
                    console.error(`❌ Error in event ${event.default.name}:`, error.message);
                }
            });
        } else {
            client.on(event.default.name, (...args) => {
                try {
                    event.default.execute(...args, client);
                } catch (error) {
                    console.error(`❌ Error in event ${event.default.name}:`, error.message);
                }
            });
        }
        console.log(`✅ Loaded event: ${file}`);
    } catch (err) {
        console.log(`❌ Failed to load event ${file}: ${err.message}`);
    }
}

// ------------------- Register Slash Commands -------------------
const rest = new REST({ version: "10" }).setToken(process.env.TOKEN);
(async () => {
    try {
        console.log("✅ Refreshing application (/) commands...");
        await rest.put(
            Routes.applicationCommands(process.env.CLIENT_ID),
            { body: commands }
        );
        console.log("⏳ Commands refreshed successfully!");
    } catch (error) { 
        console.error("❌ Error refreshing commands:", error.message); 
    }
})();

// ------------------- Client Ready -------------------
client.once("ready", async () => {
    console.log(`\n🎉 ${client.user.tag} is online!`);
    console.log(`📊 Serving ${client.guilds.cache.size} servers`);
    console.log(`👥 Cached ${client.users.cache.size} users\n`);

    let fetchedCount = 0;
    for (const guild of client.guilds.cache.values()) {
        try {
            await guild.members.fetch();
            fetchedCount++;
            if (fetchedCount % 10 === 0) {
                await new Promise(resolve => setTimeout(resolve, 2000));
            }
        } catch (error) {
            console.log(`⚠️ Could not fetch members for ${guild.name}`);
        }
    }

    try {
        const autobanData = JSON.parse(fs.readFileSync(dataFiles.autoban));
        for (const guildId in autobanData) {
            if (autobanData[guildId]?.autoban) {
                const guild = client.guilds.cache.get(guildId);
                if (!guild) continue;
                const members = guild.members.cache.filter(m => !m.user.bot).map(m => m.id);
                autobanData[guildId].members = Array.from(new Set([...autobanData[guildId].members, ...members]));
            }
        }
        fs.writeFileSync(dataFiles.autoban, JSON.stringify(autobanData, null, 4));
        console.log("✅ Auto-ban data loaded successfully\n");
    } catch (error) {
        console.error("❌ Error loading auto-ban data:", error.message);
    }
});

// ------------------- Slash Command Handler -------------------
client.on("interactionCreate", async interaction => {
    if (!interaction.isChatInputCommand()) return;
    
    const rateLimitKey = `slash-${interaction.user.id}`;
    if (!rateLimiter.canRequest(rateLimitKey)) {
        return interaction.reply({ 
            content: "⏳ You're doing that too fast! Please slow down.", 
            ephemeral: true 
        }).catch(() => {});
    }
    
    const command = client.commands.get(interaction.commandName);
    if (!command) return;

    const cooldownKey = `${interaction.user.id}-${interaction.commandName}`;
    const cooldownAmount = Math.max((command.cooldown || 2) * 1000, 3000);
    
    if (cooldowns.has(cooldownKey)) {
        const expirationTime = cooldowns.get(cooldownKey);
        const timeLeft = (expirationTime - Date.now()) / 1000;
        
        if (timeLeft > 0) {
            return interaction.reply({
                content: `⏳ Please wait ${timeLeft.toFixed(1)}s before using \`/${interaction.commandName}\` again.`,
                ephemeral: true
            }).catch(() => {});
        }
    }

    cooldowns.set(cooldownKey, Date.now() + cooldownAmount);
    setTimeout(() => cooldowns.delete(cooldownKey), cooldownAmount);

    try {
        await command.execute(interaction, OWNER_ID);
    } catch (error) {
        console.error(`❌ Error in /${interaction.commandName}:`, error.message);
        
        const errorMsg = { content: "❌ An error occurred while executing this command.", ephemeral: true };
        try {
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp(errorMsg);
            } else {
                await interaction.reply(errorMsg);
            }
        } catch (e) {}
    }
});

// ------------------- Prefix + No-Prefix Command Handler -------------------
client.on("messageCreate", async message => {
    if (message.author.bot || !message.guild) return;

    const rateLimitKey = `prefix-${message.author.id}`;
    if (!rateLimiter.canRequest(rateLimitKey)) {
        return;
    }

    try {
        const prefixes = JSON.parse(fs.readFileSync(dataFiles.prefixes));
        const customPrefix = prefixes[message.guild.id];
        const defaultPrefix = process.env.PREFIX || ".";
        
        let usedPrefix = null;
        let commandName = null;
        let args = [];
        
        // Check for prefix command first (ALWAYS WORKS)
        if (customPrefix && message.content.startsWith(customPrefix)) {
            usedPrefix = customPrefix;
            args = message.content.slice(customPrefix.length).trim().split(/ +/);
            commandName = args.shift()?.toLowerCase();
        } else if (message.content.startsWith(defaultPrefix)) {
            usedPrefix = defaultPrefix;
            args = message.content.slice(defaultPrefix.length).trim().split(/ +/);
            commandName = args.shift()?.toLowerCase();
        } 
        // Try no-prefix (ONLY IF WHITELISTED)
        else if (hasNoPrefixAccess(message.guild.id, message.author.id)) {
            const messageParts = message.content.trim().split(/ +/);
            const potentialCommand = messageParts[0]?.toLowerCase();
            
            // Check if it's a valid command
            let testCommand = client.commands.get(potentialCommand);
            if (!testCommand) {
                testCommand = client.commands.find(cmd => 
                    cmd.aliases && cmd.aliases.includes(potentialCommand)
                );
            }
            
            // If valid command
            if (testCommand) {
                commandName = potentialCommand;
                args = messageParts.slice(1);
                usedPrefix = "no-prefix";
            }
        }
        
        if (!commandName) return;
        
        // Get command
        let command = client.commands.get(commandName);
        if (!command) {
            command = client.commands.find(cmd => 
                cmd.aliases && cmd.aliases.includes(commandName)
            );
        }
        
        if (!command || !command.runPrefix) return;

        // Cooldown check
        const now = Date.now();
        const cooldownAmount = Math.max((command.cooldown || 2) * 1000, 3000);
        if (!cooldowns.has(command.data.name)) cooldowns.set(command.data.name, new Map());
        const timestamps = cooldowns.get(command.data.name);

        if (timestamps.has(message.author.id)) {
            const expiration = timestamps.get(message.author.id) + cooldownAmount;
            if (now < expiration) {
                const timeLeft = ((expiration - now) / 1000).toFixed(1);
                return message.reply({ content: `⏳ Cooldown: ${timeLeft}s` })
                    .then(msg => setTimeout(() => msg.delete().catch(() => {}), 10000))
                    .catch(() => {});
            }
        }

        timestamps.set(message.author.id, now);
        setTimeout(() => timestamps.delete(message.author.id), cooldownAmount);

        await command.runPrefix(message, args, client);
    } catch (err) {
        console.error(`❌ Error in command:`, err.message);
        
        try {
            const embed = new EmbedBuilder()
                .setColor("Red")
                .setDescription("❌ Error running command.");
            
            message.reply({ embeds: [embed] })
                .then(msg => setTimeout(() => msg.delete().catch(() => {}), 10000))
                .catch(() => {});
        } catch (e) {}
    }
});

// ------------------- Bot Status -------------------
const statuses = [
    { name: "💖 Protecting your server!", type: 0 },
    { name: "🌸 Watching over everyone!", type: 3 }
];

let statusIndex = 0;
setInterval(() => {
    try {
        if (client.user) {
            const status = statuses[statusIndex];
            client.user.setPresence({ 
                activities: [{ name: `${status.name} | ${client.guilds.cache.size} servers`, type: status.type }], 
                status: "dnd" 
            });
            statusIndex = (statusIndex + 1) % statuses.length;
        }
    } catch (error) {
        console.error("❌ Error updating status:", error.message);
    }
}, 15000);

// ------------------- Auto Restart -------------------
let reconnectAttempts = 0;
const maxReconnectAttempts = 5;

client.on('disconnect', () => {
    console.warn('⚠️ Bot disconnected from Discord');
});

client.on('reconnecting', () => {
    reconnectAttempts++;
    console.log(`🔄 Reconnecting... (Attempt ${reconnectAttempts}/${maxReconnectAttempts})`);
});

client.on('resume', () => {
    console.log('✅ Connection resumed successfully');
    reconnectAttempts = 0;
});

// ------------------- Memory Monitoring -------------------
setInterval(() => {
    const memUsage = process.memoryUsage();
    const memMB = Math.round(memUsage.heapUsed / 1024 / 1024);
    
    if (memMB > 450) {
        console.warn(`⚠️ High memory usage: ${memMB}MB`);
        if (global.gc) {
            try {
                global.gc();
                console.log('🧹 Garbage collection executed');
            } catch (e) {}
        }
    }
}, 5 * 60 * 1000);

// ------------------- Periodic Stats -------------------
setInterval(() => {
    console.log('\n📊 Bot Stats:');
    console.log(`   Servers: ${client.guilds.cache.size}`);
    console.log(`   Users: ${client.users.cache.size}`);
    console.log(`   Memory: ${Math.round(process.memoryUsage().heapUsed / 1024 / 1024)}MB`);
    console.log(`   Uptime: ${Math.floor(client.uptime / 3600000)}h ${Math.floor((client.uptime % 3600000) / 60000)}m\n`);
}, 30 * 60 * 1000);

// ------------------- Graceful Shutdown -------------------
process.on('SIGINT', async () => {
    console.log('\n⚠️ Shutting down gracefully...');
    try {
        await client.destroy();
        console.log('✅ Bot disconnected');
        process.exit(0);
    } catch (error) {
        console.error('❌ Error during shutdown:', error.message);
        process.exit(1);
    }
});

process.on('SIGTERM', async () => {
    console.log('\n⚠️ SIGTERM received, shutting down...');
    try {
        await client.destroy();
        process.exit(0);
    } catch (error) {
        process.exit(1);
    }
});

// ------------------- Login -------------------
console.log('🚀 Starting TuZhi Utility Bot...\n');

client.login(process.env.TOKEN).catch(error => {
    console.error('❌ Failed to login:', error.message);
    console.error('💡 Check your bot token in .env file');
    process.exit(1);
});