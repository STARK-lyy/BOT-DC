import {
    SlashCommandBuilder,
    TextDisplayBuilder,
    ContainerBuilder,
    SeparatorBuilder,
    MessageFlags,
    PermissionFlagsBits,
    ChannelType
} from "discord.js";
import { addAIChannel, isAIChannel } from "../../utils/aiHandler.js";

const cooldowns = new Map();

export default {
    data: new SlashCommandBuilder()
        .setName("activate")
        .setDescription("Turn on TuZhi AI in a channel - let the fun begin!")
        .addChannelOption(option =>
            option.setName("channel")
                .setDescription("Select the channel where TuZhi will chat")
                .addChannelTypes(ChannelType.GuildText)
                .setRequired(true)
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    cooldown: 5,

    async execute(interaction) {
        const userId = interaction.user.id;
        const BOT_OWNER_ID = process.env.BOT_OWNER_ID;

        const buildMessageContainer = (title, message, color, emoji) => {
            const header = new TextDisplayBuilder().setContent(`${emoji} **${title}**`);
            const body = new TextDisplayBuilder().setContent(`> ${message}`);
            return new ContainerBuilder()
                .setAccentColor(color)
                .addTextDisplayComponents(header)
                .addSeparatorComponents(new SeparatorBuilder())
                .addTextDisplayComponents(body);
        };

        // Bot Owner Check - SABSE PEHLE!
        if (userId !== BOT_OWNER_ID) {
            const ownerOnlyContainer = buildMessageContainer(
                "Access Denied",
                `⚠️ This command is **restricted** to the bot owner only!`,
                0xFF0000,
                "🔒"
            );

            const reply = await interaction.reply({
                components: [ownerOnlyContainer],
                flags: MessageFlags.IsComponentsV2
            });

            setTimeout(() => reply.delete().catch(() => {}), 10000);
            return;
        }

        // Cooldown check
        if (cooldowns.has(userId)) {
            const expirationTime = cooldowns.get(userId);
            const timeLeft = (expirationTime - Date.now()) / 1000;

            if (timeLeft > 0) {
                const cooldownContainer = buildMessageContainer(
                    "Hold On!",
                    `Please wait, you can use this command again <t:${Math.floor(expirationTime / 1000)}:R>`,
                    0xFFA500,
                    "⏰"
                );

                const reply = await interaction.reply({
                    components: [cooldownContainer],
                    flags: MessageFlags.IsComponentsV2
                });

                setTimeout(() => reply.delete().catch(() => {}), 8000);
                return;
            }
        }

        cooldowns.set(userId, Date.now() + 5000);
        setTimeout(() => cooldowns.delete(userId), 5000);

        const channel = interaction.options.getChannel("channel");
        
        if (!channel || channel.type !== ChannelType.GuildText) {
            const errorContainer = buildMessageContainer(
                "Invalid Channel",
                "Please select a valid text channel!",
                0xFF6B6B,
                "❌"
            );

            const reply = await interaction.reply({
                components: [errorContainer],
                flags: MessageFlags.IsComponentsV2
            });

            setTimeout(() => reply.delete().catch(() => {}), 8000);
            return;
        }

        // Check if already enabled
        if (isAIChannel(channel.id)) {
            const warnContainer = buildMessageContainer(
                "Already Active",
                `TuZhi AI is already active in <#${channel.id}>!`,
                0xFF000,
                "✨"
            );

            const reply = await interaction.reply({
                components: [warnContainer],
                flags: MessageFlags.IsComponentsV2
            });

            setTimeout(() => reply.delete().catch(() => {}), 8000);
            return;
        }

        // Add channel
        addAIChannel(channel.id);

        // Success message
        const header = new TextDisplayBuilder().setContent(
            `🎉 **TuZhi AI Successfully Activated!**`
        );

        const body = new TextDisplayBuilder().setContent(
            `> **Hello, I can talk to you on this channel** <#${channel.id}>\n`
        );

        const container = new ContainerBuilder()
            .setAccentColor(0xfe8200)
            .addTextDisplayComponents(header)
            .addSeparatorComponents(new SeparatorBuilder())
            .addTextDisplayComponents(body)

        await interaction.reply({
            components: [container],
            flags: MessageFlags.IsComponentsV2
        });
    }
};