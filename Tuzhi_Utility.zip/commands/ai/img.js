import {
    SlashCommandBuilder,
    TextDisplayBuilder,
    ContainerBuilder,
    SeparatorBuilder,
    MediaGalleryBuilder,
    AttachmentBuilder,
    MessageFlags
} from "discord.js";
import axios from "axios";

const cooldowns = new Map();

// Image generation styles
const CATEGORIES = {
    realistic: "realistic, photo, high quality, detailed, 4k, professional photography",
    anime: "anime style, manga, japanese animation, vibrant colors",
    fantasy: "fantasy art, magical, mystical, enchanted, epic",
    scifi: "sci-fi, futuristic, cyberpunk, neon, technological",
    abstract: "abstract art, artistic, creative, modern art",
    digital: "digital art, modern, clean, vector art, illustration"
};

export default {
    data: new SlashCommandBuilder()
        .setName("img")
        .setDescription("Generate awesome AI images - just describe what you want!")
        .addStringOption(option =>
            option
                .setName("prompt")
                .setDescription("Describe the image you want in detail")
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName("style")
                .setDescription("Choose your preferred art style")
                .setRequired(true)
                .addChoices(
                    { name: "📸 Realistic - Like a real photo", value: "realistic" },
                    { name: "🎌 Anime - Japanese anime style", value: "anime" },
                    { name: "🧙 Fantasy - Magical & mystical", value: "fantasy" },
                    { name: "🚀 Sci-Fi - Futuristic & cool", value: "scifi" },
                    { name: "🌈 Abstract - Creative art", value: "abstract" },
                    { name: "💻 Digital Art - Modern illustration", value: "digital" }
                )
        ),

    cooldown: 10,

    async execute(interaction) {
        const userId = interaction.user.id;
        const prompt = interaction.options.getString("prompt");
        const style = interaction.options.getString("style");

        const buildMessageContainer = (title, message, color, emoji) => {
            const header = new TextDisplayBuilder().setContent(`${emoji} **${title}**`);
            const body = new TextDisplayBuilder().setContent(`> ${message}`);
            return new ContainerBuilder()
                .setAccentColor(color)
                .addTextDisplayComponents(header)
                .addSeparatorComponents(new SeparatorBuilder())
                .addTextDisplayComponents(body);
        };

        // Cooldown check
        if (cooldowns.has(userId)) {
            const expirationTime = cooldowns.get(userId);
            const timeLeft = (expirationTime - Date.now()) / 1000;

            if (timeLeft > 0) {
                const cooldownContainer = buildMessageContainer(
                    "Please Be Patient",
                    `Image generation takes time!\nYou can create another image <t:${Math.floor(expirationTime / 1000)}:R>`,
                    0xFF0000,
                    "⏳"
                );

                const reply = await interaction.reply({
                    components: [cooldownContainer],
                    flags: MessageFlags.IsComponentsV2
                });

                setTimeout(() => reply.delete().catch(() => {}), 10000);
                return;
            }
        }

        cooldowns.set(userId, Date.now() + 10000); // 10 second cooldown
        setTimeout(() => cooldowns.delete(userId), 10000);

        // Processing message
        const processingContainer = buildMessageContainer(
            "Creating Your Image",
            `🎨 Your **${style}** style image is being generated...\n\nThis might take 10-30 seconds. Please wait!`,
            0xfe8200,
            "⚡"
        );

        await interaction.reply({
            components: [processingContainer],
            flags: MessageFlags.IsComponentsV2
        });

        try {
            // Build enhanced prompt
            const categoryStyle = CATEGORIES[style] || "";
            const enhancedPrompt = `${prompt}, ${categoryStyle}`;

            // Generate image URL
            const imageUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(enhancedPrompt)}?width=1024&height=1024&seed=${Date.now()}&nologo=true&enhance=true`;

            // Fetch image
            const response = await axios.get(imageUrl, {
                responseType: 'arraybuffer',
                timeout: 35000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });

            if (!response.data) {
                throw new Error("Failed to generate image");
            }
            
            const imageBuffer = Buffer.from(response.data);
            const attachment = new AttachmentBuilder(imageBuffer, { name: 'tuzhi-generated.png' });

            // Success response
            const header = new TextDisplayBuilder().setContent(
                `🎨 **Image Generated Successfully!**`
            );

            const promptInfo = new TextDisplayBuilder().setContent(
                `**Your Prompt:** ${prompt.substring(0, 100)}${prompt.length > 100 ? '...' : ''}\n` +
                `**Style:** ${style.charAt(0).toUpperCase() + style.slice(1)}\n` +
                `**Created by:** ${interaction.user.username}`
            );

            const mediaGallery = new MediaGalleryBuilder().addItems(
                (item) => item
                    .setURL('attachment://tuzhi-generated.png')
                    .setDescription(`AI Generated: ${prompt.substring(0, 80)}`)
            );


            const container = new ContainerBuilder()
                .setAccentColor(0xfe8200)
                .addTextDisplayComponents(header)
                .addSeparatorComponents(new SeparatorBuilder())
                .addTextDisplayComponents(promptInfo)
                .addSeparatorComponents(new SeparatorBuilder())
                .addMediaGalleryComponents(mediaGallery)
                .addSeparatorComponents(new SeparatorBuilder())

            await interaction.editReply({
                components: [container],
                files: [attachment],
                flags: MessageFlags.IsComponentsV2
            });

        } catch (error) {
            console.error("Image generation error:", error);

            const errorContainer = buildMessageContainer(
                "Generation Failed",
                `Something went wrong while creating your image!\n\n**Possible Reasons:**\n> • Server is busy\n> • Network issue occurred\n> • Prompt may have issues\n\n**Solution:** Wait a moment and try again!`,
                0xFF6B6B,
                "❌"
            );

            await interaction.editReply({
                components: [errorContainer],
                flags: MessageFlags.IsComponentsV2
            });
        }
    }
};