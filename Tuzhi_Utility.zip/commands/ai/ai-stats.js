// ============================================
// commands/ai/ai-stats.js - AI System Statistics Command
// ============================================

import {
    SlashCommandBuilder,
    TextDisplayBuilder,
    ContainerBuilder,
    SeparatorBuilder,
    MessageFlags,
    PermissionFlagsBits
} from "discord.js";
import { getAPIStats } from "../../utils/aiHandler.js";
import fs from "fs";

const ORANGE_COLOR = 0xFE8200;

export default {
    data: new SlashCommandBuilder()
        .setName("ai-stats")
        .setDescription("View TuZhi AI system statistics (Admin only)")
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    cooldown: 10,

    async execute(interaction) {
        try {
            // Permission check
            if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
                const warnContainer = new ContainerBuilder()
                    .setAccentColor(ORANGE_COLOR)
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`🚫 **Permission Denied**`)
                    )
                    .addSeparatorComponents(new SeparatorBuilder())
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`> Only administrators can view AI stats.`)
                    );

                await interaction.reply({
                    components: [warnContainer],
                    flags: MessageFlags.IsComponentsV2
                });
                return;
            }

            // Get API stats
            const apiStats = getAPIStats();
            
            // Read memory data
            let totalUsers = 0;
            let totalContexts = 0;
            try {
                const memoryData = JSON.parse(fs.readFileSync("./data/ai/memory.json", "utf-8"));
                Object.values(memoryData.servers || {}).forEach(server => {
                    const users = Object.values(server.users || {});
                    totalUsers += users.length;
                    users.forEach(user => {
                        totalContexts += user.context?.length || 0;
                    });
                });
            } catch (error) {
                console.error("Error reading memory data:", error.message);
            }

            // Read active channels
            let activeChannels = 0;
            try {
                const channelsData = JSON.parse(fs.readFileSync("./data/ai/ai_channels.json", "utf-8"));
                activeChannels = channelsData.channels?.length || 0;
            } catch (error) {
                console.error("Error reading channels data:", error.message);
            }

            // Build stats message
            const header = new TextDisplayBuilder().setContent(
                `📊 **TuZhi AI System Statistics**`
            );

            let apiStatusText = `> 🔌 **Dual API System Status:**\n`;
            apiStats.forEach((api, index) => {
                const status = api.blocked ? '🔴 Blocked' : api.available ? '🟢 Available' : '🟡 Limited';
                apiStatusText += `> **${api.name} API:** ${status} (${api.requests}/60 requests/min)\n`;
            });

            const body = new TextDisplayBuilder().setContent(
                apiStatusText +
                `> \n` +
                `> 💬 **Usage Statistics:**\n` +
                `> • Active Channels: **${activeChannels}**\n` +
                `> • Total Users: **${totalUsers}**\n` +
                `> • Stored Contexts: **${totalContexts}**\n` +
                `> \n` +
                `> ⚙️ **System Health:**\n` +
                `> • Cooldown: **3 seconds**\n` +
                `> • Max Context: **15 messages**\n` +
                `> • Auto-failover: **Enabled**\n` +
                `> • Rate limit protection: **Active**`
            );

            const footer = new TextDisplayBuilder().setContent(
                `**Requested by:** ${interaction.user.username} • Updated in real-time ⚡`
            );

            const container = new ContainerBuilder()
                .setAccentColor(ORANGE_COLOR)
                .addTextDisplayComponents(header)
                .addSeparatorComponents(new SeparatorBuilder())
                .addTextDisplayComponents(body)
                .addSeparatorComponents(new SeparatorBuilder())
                .addTextDisplayComponents(footer);

            await interaction.reply({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });

        } catch (error) {
            console.error("AI stats error:", error);
            
            const errorContainer = new ContainerBuilder()
                .setAccentColor(ORANGE_COLOR)
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`❌ **Error**`)
                )
                .addSeparatorComponents(new SeparatorBuilder())
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`> Failed to load statistics.`)
                );

            await interaction.reply({
                components: [errorContainer],
                flags: MessageFlags.IsComponentsV2
            });
        }
    }
};