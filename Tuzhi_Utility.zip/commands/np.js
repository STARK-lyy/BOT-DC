import { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle, ComponentType } from "discord.js";
import fs from "fs";

const NO_PREFIX_FILE = "./data/noPrefix.json";

function readNoPrefixData() {
    try {
        return JSON.parse(fs.readFileSync(NO_PREFIX_FILE, "utf-8"));
    } catch (error) {
        return { servers: [], users: [] };
    }
}

function writeNoPrefixData(data) {
    fs.writeFileSync(NO_PREFIX_FILE, JSON.stringify(data, null, 4));
}

export default {
    data: new SlashCommandBuilder()
        .setName("np")
        .setDescription("Manage no-prefix system (Owner Only)")
        .addSubcommand(subcommand =>
            subcommand
                .setName("add")
                .setDescription("Grant no-prefix access")
                .addStringOption(option =>
                    option.setName("type")
                        .setDescription("Server or User")
                        .setRequired(true)
                        .addChoices(
                            { name: "Server", value: "server" },
                            { name: "User", value: "user" }
                        ))
                .addStringOption(option =>
                    option.setName("id")
                        .setDescription("Server ID or mention user")
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName("remove")
                .setDescription("Revoke no-prefix access")
                .addStringOption(option =>
                    option.setName("type")
                        .setDescription("Server or User")
                        .setRequired(true)
                        .addChoices(
                            { name: "Server", value: "server" },
                            { name: "User", value: "user" }
                        ))
                .addStringOption(option =>
                    option.setName("id")
                        .setDescription("Server ID or mention user")
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName("list")
                .setDescription("View all no-prefix access")),

    aliases: ["noprefix"],

    async execute(interaction, OWNER_ID) {
        // Owner check
        if (interaction.user.id !== OWNER_ID) {
            return interaction.reply({
                content: "❌ This command can only be used by the bot owner!",
                ephemeral: true
            });
        }

        const subcommand = interaction.options.getSubcommand();

        if (subcommand === "add") {
            return handleAdd(interaction);
        } else if (subcommand === "remove") {
            return handleRemove(interaction);
        } else if (subcommand === "list") {
            return handleList(interaction);
        }
    },

    async runPrefix(message, args, client) {
        // Owner check
        if (message.author.id !== process.env.OWNER_ID) {
            return message.reply("❌ This command can only be used by the bot owner!");
        }

        const subCommand = args[0]?.toLowerCase();

        if (!subCommand || !['add', 'list', 'remove'].includes(subCommand)) {
            const embed = new EmbedBuilder()
                .setColor("#5865F2")
                .setTitle("📋 No-Prefix System")
                .setDescription("Manage no-prefix access for servers and users")
                .addFields(
                    { name: "📌 Commands", value: "`np add` - Grant no-prefix access\n`np remove` - Revoke no-prefix access\n`np list` - View all access" }
                );
            return message.reply({ embeds: [embed] });
        }

        if (subCommand === 'add') {
            return handleAddPrefix(message, args, client);
        } else if (subCommand === 'list') {
            return handleListPrefix(message, client);
        } else if (subCommand === 'remove') {
            return handleRemovePrefix(message, args, client);
        }
    }
};

// ===== SLASH COMMAND HANDLERS =====

async function handleAdd(interaction) {
    const type = interaction.options.getString("type");
    let id = interaction.options.getString("id");

    const data = readNoPrefixData();

    if (type === "server") {
        // If no ID provided, use current server
        if (!id) {
            id = interaction.guildId;
        }

        // Verify server exists
        const guild = interaction.client.guilds.cache.get(id);
        if (!guild) {
            return interaction.reply({
                content: "❌ Server not found! Make sure the bot is in that server.",
                ephemeral: true
            });
        }

        if (data.servers.includes(id)) {
            return interaction.reply({
                content: `⚠️ **${guild.name}** already has no-prefix access!`,
                ephemeral: true
            });
        }

        data.servers.push(id);
        writeNoPrefixData(data);

        const embed = new EmbedBuilder()
            .setColor("#00ff00")
            .setTitle("✅ Server Added")
            .setDescription(`**Server:** ${guild.name}\n**ID:** \`${id}\`\n\n**Effect:**\nAll users in this server can now use commands without prefix!`)
            .setThumbnail(guild.iconURL({ dynamic: true }))
            .setFooter({ text: `Total whitelisted servers: ${data.servers.length}` })
            .setTimestamp();

        return interaction.reply({ embeds: [embed] });

    } else if (type === "user") {
        // Check for mentioned user or ID
        let user = interaction.options.getUser("id") || interaction.options.getMember("id")?.user;
        
        if (!user && id) {
            try {
                user = await interaction.client.users.fetch(id);
            } catch (error) {
                return interaction.reply({
                    content: "❌ User not found! Provide a valid user ID or mention.",
                    ephemeral: true
                });
            }
        }

        if (!user) {
            return interaction.reply({
                content: "❌ Please provide a user ID or mention a user!",
                ephemeral: true
            });
        }

        if (user.bot) {
            return interaction.reply({
                content: "❌ You cannot grant no-prefix access to bots!",
                ephemeral: true
            });
        }

        if (data.users.includes(user.id)) {
            return interaction.reply({
                content: `⚠️ **${user.tag}** already has no-prefix access!`,
                ephemeral: true
            });
        }

        data.users.push(user.id);
        writeNoPrefixData(data);

        const embed = new EmbedBuilder()
            .setColor("#00ff00")
            .setTitle("✅ User Added")
            .setDescription(`**User:** ${user.tag}\n**ID:** \`${user.id}\`\n\n**Effect:**\nThis user can now use commands without prefix in all servers!`)
            .setThumbnail(user.displayAvatarURL({ dynamic: true }))
            .setFooter({ text: `Total whitelisted users: ${data.users.length}` })
            .setTimestamp();

        return interaction.reply({ embeds: [embed] });
    }
}

async function handleRemove(interaction) {
    const type = interaction.options.getString("type");
    let id = interaction.options.getString("id");

    const data = readNoPrefixData();

    if (type === "server") {
        if (!id) {
            id = interaction.guildId;
        }

        if (!data.servers.includes(id)) {
            return interaction.reply({
                content: "⚠️ This server does not have no-prefix access!",
                ephemeral: true
            });
        }

        data.servers = data.servers.filter(s => s !== id);
        writeNoPrefixData(data);

        const embed = new EmbedBuilder()
            .setColor("#ff0000")
            .setTitle("❌ Server Removed")
            .setDescription(`**Server ID:** \`${id}\`\n\nThis server no longer has no-prefix access.`)
            .setFooter({ text: `Total whitelisted servers: ${data.servers.length}` })
            .setTimestamp();

        return interaction.reply({ embeds: [embed] });

    } else if (type === "user") {
        let user = interaction.options.getUser("id") || interaction.options.getMember("id")?.user;
        
        if (!user && id) {
            try {
                user = await interaction.client.users.fetch(id);
            } catch (error) {
                return interaction.reply({
                    content: "❌ User not found!",
                    ephemeral: true
                });
            }
        }

        if (!user) {
            return interaction.reply({
                content: "❌ Please provide a user ID or mention a user!",
                ephemeral: true
            });
        }

        if (!data.users.includes(user.id)) {
            return interaction.reply({
                content: `⚠️ **${user.tag}** does not have no-prefix access!`,
                ephemeral: true
            });
        }

        data.users = data.users.filter(u => u !== user.id);
        writeNoPrefixData(data);

        const embed = new EmbedBuilder()
            .setColor("#ff0000")
            .setTitle("❌ User Removed")
            .setDescription(`**User:** ${user.tag}\n**ID:** \`${user.id}\`\n\nThis user no longer has no-prefix access.`)
            .setFooter({ text: `Total whitelisted users: ${data.users.length}` })
            .setTimestamp();

        return interaction.reply({ embeds: [embed] });
    }
}

async function handleList(interaction) {
    const data = readNoPrefixData();

    const createPage = async (page = 1, type = 'servers') => {
        const itemsPerPage = 5;
        const items = type === 'servers' ? data.servers : data.users;
        const totalPages = Math.ceil(items.length / itemsPerPage) || 1;
        page = Math.max(1, Math.min(page, totalPages));

        const start = (page - 1) * itemsPerPage;
        const end = start + itemsPerPage;
        const currentItems = items.slice(start, end);

        const embed = new EmbedBuilder()
            .setColor("#5865F2")
            .setTitle(`📋 No-Prefix ${type === 'servers' ? 'Servers' : 'Users'}`)
            .setDescription(`Viewing ${type === 'servers' ? 'whitelisted servers' : 'whitelisted users'}`)
            .setTimestamp();

        if (currentItems.length === 0) {
            embed.addFields({ name: `No ${type} whitelisted`, value: `Use \`/np add\` to add ${type}` });
        } else {
            for (let i = 0; i < currentItems.length; i++) {
                const item = currentItems[i];
                
                if (type === 'servers') {
                    const guild = interaction.client.guilds.cache.get(item);
                    if (guild) {
                        embed.addFields({
                            name: `${start + i + 1}. ${guild.name}`,
                            value: `**ID:** \`${item}\`\n**Members:** ${guild.memberCount}\n**Created:** <t:${Math.floor(guild.createdTimestamp / 1000)}:R>`,
                            inline: false
                        });
                    } else {
                        embed.addFields({
                            name: `${start + i + 1}. Unknown Server`,
                            value: `**ID:** \`${item}\``,
                            inline: false
                        });
                    }
                } else {
                    try {
                        const user = await interaction.client.users.fetch(item);
                        embed.addFields({
                            name: `${start + i + 1}. ${user.tag}`,
                            value: `**ID:** \`${item}\`\n**Account:** <t:${Math.floor(user.createdTimestamp / 1000)}:R>`,
                            inline: false
                        });
                    } catch (error) {
                        embed.addFields({
                            name: `${start + i + 1}. Unknown User`,
                            value: `**ID:** \`${item}\``,
                            inline: false
                        });
                    }
                }
            }

            embed.setFooter({ text: `Page ${page}/${totalPages} • Total: ${items.length}` });
        }

        // Buttons
        const buttons = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId(`np_prev_${page}_${type}`)
                .setLabel('◀ Previous')
                .setStyle(ButtonStyle.Secondary)
                .setDisabled(page === 1),
            new ButtonBuilder()
                .setCustomId(`np_next_${page}_${type}`)
                .setLabel('Next ▶')
                .setStyle(ButtonStyle.Secondary)
                .setDisabled(page === totalPages),
            new ButtonBuilder()
                .setCustomId(`np_switch_${page}_${type}`)
                .setLabel(type === 'servers' ? '👥 View Users' : '🏠 View Servers')
                .setStyle(ButtonStyle.Primary)
        );

        return { embeds: [embed], components: [buttons] };
    };

    const response = await interaction.reply({ ...(await createPage(1, 'servers')), fetchReply: true });

    const collector = response.createMessageComponentCollector({ componentType: ComponentType.Button, time: 300000 });

    collector.on('collect', async (i) => {
        if (i.user.id !== interaction.user.id) {
            return i.reply({ content: "Only the command user can navigate!", ephemeral: true });
        }

        const [, action, pageStr, type] = i.customId.split('_');
        let page = parseInt(pageStr);

        if (action === 'prev') {
            page = Math.max(1, page - 1);
        } else if (action === 'next') {
            page = page + 1;
        } else if (action === 'switch') {
            const newType = type === 'servers' ? 'users' : 'servers';
            return i.update(await createPage(1, newType));
        }

        await i.update(await createPage(page, type));
    });

    collector.on('end', () => {
        response.edit({ components: [] }).catch(() => {});
    });
}

// ===== PREFIX COMMAND HANDLERS =====

async function handleAddPrefix(message, args, client) {
    const type = args[1]?.toLowerCase();
    
    if (!type || !['server', 'user'].includes(type)) {
        return message.reply("Usage: `np add server` or `np add user @mention`");
    }

    const data = readNoPrefixData();

    if (type === 'server') {
        const serverId = message.guild.id;
        
        if (data.servers.includes(serverId)) {
            return message.reply(`⚠️ **${message.guild.name}** already has no-prefix access!`);
        }

        data.servers.push(serverId);
        writeNoPrefixData(data);

        const embed = new EmbedBuilder()
            .setColor("#00ff00")
            .setTitle("✅ Server Added")
            .setDescription(`**Server:** ${message.guild.name}\n\nAll users can now use commands without prefix!`)
            .setFooter({ text: `Total: ${data.servers.length} servers` });

        return message.reply({ embeds: [embed] });
    } else if (type === 'user') {
        const user = message.mentions.users.first();
        
        if (!user) {
            return message.reply("❌ Please mention a user! Usage: `np add user @user`");
        }

        if (user.bot) {
            return message.reply("❌ Cannot grant no-prefix to bots!");
        }

        if (data.users.includes(user.id)) {
            return message.reply(`⚠️ **${user.tag}** already has no-prefix access!`);
        }

        data.users.push(user.id);
        writeNoPrefixData(data);

        const embed = new EmbedBuilder()
            .setColor("#00ff00")
            .setTitle("✅ User Added")
            .setDescription(`**User:** ${user.tag}\n\nCan use commands without prefix in all servers!`)
            .setFooter({ text: `Total: ${data.users.length} users` });

        return message.reply({ embeds: [embed] });
    }
}

async function handleRemovePrefix(message, args, client) {
    const type = args[1]?.toLowerCase();
    
    if (!type || !['server', 'user'].includes(type)) {
        return message.reply("Usage: `np remove server` or `np remove user @mention`");
    }

    const data = readNoPrefixData();

    if (type === 'server') {
        const serverId = message.guild.id;
        
        if (!data.servers.includes(serverId)) {
            return message.reply("⚠️ This server doesn't have no-prefix access!");
        }

        data.servers = data.servers.filter(s => s !== serverId);
        writeNoPrefixData(data);

        const embed = new EmbedBuilder()
            .setColor("#ff0000")
            .setTitle("❌ Server Removed")
            .setDescription(`**Server:** ${message.guild.name}\n\nNo longer has no-prefix access.`)
            .setFooter({ text: `Total: ${data.servers.length} servers` });

        return message.reply({ embeds: [embed] });
    } else if (type === 'user') {
        const user = message.mentions.users.first();
        
        if (!user) {
            return message.reply("❌ Please mention a user! Usage: `np remove user @user`");
        }

        if (!data.users.includes(user.id)) {
            return message.reply(`⚠️ **${user.tag}** doesn't have no-prefix access!`);
        }

        data.users = data.users.filter(u => u !== user.id);
        writeNoPrefixData(data);

        const embed = new EmbedBuilder()
            .setColor("#ff0000")
            .setTitle("❌ User Removed")
            .setDescription(`**User:** ${user.tag}\n\nNo longer has no-prefix access.`)
            .setFooter({ text: `Total: ${data.users.length} users` });

        return message.reply({ embeds: [embed] });
    }
}

async function handleListPrefix(message, client) {
    const data = readNoPrefixData();

    const embed = new EmbedBuilder()
        .setColor("#5865F2")
        .setTitle("📋 No-Prefix System")
        .setTimestamp();

    // Servers
    if (data.servers.length > 0) {
        const serverList = data.servers.slice(0, 10).map((id, i) => {
            const guild = client.guilds.cache.get(id);
            return guild ? `${i + 1}. ${guild.name} (\`${id}\`)` : `${i + 1}. Unknown (\`${id}\`)`;
        }).join('\n');
        
        embed.addFields({
            name: `🏠 Whitelisted Servers (${data.servers.length})`,
            value: serverList + (data.servers.length > 10 ? `\n... and ${data.servers.length - 10} more` : ''),
            inline: false
        });
    } else {
        embed.addFields({ name: "🏠 Whitelisted Servers", value: "*No servers*", inline: false });
    }

    // Users
    if (data.users.length > 0) {
        const userList = await Promise.all(
            data.users.slice(0, 10).map(async (id, i) => {
                try {
                    const user = await client.users.fetch(id);
                    return `${i + 1}. ${user.tag} (\`${id}\`)`;
                } catch {
                    return `${i + 1}. Unknown (\`${id}\`)`;
                }
            })
        );
        
        embed.addFields({
            name: `👥 Whitelisted Users (${data.users.length})`,
            value: userList.join('\n') + (data.users.length > 10 ? `\n... and ${data.users.length - 10} more` : ''),
            inline: false
        });
    } else {
        embed.addFields({ name: "👥 Whitelisted Users", value: "*No users*", inline: false });
    }

    return message.reply({ embeds: [embed] });
}