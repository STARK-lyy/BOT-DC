import { SlashCommandBuilder, EmbedBuilder } from "discord.js";
import fs from "fs";
import { getPrefixInfo, getLastPrefixChange } from "../../events/prefixLogger.js";
import dotenv from "dotenv";

dotenv.config();

const PREFIXES_FILE = "./data/prefixes.json";

export default {
    data: new SlashCommandBuilder()
        .setName("prefixinfo")
        .setDescription("View the current prefix and change history"),
    
    cooldown: 5, // 5 seconds cooldown
    
    async execute(interaction) {
        // Get current prefix
        const prefixes = JSON.parse(fs.readFileSync(PREFIXES_FILE, "utf-8"));
        const currentPrefix = prefixes[interaction.guildId] || process.env.PREFIX || ".";
        const defaultPrefix = process.env.PREFIX || ".";
        
        // Get prefix info from logs
        const prefixInfo = getPrefixInfo(interaction.guildId);
        const lastChange = getLastPrefixChange(interaction.guildId);
        
        const embed = new EmbedBuilder()
            .setColor("#FF0000")
            .setTitle("📋 Prefix Information")
            .setDescription(`Prefix details for **${interaction.guild.name}**`)
            .addFields(
                { name: "Current Prefix", value: `\`${currentPrefix}\``, inline: true },
                { name: "Default Prefix", value: `\`${defaultPrefix}\``, inline: true },
                { name: "Custom Set", value: currentPrefix !== defaultPrefix ? "✅ Yes" : "❌ No", inline: true }
            )
            .setThumbnail(interaction.guild.iconURL())
            .setTimestamp();

        // Add last change info if exists
        if (lastChange) {
            let setter = "Unknown User";
            try {
                const user = await interaction.client.users.fetch(lastChange.setBy);
                setter = user.tag;
            } catch (e) {
                setter = lastChange.setByName || `User ID: ${lastChange.setBy}`;
            }
            
            embed.addFields({
                name: "📝 Last Changed",
                value: `**By:** ${setter}\n` +
                       `**When:** <t:${Math.floor(lastChange.timestamp / 1000)}:R>\n` +
                       `**Prefix:** \`${lastChange.prefix}\``,
                inline: false
            });
        } else {
            embed.addFields({
                name: "📝 Change History",
                value: "No custom prefix has been set yet.\nUsing default prefix.",
                inline: false
            });
        }

        // Show change history count
        if (prefixInfo && prefixInfo.history && prefixInfo.history.length > 0) {
            embed.addFields({
                name: "📊 Total Changes",
                value: `${prefixInfo.history.length} time${prefixInfo.history.length !== 1 ? 's' : ''}`,
                inline: true
            });
        }

        // Usage instructions
        embed.addFields({
            name: "ℹ️ How to Use",
            value: `• Current prefix: \`${currentPrefix}help\`\n` +
                   `• Default prefix: \`${defaultPrefix}help\`\n` +
                   `• Change prefix: \`/setprefix <new_prefix>\`\n` +
                   `• Both prefixes work simultaneously!`,
            inline: false
        });

        // Success message - DO NOT delete
        await interaction.reply({ embeds: [embed] });
    }
};