import { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } from "discord.js";
import fs from "fs";
import { logPrefixChange } from "../../events/prefixLogger.js";
import dotenv from "dotenv";

dotenv.config();

const PREFIXES_FILE = "./data/prefixes.json";

export default {
    data: new SlashCommandBuilder()
        .setName("setprefix")
        .setDescription("Set a custom prefix for this server (Server Owner/Admin only)")
        .addStringOption(option =>
            option.setName("prefix")
                .setDescription("The new prefix (1-5 characters)")
                .setRequired(true)
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    
    async execute(interaction) {
        // Check if user is server owner or admin
        if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator) && 
            interaction.user.id !== interaction.guild.ownerId) {
            const errorReply = await interaction.reply({
                content: "❌ Only server admins or owner can change the prefix!",
                ephemeral: false
            });
            
            // Delete after 5 seconds
            setTimeout(async () => {
                try {
                    await errorReply.delete();
                } catch (e) {
                    // Ignore if already deleted
                }
            }, 5000);
            
            return;
        }

        const newPrefix = interaction.options.getString("prefix");
        
        // Validate prefix
        if (newPrefix.length > 5) {
            const errorReply = await interaction.reply({
                content: "❌ Prefix must be 1-5 characters long!",
                ephemeral: false
            });
            
            setTimeout(async () => {
                try {
                    await errorReply.delete();
                } catch (e) {}
            }, 5000);
            
            return;
        }
        
        if (newPrefix.includes(" ")) {
            const errorReply = await interaction.reply({
                content: "❌ Prefix cannot contain spaces!",
                ephemeral: false
            });
            
            setTimeout(async () => {
                try {
                    await errorReply.delete();
                } catch (e) {}
            }, 5000);
            
            return;
        }

        // Read current prefixes
        const prefixes = JSON.parse(fs.readFileSync(PREFIXES_FILE, "utf-8"));
        const oldPrefix = prefixes[interaction.guildId] || process.env.PREFIX || ".";
        
        // Update prefix
        prefixes[interaction.guildId] = newPrefix;
        fs.writeFileSync(PREFIXES_FILE, JSON.stringify(prefixes, null, 4));
        
        // Log the change
        const timestamp = Date.now();
        logPrefixChange(
            interaction.guildId,
            interaction.guild.name,
            newPrefix,
            interaction.user.id,
            interaction.user.tag,
            timestamp
        );

        // Success embed
        const embed = new EmbedBuilder()
            .setColor("#FF0000")
            .setTitle("✅ Prefix Updated")
            .setDescription(`Server prefix has been successfully changed!`)
            .addFields(
                { name: "Old Prefix", value: `\`${oldPrefix}\``, inline: true },
                { name: "New Prefix", value: `\`${newPrefix}\``, inline: true },
                { name: "Changed By", value: `${interaction.user}`, inline: false },
                { name: "Changed At", value: `<t:${Math.floor(timestamp / 1000)}:F>`, inline: false }
            )
            .setFooter({ text: `Server: ${interaction.guild.name}` })
            .setTimestamp();

        // Success message - DO NOT delete
        await interaction.reply({ embeds: [embed] });
        
        console.log(`✅ Prefix changed in ${interaction.guild.name}: "${oldPrefix}" → "${newPrefix}" by ${interaction.user.tag}`);
    }
};