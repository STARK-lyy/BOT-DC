import {
    SlashCommandBuilder,
    TextDisplayBuilder,
    ContainerBuilder,
    SeparatorBuilder,
    MediaGalleryBuilder,
    AttachmentBuilder,
    MessageFlags,
    PermissionFlagsBits
} from "discord.js";
import axios from "axios";

export default {
    data: new SlashCommandBuilder()
        .setName("send")
        .setDescription("Send a components v2 message to a channel (Owner Only)")
        .addUserOption(option =>
            option
                .setName("user")
                .setDescription("Select the user to mention/reference")
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName("message")
                .setDescription("The message text to display")
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName("dm")
                .setDescription("Should the user receive a DM?")
                .setRequired(true)
                .addChoices(
                    { name: "Yes - Send DM", value: "yes" },
                    { name: "No - Don't send DM", value: "no" }
                )
        )
        .addChannelOption(option =>
            option
                .setName("channel")
                .setDescription("Select the channel to send the message")
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName("image")
                .setDescription("Image URL to display in the message")
                .setRequired(false)
        ),

    cooldown: 3,

    async execute(interaction, OWNER_ID) {
        // Owner check
        if (interaction.user.id !== OWNER_ID) {
            const deniedContainer = new ContainerBuilder()
                .setAccentColor(0xFF0000)
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent("🔒 **Access Denied**")
                )
                .addSeparatorComponents(new SeparatorBuilder())
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent("> This command can only be used by the bot owner!")
                );

            return interaction.reply({
                components: [deniedContainer],
                flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral
            });
        }

        const targetUser = interaction.options.getUser("user");
        const messageText = interaction.options.getString("message");
        const imageUrl = interaction.options.getString("image");
        const shouldDM = interaction.options.getString("dm");
        const targetChannel = interaction.options.getChannel("channel");

        // Validate channel is in the same server
        if (targetChannel.guildId !== interaction.guildId) {
            const errorContainer = new ContainerBuilder()
                .setAccentColor(0xFF6B6B)
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent("❌ **Invalid Channel**")
                )
                .addSeparatorComponents(new SeparatorBuilder())
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent("> You can only send messages to channels in this server!")
                );

            return interaction.reply({
                components: [errorContainer],
                flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral
            });
        }

        // Check if bot has permission to send messages in that channel
        const botMember = await interaction.guild.members.fetch(interaction.client.user.id);
        const channelPermissions = targetChannel.permissionsFor(botMember);

        if (!channelPermissions.has(PermissionFlagsBits.SendMessages)) {
            const permErrorContainer = new ContainerBuilder()
                .setAccentColor(0xFF6B6B)
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent("❌ **Permission Error**")
                )
                .addSeparatorComponents(new SeparatorBuilder())
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent("> I don't have permission to send messages in that channel!")
                );

            return interaction.reply({
                components: [permErrorContainer],
                flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral
            });
        }

        // Processing message
        const processingContainer = new ContainerBuilder()
            .setAccentColor(0xfe8200)
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent("⚡ **Processing**")
            )
            .addSeparatorComponents(new SeparatorBuilder())
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent("> Preparing to send your message...")
            );

        await interaction.reply({
            components: [processingContainer],
            flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral
        });

        try {
            const header = new TextDisplayBuilder().setContent(
                `📨 **Message for ${targetUser}**`
            );

            const messageContent = new TextDisplayBuilder().setContent(
                `${messageText}`
            );

            const container = new ContainerBuilder()
                .setAccentColor(0xfe8200)
                .addTextDisplayComponents(header)
                .addSeparatorComponents(new SeparatorBuilder())
                .addTextDisplayComponents(messageContent);

            let attachments = [];

            // Handle image if provided
            if (imageUrl) {
                try {
                    // Validate URL
                    new URL(imageUrl);

                    // Try to fetch the image
                    const response = await axios.get(imageUrl, {
                        responseType: 'arraybuffer',
                        timeout: 10000,
                        headers: {
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                        }
                    });

                    const imageBuffer = Buffer.from(response.data);
                    const attachment = new AttachmentBuilder(imageBuffer, { 
                        name: 'message-image.png' 
                    });
                    attachments.push(attachment);

                    // Add media gallery to container
                    const mediaGallery = new MediaGalleryBuilder().addItems(
                        (item) => item
                            .setURL('attachment://message-image.png')
                            .setDescription('Attached Image')
                    );

                    container
                        .addSeparatorComponents(new SeparatorBuilder())
                        .addMediaGalleryComponents(mediaGallery);

                } catch (imgError) {
                    console.error("Image fetch error:", imgError);
                    // Continue without image if fetch fails
                    container
                        .addSeparatorComponents(new SeparatorBuilder())
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent("⚠️ *Image could not be loaded*")
                        );
                }
            }

            // Add footer
            container
                .addSeparatorComponents(new SeparatorBuilder())
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `*<t:${Math.floor(Date.now() / 1000)}:F>*`
                    )
                );

            // Send message to channel
            const sentMessage = await targetChannel.send({
                components: [container],
                files: attachments,
                flags: MessageFlags.IsComponentsV2,
                allowedMentions: { users: [targetUser.id] }
            });

            // Send DM if requested
            let dmStatus = "Not sent";
            if (shouldDM === "yes") {
                try {
                    // Create DM container
                    const dmContainer = new ContainerBuilder()
                        .setAccentColor(0xfe8200)
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`💌 **You have a new message!** ${targetUser}`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder())
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `**Server:** ${interaction.guild.name}\n\n` +
                                `${messageText}`
                            )
                        )
                        .addSeparatorComponents(new SeparatorBuilder())
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `[Jump to Message](${sentMessage.url})`
                            )
                        );

                    // Add image to DM if provided
                    if (imageUrl && attachments.length > 0) {
                        const dmMediaGallery = new MediaGalleryBuilder().addItems(
                            (item) => item
                                .setURL('attachment://message-image.png')
                                .setDescription('Attached Image')
                        );
                        dmContainer
                            .addSeparatorComponents(new SeparatorBuilder())
                            .addMediaGalleryComponents(dmMediaGallery);
                    }

                    // Send DM
                    await targetUser.send({
                        components: [dmContainer],
                        files: attachments,
                        flags: MessageFlags.IsComponentsV2,
                        allowedMentions: { users: [targetUser.id] }
                    });

                    dmStatus = "✅ Sent successfully";
                } catch (dmError) {
                    console.error("DM Error:", dmError);
                    dmStatus = "❌ Failed (User has DMs disabled)";
                }
            } else {
                dmStatus = "⏭️ Skipped";
            }

            // Success response
            const successContainer = new ContainerBuilder()
                .setAccentColor(0x00FF00)
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent("✅ **Message Sent Successfully!**")
                )
                .addSeparatorComponents(new SeparatorBuilder())
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `**Channel:** ${targetChannel}\n` +
                        `**User Mentioned:** ${targetUser.tag}\n` +
                        `**DM Status:** ${dmStatus}\n` +
                        `**Image:** ${imageUrl ? "✅ Included" : "❌ Not provided"}\n\n` +
                        `[Jump to Message](${sentMessage.url})`
                    )
                );

            await interaction.editReply({
                components: [successContainer],
                flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral
            });

        } catch (error) {
            console.error("Send command error:", error);

            const errorContainer = new ContainerBuilder()
                .setAccentColor(0xFF6B6B)
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent("❌ **Failed to Send Message**")
                )
                .addSeparatorComponents(new SeparatorBuilder())
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `> An error occurred while sending the message.\n\n` +
                        `**Error:** ${error.message}`
                    )
                );

            await interaction.editReply({
                components: [errorContainer],
                flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral
            });
        }
    }
};