import { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } from "discord.js";

const cooldowns = new Set();

export default {
    data: new SlashCommandBuilder()
        .setName("clear")
        .setDescription("Clear messages in a channel")
        .addIntegerOption(option =>
            option.setName("amount")
                .setDescription("Number of messages to delete (max 100)")
                .setRequired(true)
                .setMinValue(1)
                .setMaxValue(100)
        )
        .addUserOption(option =>
            option.setName("user")
                .setDescription("Delete messages from a specific user")
                .setRequired(false)
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

    cooldown: 5000, // 5 seconds

    // ---------------- Slash Command ----------------
    async execute(interaction) {
        const amount = interaction.options.getInteger("amount");
        const targetUser = interaction.options.getUser("user");

        // Cooldown check
        if (cooldowns.has(interaction.user.id)) {
            const expireTime = Math.floor((Date.now() + this.cooldown) / 1000); // timestamp for cooldown
            const cooldownEmbed = new EmbedBuilder()
                .setColor("Red")
                .setDescription(`**⏱ | ${interaction.user.username}**! Slow down and try the command again **<t:${expireTime}:R>**`);
            const reply = await interaction.reply({ embeds: [cooldownEmbed], ephemeral: true });
            setTimeout(() => {
                if (reply.deletable) reply.delete().catch(() => {});
            }, 10000); // 10s auto delete
            return;
        }

        cooldowns.add(interaction.user.id);
        setTimeout(() => cooldowns.delete(interaction.user.id), this.cooldown);

        const channel = interaction.channel;
        if (!channel || !channel.isTextBased()) {
            return interaction.reply({ content: "❌ This channel cannot have messages deleted.", ephemeral: true });
        }

        try {
            let messages = await channel.messages.fetch({ limit: amount });
            if (targetUser) messages = messages.filter(msg => msg.author.id === targetUser.id);

            await channel.bulkDelete(messages, true);

            const embed = new EmbedBuilder()
                .setColor("#ff0000")
                .setDescription(`✅ Deleted ${messages.size} message(s)${targetUser ? ` from ${targetUser.username}` : ""}.`);
            
            await interaction.reply({ embeds: [embed] });
        } catch (err) {
            console.error(err);
            interaction.reply({ content: "❌ Could not delete messages. They may be older than 14 days.", ephemeral: true });
        }
    },

    // ---------------- Prefix Command ----------------
    async runPrefix(message, args) {
        if (!message.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
            const expireTime = Math.floor((Date.now() + 5000) / 1000);
            const cooldownEmbed = new EmbedBuilder()
                .setColor("Red")
                .setDescription(`**⏱ | ${message.author.username}**! Slow down and try the command again **<t:${expireTime}:R>**`);
            message.reply({ embeds: [cooldownEmbed] }).then(msg => setTimeout(() => msg.delete().catch(() => {}), 10000));
            return;
        }

        if (!args.length) {
            return message.reply("❌ Provide an amount or user to clear messages.").then(msg => setTimeout(() => msg.delete().catch(() => {}), 10000));
        }

        // Extract user and amount from args
        let targetUser = message.mentions.users.first();
        let amount = parseInt(args.find(a => !isNaN(a)));

        if (!amount) amount = 5; // default 5
        if (amount > 100) amount = 100;

        const channel = message.channel;

        try {
            let messages = await channel.messages.fetch({ limit: amount + 50 }); // fetch extra in case of user filter
            if (targetUser) messages = messages.filter(msg => msg.author.id === targetUser.id).first(amount);
            else messages = messages.first(amount);

            await channel.bulkDelete(messages, true);

            const embed = new EmbedBuilder()
                .setColor("#ff0000")
                .setDescription(`✅ Deleted ${messages.length} message(s)${targetUser ? ` from ${targetUser.username}` : ""}.`);

            message.channel.send({ embeds: [embed] });
        } catch (err) {
            console.error(err);
            const embed = new EmbedBuilder()
                .setColor("Red")
                .setDescription("❌ Could not delete messages. They may be older than 14 days.");
            message.channel.send({ embeds: [embed] });
        }
    }
};