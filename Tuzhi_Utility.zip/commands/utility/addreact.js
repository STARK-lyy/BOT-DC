import { 
    SlashCommandBuilder, 
    PermissionFlagsBits,
    StringSelectMenuBuilder,
    ActionRowBuilder,
    ComponentType,
    MessageFlags,
    TextDisplayBuilder,
    ButtonBuilder,
    ButtonStyle,
    ContainerBuilder,
    SectionBuilder,
    SeparatorBuilder,
    ThumbnailBuilder
} from "discord.js";

export default {
    data: new SlashCommandBuilder()
        .setName("addreact")
        .setDescription("Add a reaction to a message using custom emojis")
        .addStringOption(option =>
            option
                .setName("messageid")
                .setDescription("The ID of the message to react to")
                .setRequired(true)
        )
        .addChannelOption(option =>
            option
                .setName("channel")
                .setDescription("The channel where the message is (defaults to current channel)")
                .setRequired(false)
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    cooldown: 3,

    async execute(interaction) {
        try {
            // Check if user is server owner or has Manage Server permission
            if (interaction.user.id !== interaction.guild.ownerId && 
                !interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
                
                const errorContainer = new ContainerBuilder()
                    .setAccentColor(0xfe8200)
                    .addTextDisplayComponents((textDisplay) =>
                        textDisplay.setContent("❌ **Permission Denied**\n\nOnly server owner or users with `Manage Server` permission can use this command!")
                    );

                const warningMsg = await interaction.reply({
                    components: [errorContainer],
                    flags: MessageFlags.IsComponentsV2,
                    fetchReply: true
                });

                setTimeout(() => {
                    warningMsg.delete().catch(() => {});
                }, 10000);

                return;
            }

            const messageId = interaction.options.getString("messageid");
            const targetChannel = interaction.options.getChannel("channel") || interaction.channel;

            let targetMessage;
            try {
                targetMessage = await targetChannel.messages.fetch(messageId);
            } catch (error) {
                const errorContainer = new ContainerBuilder()
                    .setAccentColor(0xfe8200)
                    .addTextDisplayComponents((textDisplay) =>
                        textDisplay.setContent("❌ **Message not found!**\n\nMake sure the message ID is correct and in the specified channel.")
                    );

                const warningMsg = await interaction.reply({
                    components: [errorContainer],
                    flags: MessageFlags.IsComponentsV2,
                    fetchReply: true
                });

                setTimeout(() => {
                    warningMsg.delete().catch(() => {});
                }, 10000);

                return;
            }

            const customEmojis = interaction.guild.emojis.cache;

            if (customEmojis.size === 0) {
                const errorContainer = new ContainerBuilder()
                    .setAccentColor(0xfe8200)
                    .addTextDisplayComponents((textDisplay) =>
                        textDisplay.setContent("❌ **No Custom Emojis**\n\nThis server doesn't have any custom emojis!")
                    );

                const warningMsg = await interaction.reply({
                    components: [errorContainer],
                    flags: MessageFlags.IsComponentsV2,
                    fetchReply: true
                });

                setTimeout(() => {
                    warningMsg.delete().catch(() => {});
                }, 10000);

                return;
            }

            // Get up to 25 emojis
            const emojiOptions = customEmojis.map(emoji => ({
                label: emoji.name,
                value: emoji.id,
                emoji: emoji.id,
                description: `${emoji.animated ? 'Animated' : 'Static'} emoji`
            })).slice(0, 25);

            const selectMenu = new StringSelectMenuBuilder()
                .setCustomId("emoji_select")
                .setPlaceholder("Select an emoji to react with")
                .addOptions(emojiOptions);

            const selectRow = new ActionRowBuilder().addComponents(selectMenu);

            const supportButton = new ButtonBuilder()
                .setLabel("Support")
                .setStyle(ButtonStyle.Link)
                .setURL("https://discord.gg/t8DHmYvX6Q");

            const removeButton = new ButtonBuilder()
                .setCustomId("remove_message")
                .setLabel("Remove")
                .setStyle(ButtonStyle.Danger);

            const buttonRow = new ActionRowBuilder().addComponents(supportButton, removeButton);

            // Get first emoji for thumbnail
            const firstEmoji = customEmojis.first();
            const emojiUrl = firstEmoji.url;

            // Create main container with emoji thumbnail
            const mainSection = new SectionBuilder()
                .addTextDisplayComponents(
                    (textDisplay) => textDisplay.setContent("🎭 **Select Emoji**\n\nSelect a custom emoji to react to the message"),
                    (textDisplay) => textDisplay.setContent(`**Message ID:** \`${messageId}\`\n**Channel:** ${targetChannel}`),
                    (textDisplay) => textDisplay.setContent(`${customEmojis.size} custom emojis available • [Jump to Message](${targetMessage.url})`)
                )
                .setThumbnailAccessory((thumbnail) => 
                    thumbnail.setURL(emojiUrl).setDescription("Server emoji")
                );

            const mainContainer = new ContainerBuilder()
                .setAccentColor(0xfe8200)
                .addSectionComponents((section) => mainSection)
                .addActionRowComponents((actionRow) => selectRow);

            const response = await interaction.reply({
                components: [mainContainer, buttonRow],
                flags: MessageFlags.IsComponentsV2,
                fetchReply: true
            });

            const collector = response.createMessageComponentCollector({
                time: 60000
            });

            collector.on("collect", async i => {
                try {
                    if (i.customId === "remove_message") {
                        if (i.user.id !== interaction.user.id) {
                            return i.reply({
                                content: "❌ Only the command user can remove this message!",
                                ephemeral: true
                            });
                        }

                        await i.deferUpdate();
                        await response.delete().catch(() => {});
                        collector.stop();
                        return;
                    }

                    if (i.customId === "emoji_select") {
                        if (i.user.id !== interaction.user.id) {
                            return i.reply({
                                content: "❌ Only the command user can select emojis!",
                                ephemeral: true
                            });
                        }

                        await i.deferUpdate();

                        const emojiId = i.values[0];
                        const selectedEmoji = customEmojis.get(emojiId);

                        if (!selectedEmoji) {
                            const errorContainer = new ContainerBuilder()
                                .setAccentColor(0xfe8200)
                                .addTextDisplayComponents((textDisplay) =>
                                    textDisplay.setContent("❌ **Emoji not found!**")
                                );

                            const warningMsg = await i.followUp({
                                components: [errorContainer],
                                flags: MessageFlags.IsComponentsV2,
                                fetchReply: true
                            });

                            setTimeout(() => {
                                warningMsg.delete().catch(() => {});
                            }, 10000);

                            return;
                        }

                        try {
                            await targetMessage.react(selectedEmoji);

                            // Success message with emoji thumbnail
                            const successSection = new SectionBuilder()
                                .addTextDisplayComponents(
                                    (textDisplay) => textDisplay.setContent(`✅ **Reaction Added Successfully!**`),
                                    (textDisplay) => textDisplay.setContent(`**Emoji:** ${selectedEmoji} (\`${selectedEmoji.name}\`)`),
                                    (textDisplay) => textDisplay.setContent(`Added by ${interaction.user} • [Jump to Message](${targetMessage.url})`)
                                )
                                .setThumbnailAccessory((thumbnail) => 
                                    thumbnail.setURL(selectedEmoji.url).setDescription(selectedEmoji.name)
                                );

                            const successContainer = new ContainerBuilder()
                                .setAccentColor(0xfe8200)
                                .addSectionComponents((section) => successSection);

                            // Remove button still available
                            const newRemoveButton = new ButtonBuilder()
                                .setCustomId("remove_success")
                                .setLabel("Remove")
                                .setStyle(ButtonStyle.Danger);

                            const newButtonRow = new ActionRowBuilder().addComponents(supportButton, newRemoveButton);

                            await response.edit({
                                components: [successContainer, newButtonRow],
                                flags: MessageFlags.IsComponentsV2
                            });

                            // Update collector to handle new remove button
                            const newCollector = response.createMessageComponentCollector({
                                time: 300000 // 5 minutes
                            });

                            newCollector.on("collect", async btnInteraction => {
                                if (btnInteraction.customId === "remove_success") {
                                    if (btnInteraction.user.id !== interaction.user.id) {
                                        return btnInteraction.reply({
                                            content: "❌ Only the command user can remove this message!",
                                            ephemeral: true
                                        });
                                    }

                                    await btnInteraction.deferUpdate();
                                    await response.delete().catch(() => {});
                                    newCollector.stop();
                                }
                            });

                            collector.stop();
                        } catch (error) {
                            console.error("Error adding reaction:", error);
                            
                            const errorContainer = new ContainerBuilder()
                                .setAccentColor(0xfe8200)
                                .addTextDisplayComponents((textDisplay) =>
                                    textDisplay.setContent("❌ **Failed to Add Reaction**\n\nI couldn't add the reaction. This might be because:\n\n• I don't have permission to add reactions\n• The emoji is from another server\n• The message is too old")
                                );

                            const warningMsg = await response.edit({
                                components: [errorContainer],
                                flags: MessageFlags.IsComponentsV2
                            });

                            setTimeout(() => {
                                warningMsg.delete().catch(() => {});
                            }, 10000);
                        }
                    }
                } catch (error) {
                    console.error("Error in collector:", error);
                }
            });

            collector.on("end", (collected, reason) => {
                if (reason === "time" && !collected.find(c => c.customId === "emoji_select")) {
                    const timeoutContainer = new ContainerBuilder()
                        .setAccentColor(0xfe8200)
                        .addTextDisplayComponents((textDisplay) =>
                            textDisplay.setContent("⏰ **Timed Out**\n\nYou didn't select an emoji in time. Please run the command again.")
                        );

                    response.edit({
                        components: [timeoutContainer],
                        flags: MessageFlags.IsComponentsV2
                    }).then(msg => {
                        setTimeout(() => {
                            msg.delete().catch(() => {});
                        }, 10000);
                    }).catch(() => {});
                }
            });

        } catch (error) {
            console.error("Error in addreact command:", error);
            
            const errorContainer = new ContainerBuilder()
                .setAccentColor(0xfe8200)
                .addTextDisplayComponents((textDisplay) =>
                    textDisplay.setContent("❌ **Error**\n\nAn error occurred while executing this command.")
                );

            try {
                const warningMsg = await interaction.reply({ 
                    components: [errorContainer], 
                    flags: MessageFlags.IsComponentsV2,
                    fetchReply: true 
                });
                
                setTimeout(() => {
                    warningMsg.delete().catch(() => {});
                }, 10000);
            } catch (e) {
                console.error("Error sending error message:", e);
            }
        }
    }
};