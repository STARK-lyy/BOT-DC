// commands/remove-count.js
import fs from "fs";
import path from "path";
import { SlashCommandBuilder, PermissionsBitField } from "discord.js";

const dataDir = "./data";
const dataFile = path.join(dataDir, "count.json");
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
if (!fs.existsSync(dataFile)) fs.writeFileSync(dataFile, "{}");

function loadData() {
  try { return JSON.parse(fs.readFileSync(dataFile)); } 
  catch { fs.writeFileSync(dataFile, "{}"); return {}; }
}

function saveData(json) { fs.writeFileSync(dataFile, JSON.stringify(json, null, 4)); }

export default {
  data: new SlashCommandBuilder()
    .setName("remove-count")
    .setDescription("Remove the counting channel"),
  async execute(interaction) {
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
      return interaction.reply({ content: "⛔ You need **Manage Server** permission.", ephemeral: true });
    }

    const guildId = interaction.guild.id;
    const allData = loadData();

    if (!allData[guildId]) return interaction.reply({ content: "⚠️ No counter channel set.", ephemeral: true });

    delete allData[guildId];
    saveData(allData);

    return interaction.reply({ content: "✅ Counter channel removed.", ephemeral: false });
  }
};