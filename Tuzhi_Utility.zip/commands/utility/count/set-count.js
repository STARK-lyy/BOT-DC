// commands/set-count.js
import fs from "fs";
import path from "path";
import { SlashCommandBuilder, PermissionsBitField } from "discord.js";

const dataDir = "./data";
const dataFile = path.join(dataDir, "count.json");
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
if (!fs.existsSync(dataFile)) fs.writeFileSync(dataFile, "{}");

function loadData() {
  try { return JSON.parse(fs.readFileSync(dataFile)); } 
  catch { fs.writeFileSync(dataFile, "{}"); return {}; }
}

function saveData(json) { fs.writeFileSync(dataFile, JSON.stringify(json, null, 4)); }

export default {
  data: new SlashCommandBuilder()
    .setName("set-count")
    .setDescription("Set the counting channel")
    .addChannelOption(option => 
      option.setName("channel")
        .setDescription("Channel to set as counter")
        .setRequired(true)
    ),
  async execute(interaction) {
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
      return interaction.reply({ content: "⛔ You need **Manage Server** permission.", ephemeral: true });
    }

    const channel = interaction.options.getChannel("channel");
    if (!channel.isTextBased()) return interaction.reply({ content: "⚠️ Please select a text channel.", ephemeral: true });

    const guildId = interaction.guild.id;
    const allData = loadData();

    if (allData[guildId] && allData[guildId].channelId === channel.id) {
      return interaction.reply({ content: "⚠️ This channel is already set as the counter channel.", ephemeral: true });
    }

    allData[guildId] = { channelId: channel.id, count: 1 };
    saveData(allData);

    return interaction.reply({ content: `✅ Counter channel set to ${channel}. Count starts at 1.`, ephemeral: false });
  }
};