import fs from "fs";
import path from "path";
import { SlashCommandBuilder, PermissionsBitField } from "discord.js";

const dataDir = "./data";
const dataFile = path.join(dataDir, "count.json");

// Load data
function loadData() {
  try {
    return JSON.parse(fs.readFileSync(dataFile));
  } catch {
    fs.writeFileSync(dataFile, "{}");
    return {};
  }
}

// Save data
function saveData(json) {
  fs.writeFileSync(dataFile, JSON.stringify(json, null, 4));
}

export default {
  data: new SlashCommandBuilder()
    .setName("reset-count")
    .setDescription("🔁 Reset the counting system to start from 1 (Manage Server only)"),

  async execute(interaction) {
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
      return interaction.reply({
        content: "⛔ You need **Manage Server** permission to use this command.",
        ephemeral: true,
      });
    }

    const guildId = interaction.guild.id;
    const allData = loadData();

    if (!allData[guildId] || !allData[guildId].channelId) {
      return interaction.reply({
        content: "⚠️ No counting channel is set for this server yet. Use `/set-count <channel>` first.",
        ephemeral: true,
      });
    }

    // Reset the count and last user info
    allData[guildId].count = 1;
    allData[guildId].lastUserId = null;
    saveData(allData);

    return interaction.reply({
      content: `✅ Count for **${interaction.guild.name}** has been reset to **1**.`,
    });
  },
};