import { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } from "discord.js";
import fs from "fs";
import path from "path";

const dataPath = path.join(process.cwd(), "data", "utility", "joinAutorole.json");

// Ensure data directory and file exist
function ensureDataFile() {
    const dir = path.dirname(dataPath);
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
    if (!fs.existsSync(dataPath)) {
        fs.writeFileSync(dataPath, JSON.stringify({}, null, 4));
    }
}

function loadData() {
    ensureDataFile();
    try {
        return JSON.parse(fs.readFileSync(dataPath, "utf-8"));
    } catch (error) {
        console.error("Error loading join autorole data:", error);
        return {};
    }
}

function saveData(data) {
    try {
        fs.writeFileSync(dataPath, JSON.stringify(data, null, 4));
    } catch (error) {
        console.error("Error saving join autorole data:", error);
    }
}

export default {
    data: new SlashCommandBuilder()
        .setName("add-join-autorole")
        .setDescription("Add roles that will be automatically assigned when new members join")
        .addStringOption(option =>
            option
                .setName("roles")
                .setDescription("Mention roles (e.g., @role1 @role2 or role1,role2)")
                .setRequired(true)
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .setDMPermission(false),

    async execute(interaction) {
        await interaction.deferReply({ ephemeral: true });

        // Check if user is server owner or admin
        if (interaction.user.id !== interaction.guild.ownerId && 
            !interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
            const errorEmbed = new EmbedBuilder()
                .setColor("#fe8200")
                .setDescription("<:TuZhi_Utility_UnTick:1433864956226572370> Only the server owner or administrators can use this command!");
            return interaction.editReply({ embeds: [errorEmbed] });
        }

        // Check bot permissions
        if (!interaction.guild.members.me.permissions.has(PermissionFlagsBits.ManageRoles)) {
            const errorEmbed = new EmbedBuilder()
                .setColor("#fe8200")
                .setDescription("<:TuZhi_Utility_UnTick:1433864956226572370> I don't have the **Manage Roles** permission!");
            return interaction.editReply({ embeds: [errorEmbed] });
        }

        const rolesInput = interaction.options.getString("roles");
        
        // Extract role IDs from various formats
        const roleIds = [];
        const rolePattern = /<@&(\d+)>/g;
        let match;
        
        while ((match = rolePattern.exec(rolesInput)) !== null) {
            roleIds.push(match[1]);
        }

        // Also handle comma-separated IDs
        const parts = rolesInput.split(/[,\s]+/);
        for (const part of parts) {
            const cleanId = part.replace(/[<@&>]/g, "");
            if (/^\d+$/.test(cleanId) && !roleIds.includes(cleanId)) {
                roleIds.push(cleanId);
            }
        }

        if (roleIds.length === 0) {
            const errorEmbed = new EmbedBuilder()
                .setColor("#fe8200")
                .setDescription("<:TuZhi_Utility_UnTick:1433864956226572370> No valid roles found! Please mention roles properly.\n\n**Examples:**\n`@role1 @role2`\n`@role1, @role2`");
            return interaction.editReply({ embeds: [errorEmbed] });
        }

        // Validate roles
        const validRoles = [];
        const invalidRoles = [];
        const botRole = interaction.guild.members.me.roles.highest;

        for (const roleId of roleIds) {
            const role = interaction.guild.roles.cache.get(roleId);
            
            if (!role) {
                invalidRoles.push(`<@&${roleId}> (Not Found)`);
                continue;
            }

            if (role.managed) {
                invalidRoles.push(`${role.name} (Managed by Integration)`);
                continue;
            }

            if (role.position >= botRole.position) {
                invalidRoles.push(`${role.name} (Higher than Bot's Role)`);
                continue;
            }

            if (role.id === interaction.guild.id) {
                invalidRoles.push(`${role.name} (@everyone)`);
                continue;
            }

            validRoles.push(role);
        }

        if (validRoles.length === 0) {
            const errorEmbed = new EmbedBuilder()
                .setColor("#fe8200")
                .setTitle("<:TuZhi_Utility_UnTick:1433864956226572370> No Valid Roles")
                .setDescription("None of the provided roles can be assigned.")
                .addFields({
                    name: "Issues Found:",
                    value: invalidRoles.join("\n") || "Unknown error"
                });
            return interaction.editReply({ embeds: [errorEmbed] });
        }

        // Load and update data
        const data = loadData();
        
        if (!data[interaction.guild.id]) {
            data[interaction.guild.id] = { roles: [] };
        }

        const existingRoles = data[interaction.guild.id].roles || [];
        const newRoles = [];
        const alreadyAdded = [];

        for (const role of validRoles) {
            if (existingRoles.includes(role.id)) {
                alreadyAdded.push(role);
            } else {
                existingRoles.push(role.id);
                newRoles.push(role);
            }
        }

        data[interaction.guild.id].roles = existingRoles;
        saveData(data);

        // Create response embed
        const embed = new EmbedBuilder()
            .setColor("#fe8200")
            .setTitle("<:management:1433852743948439593> Join Auto-Role Updated")
            .setTimestamp();

        if (newRoles.length > 0) {
            embed.addFields({
                name: "<:TuZhi_Utility_Tick:1433864870775885897> Added Roles:",
                value: newRoles.map(r => `<@&${r.id}>`).join(", ")
            });
        }

        if (alreadyAdded.length > 0) {
            embed.addFields({
                name: "<:TuZhi_Utility_save:1433851972435316756> Already Added:",
                value: alreadyAdded.map(r => `<@&${r.id}>`).join(", ")
            });
        }

        if (invalidRoles.length > 0) {
            embed.addFields({
                name: "<:TuZhi_Utility_UnTick:1433864956226572370> Skipped:",
                value: invalidRoles.join("\n")
            });
        }

        embed.addFields({
            name: "<:TuZhi_Utility_Users:1433852173430558910> Total Active Roles:",
            value: `${existingRoles.length} role(s)`
        });

        await interaction.editReply({ embeds: [embed] });
    }
};