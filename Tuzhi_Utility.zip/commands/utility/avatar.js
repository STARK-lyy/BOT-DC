import { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } from "discord.js";

const cooldowns = new Map();

export default {
    data: new SlashCommandBuilder()
        .setName("avatar")
        .setDescription("Get your avatar or someone else's avatar")
        .addUserOption(option =>
            option.setName("user")
                .setDescription("Select a user")
                .setRequired(false)
        ),

    cooldown: 5, // 5 seconds
    aliases: ["av", "pfp"], // Prefix aliases

    async execute(interaction) {
        const userId = interaction.user.id;
        
        // Cooldown check
        if (cooldowns.has(userId)) {
            const expirationTime = cooldowns.get(userId);
            const timeLeft = (expirationTime - Date.now()) / 1000;
            
            if (timeLeft > 0) {
                const embed = new EmbedBuilder()
                    .setColor(0xFE8200)
                    .setDescription(`⏱️ **Slow down!** You can use this command again <t:${Math.floor(expirationTime / 1000)}:R>`)
                    .setFooter({ text: `Cooldown: ${timeLeft.toFixed(1)}s remaining` });
                
                const reply = await interaction.reply({ embeds: [embed], ephemeral: true });
                
                // Delete cooldown message after 5 seconds
                setTimeout(async () => {
                    try {
                        await reply.delete();
                    } catch (e) {
                        // Ignore if already deleted
                    }
                }, 5000);
                
                return;
            }
        }

        // Set cooldown
        const cooldownTime = Date.now() + (this.cooldown * 1000);
        cooldowns.set(userId, cooldownTime);
        setTimeout(() => cooldowns.delete(userId), this.cooldown * 1000);

        const target = interaction.options.getUser("user") || interaction.user;

        // Get avatar URLs in different formats
        const avatarPng = target.displayAvatarURL({ extension: "png", size: 4096 });
        const avatarJpg = target.displayAvatarURL({ extension: "jpg", size: 4096 });
        const avatarWebp = target.displayAvatarURL({ extension: "webp", size: 4096 });

        // Create embed with Components v2 style
        const embed = new EmbedBuilder()
            .setColor(0xFE8200)
            .setAuthor({ 
                name: `${target.username}'s Avatar`, 
                iconURL: target.displayAvatarURL({ size: 64 })
            })
            .setDescription(
                `<:TuZhi_Utility_Two_Arrow:1433864767570706605> **User**: ${target}\n\n` +
                `[**PNG**](${avatarPng}) **|** [**JPG**](${avatarJpg}) **|** [**WEBP**](${avatarWebp})`
            )
            .setImage(avatarPng)
            .setFooter({ 
                text: `Requested by ${interaction.user.username}`, 
                iconURL: interaction.user.displayAvatarURL({ size: 64 })
            })
            .setTimestamp();

        // Create buttons for download links
        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setLabel("PNG")
                    .setStyle(ButtonStyle.Link)
                    .setURL(avatarPng)
                    .setEmoji("<:TuZhi_Utility_Links:1433871554323939348>"),
                new ButtonBuilder()
                    .setLabel("JPG")
                    .setStyle(ButtonStyle.Link)
                    .setURL(avatarJpg)
                    .setEmoji("<:TuZhi_Utility_Links:1433871554323939348>"),
                new ButtonBuilder()
                    .setLabel("WEBP")
                    .setStyle(ButtonStyle.Link)
                    .setURL(avatarWebp)
                    .setEmoji("<:TuZhi_Utility_Links:1433871554323939348>")
            );

        // Success message - DO NOT delete
        await interaction.reply({ embeds: [embed], components: [row] });

        console.log(`✅ Avatar command used by ${interaction.user.tag} for ${target.tag}`);
    },

    async runPrefix(message, args) {
        const userId = message.author.id;
        
        // Cooldown check
        if (cooldowns.has(userId)) {
            const expirationTime = cooldowns.get(userId);
            const timeLeft = (expirationTime - Date.now()) / 1000;
            
            if (timeLeft > 0) {
                const embed = new EmbedBuilder()
                    .setColor(0xFE8200)
                    .setDescription(`⏱️ **Slow down!** You can use this command again <t:${Math.floor(expirationTime / 1000)}:R>`)
                    .setFooter({ text: `Cooldown: ${timeLeft.toFixed(1)}s remaining` });
                
                const reply = await message.reply({ embeds: [embed] });
                
                // Delete cooldown message after 5 seconds
                setTimeout(async () => {
                    try {
                        await reply.delete();
                    } catch (e) {
                        // Ignore if already deleted
                    }
                }, 5000);
                
                return;
            }
        }

        // Set cooldown
        const cooldownTime = Date.now() + (this.cooldown * 1000);
        cooldowns.set(userId, cooldownTime);
        setTimeout(() => cooldowns.delete(userId), this.cooldown * 1000);

        // Get target user (mentioned user or author)
        const target = message.mentions.users.first() || message.author;

        // Get avatar URLs in different formats
        const avatarPng = target.displayAvatarURL({ extension: "png", size: 4096 });
        const avatarJpg = target.displayAvatarURL({ extension: "jpg", size: 4096 });
        const avatarWebp = target.displayAvatarURL({ extension: "webp", size: 4096 });

        // Create embed with Components v2 style
        const embed = new EmbedBuilder()
            .setColor(0xFE8200)
            .setAuthor({ 
                name: `${target.username}'s Avatar`, 
                iconURL: target.displayAvatarURL({ size: 64 })
            })
            .setDescription(
                `<:TuZhi_Utility_Two_Arrow:1433864767570706605> **User**: ${target}\n\n` +
                `[**PNG**](${avatarPng}) **|** [**JPG**](${avatarJpg}) **|** [**WEBP**](${avatarWebp})`
            )
            .setImage(avatarPng)
            .setFooter({ 
                text: `Requested by ${message.author.username}`, 
                iconURL: message.author.displayAvatarURL({ size: 64 })
            })
            .setTimestamp();

        // Create buttons for download links
        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setLabel("PNG")
                    .setStyle(ButtonStyle.Link)
                    .setURL(avatarPng)
                    .setEmoji("<:TuZhi_Utility_Links:1433871554323939348>"),
                new ButtonBuilder()
                    .setLabel("JPG")
                    .setStyle(ButtonStyle.Link)
                    .setURL(avatarJpg)
                    .setEmoji("<:TuZhi_Utility_Links:1433871554323939348>"),
                new ButtonBuilder()
                    .setLabel("WEBP")
                    .setStyle(ButtonStyle.Link)
                    .setURL(avatarWebp)
                    .setEmoji("<:TuZhi_Utility_Links:1433871554323939348>")
            );

        // Success message - DO NOT delete
        await message.channel.send({ embeds: [embed], components: [row] });

        console.log(`✅ Avatar command used by ${message.author.tag} for ${target.tag} (prefix)`);
    }
};