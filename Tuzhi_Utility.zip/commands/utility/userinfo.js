import { 
    SlashCommandBuilder,
    EmbedBuilder,
    MessageFlags
} from "discord.js";

const cooldowns = new Map();

// Discord Badge Icons with proper styling
const BADGE_EMOJIS = {
    Staff: "<:StaffBadge:1437816512898400306>",
    Partner: "<:badgePartner:1437816868919316480>",
    HypeSquadEvents: "<:HypeBadge:1437818739893735434>",
    BugHunterLevel1: "<:badge_BugHunter:1437818177487638528>",
    HypeSquadOnlineHouse1: "<:Badge_HypesquadBravery:1437817691179323392>",
    HypeSquadOnlineHouse2: "<:BadgeHypeSquadBrilliance:1437817728198115329>",
    HypeSquadOnlineHouse3: "<:Hypesquad_Balance_Badge:1437817821114663014>",
    PremiumEarlySupporter: "<:early_supporter:1437819901023617187>",
    BugHunterLevel2: "<:Badge_bug_hunter_Gold:1437818247352422565>",
    VerifiedDeveloper: "<:VerifiedBotDeveloper:1437820114152984706>",
    CertifiedModerator: "<:CertifiedModerator:1437820440952307763>",
    ActiveDeveloper: "<:active_devloper:1437709469084684362>",
    Nitro: "<:TuZhi_Nitro:1438340332269076640>",
    ServerBooster: "<:TuZhi_boost:1438340460815847595>"
};

const STATUS_ICONS = {
    online: "<:TuZhi_Online:1438139392534384772>",
    idle: "<:TuZhi_Idle:1438139180193415260>",
    dnd: "<:TuZhi_DnD:1438139224963551263>",
    offline: "<:TuZhi_Ofline:1438139267116433468>"
};

const DEVICE_ICONS = {
    mobile: "<:TuZhi_Mobile:1438336860886925312>",
    desktop: "<:TuZhi_Computer:1438336099868217387>",
    web: "<:TuZhi_Browser:1438336265631043675>"
};

const ACTIVITY_ICONS = {
    playing: "<:TuZhi_Playing:1438335670593650799>",
    listening: "<:TuZhi_Listings:1438335753099673630>",
    watching: "<:TuZhi_Watching:1438339122786996264>",
    streaming: "<:TuZhi_Playing:1438335670593650799>",
    competing: "<:TuZhi_Playing:1438335670593650799>",
    none: "<:TuZhi_NoActivity:1438339827765608479>"
};

function getUserBadges(user, member) {
    const badges = [];
    const flags = user.flags?.toArray() || [];
    
    for (const flag of flags) {
        if (BADGE_EMOJIS[flag]) {
            badges.push(BADGE_EMOJIS[flag]);
        }
    }
    
    if (member.premiumSince) {
        badges.push(BADGE_EMOJIS.ServerBooster);
    }
    
    if (user.avatar?.startsWith('a_') || user.banner) {
        badges.push(BADGE_EMOJIS.Nitro);
    }
    
    return badges;
}

function getAccountAge(timestamp) {
    const now = Date.now();
    const diff = now - timestamp;
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const months = Math.floor(days / 30);
    const years = Math.floor(days / 365);
    
    if (years > 0) return `${years} year${years > 1 ? 's' : ''} old`;
    if (months > 0) return `${months} month${months > 1 ? 's' : ''} old`;
    return `${days} day${days > 1 ? 's' : ''} old`;
}

async function getUserInfo(interaction, targetUser) {
    const guild = interaction.guild;
    const member = targetUser 
        ? await guild.members.fetch(targetUser.id).catch(() => null)
        : interaction.member;
    
    if (!member) {
        return interaction.reply({ 
            content: "<:TuZhi_Utility_UnTick:1433864956226572370> User not found in this server.", 
            flags: MessageFlags.Ephemeral
        });
    }

    const user = await member.user.fetch(true);
    
    // Badges
    const badgesArray = getUserBadges(user, member);
    const badgeDisplay = badgesArray.length > 0 
        ? `> ${badgesArray.join(" ")} \`${badgesArray.length} Badge${badgesArray.length > 1 ? 's' : ''}\``
        : "> <:TuZhi_Utility_UnTick:1433864956226572370> \`No Badges\`";
    
    // Roles
    const roles = member.roles.cache
        .filter(r => r.id !== guild.id)
        .sort((a, b) => b.position - a.position);
    
    const topRoles = Array.from(roles.values()).slice(0, 5).map(r => `<@&${r.id}>`).join(" ");
    const moreRoles = roles.size > 5 ? ` · **+${roles.size - 5} more**` : "";
    const roleDisplay = roles.size > 0 ? topRoles + moreRoles : "`No Roles`";
    
    // Key Permissions
    const keyPerms = [];
    if (member.permissions.has("Administrator")) keyPerms.push("Administrator");
    if (member.permissions.has("ManageGuild")) keyPerms.push("Manage Server");
    if (member.permissions.has("ManageChannels")) keyPerms.push("Manage Channels");
    if (member.permissions.has("BanMembers")) keyPerms.push("Ban Members");
    if (member.permissions.has("KickMembers")) keyPerms.push("Kick Members");
    if (member.permissions.has("ManageRoles")) keyPerms.push("Manage Roles");
    if (member.permissions.has("ManageMessages")) keyPerms.push("Manage Messages");
    if (member.permissions.has("MentionEveryone")) keyPerms.push("Mention Everyone");
    if (member.permissions.has("ModerateMembers")) keyPerms.push("Timeout Members");
    if (member.permissions.has("ManageWebhooks")) keyPerms.push("Manage Webhooks");
    if (member.permissions.has("ManageNicknames")) keyPerms.push("Manage Nicknames");
    
    const permDisplay = keyPerms.length > 0 
        ? keyPerms.slice(0, 5).map(p => `\`${p}\``).join(" · ") + (keyPerms.length > 5 ? ` · **+${keyPerms.length - 5} more**` : "")
        : "> \`No Key Permissions\`";
    
    // Dangerous stats
    const dangerousRoleCount = member.roles.cache.filter(r => 
        r.permissions.has("Administrator") || 
        r.permissions.has("BanMembers") ||
        r.permissions.has("KickMembers") ||
        r.permissions.has("ManageGuild")
    ).size;
    
    const managedRoleCount = member.roles.cache.filter(r => r.managed).size;
    
    // Timestamps
    const accountCreated = Math.floor(user.createdTimestamp / 1000);
    const serverJoined = Math.floor(member.joinedTimestamp / 1000);
    const accountAge = getAccountAge(user.createdTimestamp);
    const serverAge = getAccountAge(member.joinedTimestamp);
    
    // Status & Activity
    const status = member.presence?.status || "offline";
    const statusIcon = STATUS_ICONS[status];
    const statusText = status.charAt(0).toUpperCase() + status.slice(1);
    
    let devices = [];
    if (member.presence?.clientStatus) {
        const { clientStatus } = member.presence;
        if (clientStatus.desktop) devices.push(DEVICE_ICONS.desktop);
        if (clientStatus.mobile) devices.push(DEVICE_ICONS.mobile);
        if (clientStatus.web) devices.push(DEVICE_ICONS.web);
    }
    const deviceDisplay = devices.length > 0 ? devices.join(" ") : "<:TuZhi_Ofline:1438139267116433468>";
    const deviceText = devices.length > 0 ? `${devices.length} Device(s)` : "Offline";
    
    // Activity
    let activity = "No Activity";
    let activityIcon = ACTIVITY_ICONS.none;
    if (member.presence?.activities?.length > 0) {
        const act = member.presence.activities[0];
        if (act.type === 4) {
            activity = act.state || "Custom Status";
            activityIcon = ACTIVITY_ICONS.none;
        } else if (act.type === 0) {
            activity = `Playing ${act.name}`;
            activityIcon = ACTIVITY_ICONS.playing;
        } else if (act.type === 2) {
            activity = `Listening to ${act.name}`;
            activityIcon = ACTIVITY_ICONS.listening;
        } else if (act.type === 3) {
            activity = `Watching ${act.name}`;
            activityIcon = ACTIVITY_ICONS.watching;
        } else if (act.type === 1) {
            activity = `Streaming ${act.name}`;
            activityIcon = ACTIVITY_ICONS.streaming;
        }
    }
    
    // Boost info
    const boostStatus = member.premiumSince 
        ? `Boosting since <t:${Math.floor(member.premiumSinceTimestamp / 1000)}:R>`
        : "Not Boosting";
    
    // Timeout
    const timeoutUntil = member.communicationDisabledUntil;
    const isTimedOut = timeoutUntil && timeoutUntil > Date.now();
    const timeoutDisplay = isTimedOut 
        ? `<:TuZhi_Utility_UnTick:1433864956226572370> Timed out until <t:${Math.floor(timeoutUntil / 1000)}:R>`
        : "<:TuZhi_Utility_Tick:1433864870775885897> Not Timed Out";
    
    // Voice
    const voiceDisplay = member.voice.channel 
        ? `<:TuZhi_Utility_Voice:1433861367382802635> In ${member.voice.channel.name}`
        : "<:TuZhi_Utility_UnTick:1433864956226572370> Not in Voice";
    
    // Avatar & Banner
    const avatarURL = user.displayAvatarURL({ size: 512, extension: 'png' });
    const bannerURL = user.bannerURL({ size: 1024, extension: 'png' });
    
    // Extra Info - Advanced Features
    const isBot = user.bot ? "<:TuZhi_Utility_Tick:1433864870775885897> Yes" : "<:TuZhi_Utility_UnTick:1433864956226572370> No";
    const isOwner = guild.ownerId === user.id ? "<:TuZhi_Utility_Tick:1433864870775885897> Server Owner" : "<:TuZhi_Utility_UnTick:1433864956226572370> Member";
    const nickname = member.nickname ? `\`${member.nickname}\`` : "`None`";
    
    // Avatar type detection
    const hasAnimatedAvatar = user.avatar?.startsWith('a_') ? "<:TuZhi_Utility_Tick:1433864870775885897> Animated" : "<:TuZhi_Utility_UnTick:1433864956226572370> Static";
    const hasBanner = bannerURL ? "<:TuZhi_Utility_Tick:1433864870775885897> Yes" : "<:TuZhi_Utility_UnTick:1433864956226572370> No";
    
    // User Profile Badge (same as Discord shows badges on profile)
    const profileBadgeEmoji = user.bot ? "🤖" : "✨";
    
    // Acknowledgements (like Discord shows "member since" on profile)
    const acknowledgements = [];
    if (guild.ownerId === user.id) {
        acknowledgements.push("<:TuZhi_Owner:1438358888276693073> Owner");
    }
    if (member.permissions.has("Administrator")) {
        acknowledgements.push("<a:HeadAdmin:1438357047598121061> Admin");
    }
    if (member.permissions.has("ModerateMembers")) {
        acknowledgements.push("<a:mod:1438357931946152067> Mod");
    }
    
    const ackDisplay = acknowledgements.length > 0 
        ? `\n> ${acknowledgements.join(" · ")}`
        : "";
    
    // Build Embed
    const embed = new EmbedBuilder()
        .setColor("fe8200")
        .setAuthor({ 
            name: `${profileBadgeEmoji} Who is ${user.displayName}?`, 
            iconURL: avatarURL 
        })
        .setDescription(
            `**USER INFORMATION**\n` +
            `> <:TuZhi_Utility_User:1433852028207104145> **Username:** \`${user.username}\`\n` +
            `> <:TuZhi_Utility_HasTag:1433860789344800781> **Display Name:** \`${user.displayName}\`\n` +
            `> <:TuZhi_Utility_Paint:1433861849798934570> **Nickname:** ${nickname}\n` +
            `> <:TuZhi_Utility_OneArrow:1433871661928808682> **User ID:** \`${user.id}\`\n` +
            `> <:TuZhi_Utility_Paint:1433861849798934570> **Role Color:** \`${member.displayHexColor}\`\n` +
            `> 🔸 **User:** ${badgeDisplay}\n` +
            `${ackDisplay}\n\n` +
            
            `**ACCOUNT TIMESTAMPS**\n` +
            `> <:TuZhi_Utility_Date:1433872454861852870> **Account Created:** <t:${accountCreated}:F> · \`${accountAge}\`\n` +
            `> <:TuZhi_Utility_Date:1433872454861852870> **Server Joined:** <t:${serverJoined}:F> · \`${serverAge}\`\n\n` +
            
            `**STATUS & ACTIVITY**\n` +
            `> ${statusIcon} **Status:** \`${statusText}\`\n` +
            `> ${deviceDisplay} **Device:** \`${deviceText}\`\n` +
            `> ${activityIcon} **Activity:** ${activity}\n\n` +
            
            `**ROLES & PERMISSIONS**\n` +
            `> <:TuZhi_Utility_Managements:1433852901884825632> **Roles [${roles.size}]:** ${roleDisplay}\n` +
            `> <:TuZhi_Utility_Star_mod:1433861404699660421> **Highest Role:** ${member.roles.highest.id !== guild.id ? `<@&${member.roles.highest.id}>` : "`None`"}\n` +
            `> <:management:1433852743948439593> **Dangerous Roles:** \`${dangerousRoleCount}\` · **Managed:** \`${managedRoleCount}\`\n` +
            `> <:TuZhi_Utility_Secured:1433861508328329349> **Key Permissions:**\n` +
            `> ${permDisplay}\n\n` +
            
            `**SERVER STATUS**\n` +
            `> <:TuZhi_boost:1438340460815847595> **Boost:** ${boostStatus}\n` +
            `> ${timeoutDisplay}\n` +
            `> ${voiceDisplay}\n\n` +
            
            `**EXTRA INFO**\n` +
            `> <:TuZhi_Utility_Setting:1433855987626020925> **Bot Account:** ${isBot}\n` +
            `> <:TuZhi_Utility_Star_mod:1433861404699660421> **Status:** ${isOwner}\n` +
            `> <:TuZhi_Utility_Artist:1433851488001851515> **Avatar Type:** ${hasAnimatedAvatar}\n` +
            `> <:TuZhi_Utility_Paint:1433861849798934570> **Profile Banner:** ${hasBanner}\n` +
            `> <:TuZhi_Utility_Links:1433871554323939348> **[Avatar URL](${avatarURL}) · [User Profile](https://discord.com/users/${user.id})**`
        )
        .setFooter({ 
            text: `Requested by ${interaction.user?.tag || interaction.author?.tag} • TuZhi Utility`, 
            iconURL: (interaction.user || interaction.author)?.displayAvatarURL() 
        })
        .setTimestamp();
    
    if (bannerURL) {
        embed.setImage(bannerURL);
    }
    
    return { embeds: [embed] };
}

export default {
    data: new SlashCommandBuilder()
        .setName("userinfo")
        .setDescription("Shows detailed information about a user")
        .addUserOption(option =>
            option.setName("user")
                .setDescription("The user to get information about")
                .setRequired(false)
        ),

    cooldown: 5,
    aliases: ["ui", "useri", "whois", "memberinfo", "user"],

    async execute(interaction) {
        const userId = interaction.user.id;
        
        if (cooldowns.has(userId)) {
            const expirationTime = cooldowns.get(userId);
            const timeLeft = (expirationTime - Date.now()) / 1000;
            
            if (timeLeft > 0) {
                return interaction.reply({ 
                    content: `<:TuZhi_Utility_Cooldown:1433852369799745761> **Slow down!** Try again <t:${Math.floor(expirationTime / 1000)}:R>`, 
                    flags: MessageFlags.Ephemeral
                });
            }
        }

        cooldowns.set(userId, Date.now() + 5000);
        setTimeout(() => cooldowns.delete(userId), 5000);

        const targetUser = interaction.options.getUser("user");
        const response = await getUserInfo(interaction, targetUser);
        
        await interaction.reply(response);
    },

    async runPrefix(message, args) {
        const userId = message.author.id;
        
        if (cooldowns.has(userId)) {
            const expirationTime = cooldowns.get(userId);
            const timeLeft = (expirationTime - Date.now()) / 1000;
            
            if (timeLeft > 0) {
                const reply = await message.reply(
                    `<:TuZhi_Utility_Cooldown:1433852369799745761> **Slow down!** Try again in ${timeLeft.toFixed(1)}s`
                );
                setTimeout(() => reply.delete().catch(() => {}), 10000);
                return;
            }
        }

        cooldowns.set(userId, Date.now() + 5000);
        setTimeout(() => cooldowns.delete(userId), 5000);

        let targetUser = null;
        
        if (message.mentions.users.size > 0) {
            targetUser = message.mentions.users.first();
        } else if (args[0]) {
            try {
                targetUser = await message.client.users.fetch(args[0]);
            } catch (e) {}
        } else if (message.reference) {
            const repliedMsg = await message.channel.messages.fetch(message.reference.messageId).catch(() => null);
            if (repliedMsg) targetUser = repliedMsg.author;
        }

        const mockInteraction = {
            guild: message.guild,
            member: message.member,
            author: message.author,
            client: message.client,
            reply: async (data) => await message.channel.send(data)
        };

        const response = await getUserInfo(mockInteraction, targetUser);
        await message.channel.send(response);
    }
};