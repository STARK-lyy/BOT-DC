import {
  SlashCommandBuilder,
  TextDisplayBuilder,
  SectionBuilder,
  ContainerBuilder,
  SeparatorBuilder,
  ButtonBuilder,
  ButtonStyle,
  MessageFlags,
} from "discord.js";
import os from "os";
import fs from "fs";
import process from "process";
import pkg from "discord.js";

const BOT_VERSION = process.env.BOT_VERSION || "Unknown";
const OWNER_ID = process.env.OWNER_ID || "Unknown";

export default {
  data: new SlashCommandBuilder()
    .setName("status")
    .setDescription("Shows TuZhi Utility bot's real-time statistics."),

  async execute(interaction) {
    const client = interaction.client;
    if (!client.user)
      return interaction.reply({
        content: "❌ Bot not ready yet. Try again.",
        flags: 64,
      });

    // 🕒 UPTIME
    const totalSeconds = Math.floor(process.uptime());
    const days = Math.floor(totalSeconds / 86400);
    const hours = Math.floor((totalSeconds % 86400) / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    let uptime = "";
    if (days) uptime += `${days}d `;
    if (hours) uptime += `${hours}h `;
    if (minutes) uptime += `${minutes}m `;
    if (!days && !hours) uptime += `${seconds}s`;

    // 💾 MEMORY
    const mem = process.memoryUsage();
    const usedMB = (mem.rss / 1024 / 1024).toFixed(2);
    const totalGB = (os.totalmem() / 1024 / 1024 / 1024).toFixed(2);
    const memPercent = ((mem.rss / os.totalmem()) * 100).toFixed(2);

    // ⚙️ CPU
    const cpuModel = os.cpus()[0].model;
    const cpuLoad = os.loadavg()[0].toFixed(2);

    // 🌐 STATS
    const servers = client.guilds.cache.size;
    const users = client.guilds.cache.reduce((a, g) => a + g.memberCount, 0);
    const channels = client.channels.cache.size;
    const texts = client.channels.cache.filter(c => c.type === 0).size;
    const voices = client.channels.cache.filter(c => c.type === 2).size;

    const files = fs.readdirSync("./commands").filter(f => f.endsWith(".js"));
    const cmdCount = files.length;

    // 🧱 BASIC TEXT BLOCK
    const basicText = new TextDisplayBuilder().setContent(
      `# TuZhi Utility Status`
   );
     const menText = new TextDisplayBuilder().setContent(
      `**┃ Basic Info**  
┣ Owner: <@${OWNER_ID}>  
┣ Bot Created: <t:${Math.floor(client.user.createdTimestamp / 1000)}:R>  
┣ Uptime: **${uptime}**  
┣ Ping: **${client.ws.ping}ms**  
┗ Commands: **${cmdCount}**`
    );

    const sysText = new TextDisplayBuilder().setContent(
      `**┃ System Info**  
┣ Memory: **${usedMB}MB / ${totalGB}GB (${memPercent}%)**  
┣ CPU: **${cpuModel} (${cpuLoad}%)**  
┣ Platform: **${os.platform()} (${os.arch()})**  
┣ System Uptime: **${Math.floor(os.uptime() / 60)} min**  
┣ Node.js: **${process.version}**  
┗ Discord.js: **${pkg.version}**`
    );

    const netText = new TextDisplayBuilder().setContent(
      `**┃ Network Metrics**  
┣ Servers: **${servers}**  
┣ Users: **${users.toLocaleString()}**  
┣ Channels: **${channels}**  
┗ Shards: **${client.ws.shards?.size || 1}**`
    );

    // 🧱 Buttons (Privacy Policy & ToS)
    const privacyBtn = new ButtonBuilder()
      .setLabel("Privacy Policy")
      .setStyle(ButtonStyle.Link)
      .setURL("https://tuzhiutility-bot.vercel.app/privacy.html");

    const tosBtn = new ButtonBuilder()
      .setLabel("ToS")
      .setStyle(ButtonStyle.Link)
      .setURL("https://tuzhiutility-bot.vercel.app/tos.html");

    // 🧱 Container layout (NO COLOR)
    const container = new ContainerBuilder()
      .addTextDisplayComponents(basicText)
      .addSeparatorComponents((s) => s)
      .addTextDisplayComponents(menText)
      .addSeparatorComponents((s) => s)
      .addTextDisplayComponents(sysText)
      .addSeparatorComponents((s) => s)
      .addTextDisplayComponents(netText)
      .addSeparatorComponents((s) => s)
      .addSectionComponents((section) =>
        section
          .addTextDisplayComponents((t) =>
            t.setContent("📘 **TuZhi Utility** v" + BOT_VERSION)
          )
          .setButtonAccessory(tosBtn)
      )
      .addSectionComponents((section) =>
        section
          .addTextDisplayComponents((t) => t.setContent("🔒 Privacy Policy"))
          .setButtonAccessory(privacyBtn)
      );

    await interaction.reply({
      components: [container],
      flags: MessageFlags.IsComponentsV2,
    });
  },
};