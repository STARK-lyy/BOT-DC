import {
    SlashCommandBuilder,
    TextDisplayBuilder,
    ContainerBuilder,
    SeparatorBuilder,
    ButtonBuilder,
    ButtonStyle,
    ActionRowBuilder,
    MessageFlags,
    PermissionFlagsBits
} from "discord.js";

const cooldowns = new Map();

export default {
    data: new SlashCommandBuilder()
        .setName("add")
        .setDescription("Add emojis to your server")
        .addSubcommand(subcommand =>
            subcommand
                .setName("emoji")
                .setDescription("Add a custom emoji to this server")
                .addStringOption(option =>
                    option
                        .setName("emote")
                        .setDescription("The emoji to add (e.g., <:name:123456789>)")
                        .setRequired(true)
                )
                .addStringOption(option =>
                    option
                        .setName("name")
                        .setDescription("Name for the emoji (optional)")
                        .setRequired(false)
                )
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuildExpressions),

    aliases: ["steal", "addemoji"],
    cooldown: 5,

    // 🟠 Utility Function - Styled Message Containers
    buildMessageContainer(title, message, color, emoji) {
        const header = new TextDisplayBuilder().setContent(`${emoji} **${title}**`);
        const body = new TextDisplayBuilder().setContent(`> ${message}`);
        return new ContainerBuilder()
            .setAccentColor(color)
            .addTextDisplayComponents(header)
            .addSeparatorComponents(new SeparatorBuilder())
            .addTextDisplayComponents(body);
    },

    // 🟠 Parse Emoji Function
    parseEmoji(emojiString) {
        // Custom emoji format: <:name:id> or <a:name:id>
        const customMatch = emojiString.match(/<a?:(\w+):(\d+)>/);
        if (customMatch) {
            const animated = emojiString.startsWith('<a:');
            return {
                name: customMatch[1],
                id: customMatch[2],
                animated,
                url: `https://cdn.discordapp.com/emojis/${customMatch[2]}.${animated ? 'gif' : 'png'}`
            };
        }
        return null;
    },

    // 🟠 Slash Command Handler
    async execute(interaction) {
        const userId = interaction.user.id;

        // Cooldown Check
        if (cooldowns.has(userId)) {
            const expirationTime = cooldowns.get(userId);
            const timeLeft = (expirationTime - Date.now()) / 1000;

            if (timeLeft > 0) {
                const cooldownContainer = this.buildMessageContainer(
                    "Slow Down",
                    `You can use this command again <t:${Math.floor(expirationTime / 1000)}:R>`,
                    0xFE8200,
                    "<:TuZhi_Utility_Cooldown:1433852369799745761>"
                );

                const reply = await interaction.reply({
                    components: [cooldownContainer],
                    flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral
                });

                setTimeout(() => reply.delete().catch(() => {}), 10000);
                return;
            }
        }

        cooldowns.set(userId, Date.now() + 5000);
        setTimeout(() => cooldowns.delete(userId), 5000);

        const guild = interaction.guild;
        if (!guild) {
            const errorContainer = this.buildMessageContainer(
                "Error",
                "This command can only be used in a server!",
                0xFE8200,
                "<:TuZhi_Utility_UnTick:1433864956226572370>"
            );

            const reply = await interaction.reply({
                components: [errorContainer],
                flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral
            });

            setTimeout(() => reply.delete().catch(() => {}), 10000);
            return;
        }

        // Permission Check
        if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuildExpressions)) {
            const warnContainer = this.buildMessageContainer(
                "Warn",
                "You need **Manage Emojis** permission to use this command!",
                0xFE8200,
                "<:TuZhi_Utility_Winn:1433861769528479794>"
            );

            const reply = await interaction.reply({
                components: [warnContainer],
                flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral
            });

            setTimeout(() => reply.delete().catch(() => {}), 10000);
            return;
        }

        const emoteString = interaction.options.getString("emote");
        const customName = interaction.options.getString("name");

        const emojiData = this.parseEmoji(emoteString);

        if (!emojiData) {
            const errorContainer = this.buildMessageContainer(
                "Error",
                "Invalid emoji format! Use a custom Discord emoji like `<:name:123456789>`",
                0xFE8200,
                "<:TuZhi_Utility_Confused:1433865082193842349>"
            );

            const reply = await interaction.reply({
                components: [errorContainer],
                flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral
            });

            setTimeout(() => reply.delete().catch(() => {}), 10000);
            return;
        }

        const finalName = customName || emojiData.name;

        // Show Confirmation with Buttons
        await this.showConfirmation(interaction, emojiData, finalName, guild);
    },

    // 🟠 Prefix Command Handler
    async runPrefix(message, args, client) {
        const userId = message.author.id;

        // Cooldown Check
        if (cooldowns.has(userId)) {
            const expirationTime = cooldowns.get(userId);
            const timeLeft = (expirationTime - Date.now()) / 1000;

            if (timeLeft > 0) {
                const cooldownContainer = this.buildMessageContainer(
                    "Slow Down",
                    `You can use this command again <t:${Math.floor(expirationTime / 1000)}:R>`,
                    0xFE8200,
                    "<:TuZhi_Utility_Cooldown:1433852369799745761>"
                );

                const reply = await message.reply({
                    components: [cooldownContainer],
                    flags: MessageFlags.IsComponentsV2
                });

                setTimeout(() => reply.delete().catch(() => {}), 10000);
                return;
            }
        }

        cooldowns.set(userId, Date.now() + 5000);
        setTimeout(() => cooldowns.delete(userId), 5000);

        const guild = message.guild;

        // Permission Check
        if (!message.member.permissions.has(PermissionFlagsBits.ManageGuildExpressions)) {
            const warnContainer = this.buildMessageContainer(
                "Warn",
                "You need **Manage Emojis** permission to use this command!",
                0xFE8200,
                "<:TuZhi_Utility_Winn:1433861769528479794>"
            );

            const reply = await message.reply({
                components: [warnContainer],
                flags: MessageFlags.IsComponentsV2
            });

            setTimeout(() => reply.delete().catch(() => {}), 10000);
            return;
        }

        let emojiData = null;
        let finalName = null;

        // Check if replying to a message
        if (message.reference) {
            const repliedMsg = await message.channel.messages.fetch(message.reference.messageId).catch(() => null);
            
            if (repliedMsg) {
                // Extract emoji from replied message
                const emojiMatch = repliedMsg.content.match(/<a?:(\w+):(\d+)>/);
                
                if (emojiMatch) {
                    const animated = repliedMsg.content.includes('<a:');
                    emojiData = {
                        name: emojiMatch[1],
                        id: emojiMatch[2],
                        animated,
                        url: `https://cdn.discordapp.com/emojis/${emojiMatch[2]}.${animated ? 'gif' : 'png'}`
                    };
                    finalName = args[0] || emojiData.name;
                }
            }
        } else {
            // Get emoji from command args
            const emoteString = args[0];
            
            if (!emoteString) {
                const errorContainer = this.buildMessageContainer(
                    "Error",
                    "Please provide an emoji or reply to a message with emoji!\nUsage: `.steal <emoji>` or reply to message",
                    0xFE8200,
                    "<:TuZhi_Utility_Confused:1433865082193842349>"
                );

                const reply = await message.reply({
                    components: [errorContainer],
                    flags: MessageFlags.IsComponentsV2
                });

                setTimeout(() => reply.delete().catch(() => {}), 10000);
                return;
            }

            emojiData = this.parseEmoji(emoteString);
            finalName = args[1] || (emojiData ? emojiData.name : null);
        }

        if (!emojiData) {
            const errorContainer = this.buildMessageContainer(
                "Error",
                "No valid emoji found! Use a custom Discord emoji.",
                0xFE8200,
                "<:TuZhi_Utility_Confused:1433865082193842349>"
            );

            const reply = await message.reply({
                components: [errorContainer],
                flags: MessageFlags.IsComponentsV2
            });

            setTimeout(() => reply.delete().catch(() => {}), 10000);
            return;
        }

        // Show Confirmation with Buttons
        await this.showConfirmationPrefix(message, emojiData, finalName, guild);
    },

    // 🟠 Show Confirmation (Slash)
    async showConfirmation(interaction, emojiData, finalName, guild) {
        const header = new TextDisplayBuilder().setContent(
            `<:TuZhi_Utility_EmojiPlus:1433853283545518324> **Add Emoji Confirmation**`
        );

        const details = new TextDisplayBuilder().setContent(
            `<:TuZhi_Utility_Two_Arrow:1433864767570706605> **Emoji:** ${emojiData.animated ? '<a:' : '<:'}${emojiData.name}:${emojiData.id}>\n` +
            `<:TuZhi_Utility_Repaire:1433853017911857236> **Name:** \`${finalName}\`\n` +
            `<:TuZhi_Utility_Fire:1433856226441170944> **Type:** ${emojiData.animated ? 'Animated' : 'Static'}`
        );

        const footer = new TextDisplayBuilder().setContent(
            `<:TuZhi_Utility_User:1433852028207104145> **Requested by:** ${interaction.user}`
        );

        const container = new ContainerBuilder()
            .setAccentColor(0xFE8200)
            .addTextDisplayComponents(header)
            .addSeparatorComponents(new SeparatorBuilder())
            .addTextDisplayComponents(details)
            .addSeparatorComponents(new SeparatorBuilder())
            .addTextDisplayComponents(footer);

        const addButton = new ButtonBuilder()
            .setCustomId(`emoji_add_${emojiData.id}_${finalName}`)
            .setLabel("Add Emoji")
            .setStyle(ButtonStyle.Primary)
            .setEmoji({ name: "TuZhi_Utility_Tick", id: "1433864870775885897" });

        const cancelButton = new ButtonBuilder()
            .setCustomId(`emoji_cancel`)
            .setLabel("Cancel")
            .setStyle(ButtonStyle.Secondary)
            .setEmoji({ name: "TuZhi_Utility_UnTick", id: "1433864956226572370" });

        // 🔴 FIX: Wrap buttons in ActionRowBuilder
        const buttonRow = new ActionRowBuilder()
            .addComponents(addButton, cancelButton);

        const response = await interaction.reply({
            components: [container, buttonRow],
            flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral
        });

        const collector = response.createMessageComponentCollector({ 
            time: 60000,
            filter: i => i.user.id === interaction.user.id
        });

        collector.on('collect', async i => {
            if (i.customId === 'emoji_cancel') {
                const cancelContainer = this.buildMessageContainer(
                    "Cancelled",
                    "Emoji addition has been cancelled.",
                    0xFE8200,
                    "<:TuZhi_Utility_UnTick:1433864956226572370>"
                );

                await i.update({
                    components: [cancelContainer],
                    flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral
                });

                collector.stop();
                return;
            }

            if (i.customId.startsWith('emoji_add_')) {
                await i.deferUpdate();

                try {
                    const emoji = await guild.emojis.create({
                        attachment: emojiData.url,
                        name: finalName,
                        reason: `Added by ${interaction.user.tag}`
                    });

                    const successHeader = new TextDisplayBuilder().setContent(
                        `<:TuZhi_Utility_Tick:1433864870775885897> **Emoji Added Successfully!**`
                    );

                    const successDetails = new TextDisplayBuilder().setContent(
                        `<:TuZhi_Utility_EmojiPlus:1433853283545518324> **Emoji:** ${emoji}\n` +
                        `<:TuZhi_Utility_Repaire:1433853017911857236> **Name:** \`${emoji.name}\`\n` +
                        `<:TuZhi_Utility_save:1433851972435316756> **ID:** \`${emoji.id}\``
                    );

                    const successFooter = new TextDisplayBuilder().setContent(
                        `<:TuZhi_Utility_User:1433852028207104145> **Added by:** ${interaction.user}`
                    );

                    const successContainer = new ContainerBuilder()
                        .setAccentColor(0xFE8200)
                        .addTextDisplayComponents(successHeader)
                        .addSeparatorComponents(new SeparatorBuilder())
                        .addTextDisplayComponents(successDetails)
                        .addSeparatorComponents(new SeparatorBuilder())
                        .addTextDisplayComponents(successFooter);

                    await i.editReply({
                        components: [successContainer],
                        flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral
                    });

                } catch (error) {
                    let errorMsg = "Failed to add emoji. Please try again.";
                    
                    if (error.code === 30008) {
                        errorMsg = "This server has reached the maximum number of emojis!";
                    } else if (error.code === 50035) {
                        errorMsg = "Invalid emoji name or format!";
                    } else if (error.code === 50013) {
                        errorMsg = "I don't have permission to manage emojis!";
                    }

                    const errorContainer = this.buildMessageContainer(
                        "Error",
                        errorMsg,
                        0xFE8200,
                        "<:TuZhi_Utility_UnTick:1433864956226572370>"
                    );

                    await i.editReply({
                        components: [errorContainer],
                        flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral
                    });
                }

                collector.stop();
            }
        });

        collector.on('end', async (collected, reason) => {
            if (reason === 'time') {
                const timeoutContainer = this.buildMessageContainer(
                    "Timeout",
                    "Emoji addition timed out. Please try again.",
                    0xFE8200,
                    "<:TuZhi_Utility_Cooldown:1433852369799745761>"
                );

                await interaction.editReply({
                    components: [timeoutContainer],
                    flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral
                }).catch(() => {});
            }
        });
    },

    // 🟠 Show Confirmation (Prefix)
    async showConfirmationPrefix(message, emojiData, finalName, guild) {
        const header = new TextDisplayBuilder().setContent(
            `<:TuZhi_Utility_EmojiPlus:1433853283545518324> **Add Emoji Confirmation**`
        );

        const details = new TextDisplayBuilder().setContent(
            `<:TuZhi_Utility_Two_Arrow:1433864767570706605> **Emoji:** ${emojiData.animated ? '<a:' : '<:'}${emojiData.name}:${emojiData.id}>\n` +
            `<:TuZhi_Utility_Repaire:1433853017911857236> **Name:** \`${finalName}\`\n` +
            `<:TuZhi_Utility_Fire:1433856226441170944> **Type:** ${emojiData.animated ? 'Animated' : 'Static'}`
        );

        const footer = new TextDisplayBuilder().setContent(
            `<:TuZhi_Utility_User:1433852028207104145> **Requested by:** ${message.author}`
        );

        const container = new ContainerBuilder()
            .setAccentColor(0xFE8200)
            .addTextDisplayComponents(header)
            .addSeparatorComponents(new SeparatorBuilder())
            .addTextDisplayComponents(details)
            .addSeparatorComponents(new SeparatorBuilder())
            .addTextDisplayComponents(footer);

        const addButton = new ButtonBuilder()
            .setCustomId(`emoji_add_${emojiData.id}_${finalName}`)
            .setLabel("Add Emoji")
            .setStyle(ButtonStyle.Primary)
            .setEmoji({ name: "TuZhi_Utility_Tick", id: "1433864870775885897" });

        const cancelButton = new ButtonBuilder()
            .setCustomId(`emoji_cancel`)
            .setLabel("Cancel")
            .setStyle(ButtonStyle.Secondary)
            .setEmoji({ name: "TuZhi_Utility_UnTick", id: "1433864956226572370" });

        // 🔴 FIX: Wrap buttons in ActionRowBuilder
        const buttonRow = new ActionRowBuilder()
            .addComponents(addButton, cancelButton);

        const response = await message.reply({
            components: [container, buttonRow],
            flags: MessageFlags.IsComponentsV2
        });

        const collector = response.createMessageComponentCollector({ 
            time: 60000,
            filter: i => i.user.id === message.author.id
        });

        collector.on('collect', async i => {
            if (i.customId === 'emoji_cancel') {
                const cancelContainer = this.buildMessageContainer(
                    "Cancelled",
                    "Emoji addition has been cancelled.",
                    0xFE8200,
                    "<:TuZhi_Utility_UnTick:1433864956226572370>"
                );

                await i.update({
                    components: [cancelContainer],
                    flags: MessageFlags.IsComponentsV2
                });

                setTimeout(() => response.delete().catch(() => {}), 10000);
                collector.stop();
                return;
            }

            if (i.customId.startsWith('emoji_add_')) {
                await i.deferUpdate();

                try {
                    const emoji = await guild.emojis.create({
                        attachment: emojiData.url,
                        name: finalName,
                        reason: `Added by ${message.author.tag}`
                    });

                    const successHeader = new TextDisplayBuilder().setContent(
                        `<:TuZhi_Utility_Tick:1433864870775885897> **Emoji Added Successfully!**`
                    );

                    const successDetails = new TextDisplayBuilder().setContent(
                        `<:TuZhi_Utility_EmojiPlus:1433853283545518324> **Emoji:** ${emoji}\n` +
                        `<:TuZhi_Utility_Repaire:1433853017911857236> **Name:** \`${emoji.name}\`\n` +
                        `<:TuZhi_Utility_save:1433851972435316756> **ID:** \`${emoji.id}\``
                    );

                    const successFooter = new TextDisplayBuilder().setContent(
                        `<:TuZhi_Utility_User:1433852028207104145> **Added by:** ${message.author}`
                    );

                    const successContainer = new ContainerBuilder()
                        .setAccentColor(0xFE8200)
                        .addTextDisplayComponents(successHeader)
                        .addSeparatorComponents(new SeparatorBuilder())
                        .addTextDisplayComponents(successDetails)
                        .addSeparatorComponents(new SeparatorBuilder())
                        .addTextDisplayComponents(successFooter);

                    await i.editReply({
                        components: [successContainer],
                        flags: MessageFlags.IsComponentsV2
                    });

                } catch (error) {
                    let errorMsg = "Failed to add emoji. Please try again.";
                    
                    if (error.code === 30008) {
                        errorMsg = "This server has reached the maximum number of emojis!";
                    } else if (error.code === 50035) {
                        errorMsg = "Invalid emoji name or format!";
                    } else if (error.code === 50013) {
                        errorMsg = "I don't have permission to manage emojis!";
                    }

                    const errorContainer = this.buildMessageContainer(
                        "Error",
                        errorMsg,
                        0xFE8200,
                        "<:TuZhi_Utility_UnTick:1433864956226572370>"
                    );

                    await i.editReply({
                        components: [errorContainer],
                        flags: MessageFlags.IsComponentsV2
                    });

                    setTimeout(() => response.delete().catch(() => {}), 10000);
                }

                collector.stop();
            }
        });

        collector.on('end', async (collected, reason) => {
            if (reason === 'time') {
                const timeoutContainer = this.buildMessageContainer(
                    "Timeout",
                    "Emoji addition timed out. Please try again.",
                    0xFE8200,
                    "<:TuZhi_Utility_Cooldown:1433852369799745761>"
                );

                await response.edit({
                    components: [timeoutContainer],
                    flags: MessageFlags.IsComponentsV2
                }).catch(() => {});

                setTimeout(() => response.delete().catch(() => {}), 10000);
            }
        });
    }
};