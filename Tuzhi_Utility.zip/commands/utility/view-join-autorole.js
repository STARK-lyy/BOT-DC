import { SlashCommandBuilder, EmbedBuilder } from "discord.js";
import fs from "fs";
import path from "path";

const dataPath = path.join(process.cwd(), "data", "utility", "joinAutorole.json");

function loadData() {
    try {
        if (!fs.existsSync(dataPath)) return {};
        return JSON.parse(fs.readFileSync(dataPath, "utf-8"));
    } catch (error) {
        console.error("Error loading join autorole data:", error);
        return {};
    }
}

export default {
    data: new SlashCommandBuilder()
        .setName("view-join-autorole")
        .setDescription("View all roles configured for automatic assignment")
        .setDMPermission(false),

    async execute(interaction) {
        await interaction.deferReply({ ephemeral: true });

        const data = loadData();

        if (!data[interaction.guild.id] || !data[interaction.guild.id].roles || data[interaction.guild.id].roles.length === 0) {
            const embed = new EmbedBuilder()
                .setColor("#fe8200")
                .setTitle("<:TuZhi_Utility_Search:1433861958108581910> Join Auto-Role Status")
                .setDescription("<:TuZhi_Utility_UnTick:1433864956226572370> No auto-roles are currently configured for this server.\n\nUse `/add-join-autorole` to set up automatic role assignment for new members.")
                .setTimestamp();

            return interaction.editReply({ embeds: [embed] });
        }

        const roleIds = data[interaction.guild.id].roles;
        const validRoles = [];
        const invalidRoles = [];

        for (const roleId of roleIds) {
            const role = interaction.guild.roles.cache.get(roleId);
            if (role) {
                validRoles.push(role);
            } else {
                invalidRoles.push(roleId);
            }
        }

        const embed = new EmbedBuilder()
            .setColor("#fe8200")
            .setTitle("<:management:1433852743948439593> Join Auto-Role Configuration")
            .setDescription("<:TuZhi_Utility_Tick:1433864870775885897> **Status:** Active\n\nNew members will automatically receive the following roles upon joining:")
            .setTimestamp()
            .setFooter({ text: `Total: ${validRoles.length} active role(s)` });

        if (validRoles.length > 0) {
            const roleList = validRoles.map((role, index) => 
                `\`${index + 1}.\` <@&${role.id}> • ${role.members.size} members`
            ).join("\n");

            embed.addFields({
                name: "<:TuZhi_Utility_like:1433851565608800347> Active Roles:",
                value: roleList.length > 1024 ? roleList.substring(0, 1021) + "..." : roleList
            });
        }

        if (invalidRoles.length > 0) {
            embed.addFields({
                name: "<:TuZhi_Utility_dislike:1433851889908191348> Invalid Roles (Deleted):",
                value: invalidRoles.map(id => `<@&${id}>`).join(", ").substring(0, 1024)
            });

            embed.addFields({
                name: "<:TuZhi_Utility_Repaire:1433853017911857236> Recommendation:",
                value: "Use `/remove-join-autorole` to clean up deleted roles."
            });
        }

        // Add bot role position info
        const botRole = interaction.guild.members.me.roles.highest;
        embed.addFields({
            name: "<:TuZhi_Utility_Setting:1433855987626020925> Bot Info:",
            value: `Highest Role: <@&${botRole.id}>\nPosition: ${botRole.position}`
        });

        await interaction.editReply({ embeds: [embed] });
    }
};