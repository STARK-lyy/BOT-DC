import { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } from "discord.js";
import fs from "fs";
import path from "path";

const dataPath = path.join(process.cwd(), "data", "utility", "joinAutorole.json");

function loadData() {
    try {
        if (!fs.existsSync(dataPath)) return {};
        return JSON.parse(fs.readFileSync(dataPath, "utf-8"));
    } catch (error) {
        console.error("Error loading join autorole data:", error);
        return {};
    }
}

function saveData(data) {
    try {
        const dir = path.dirname(dataPath);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
        fs.writeFileSync(dataPath, JSON.stringify(data, null, 4));
    } catch (error) {
        console.error("Error saving join autorole data:", error);
    }
}

export default {
    data: new SlashCommandBuilder()
        .setName("remove-join-autorole")
        .setDescription("Remove roles from auto-assignment or disable the system entirely")
        .addStringOption(option =>
            option
                .setName("action")
                .setDescription("Choose action")
                .setRequired(true)
                .addChoices(
                    { name: "Remove Specific Roles", value: "specific" },
                    { name: "Disable All Auto-Roles", value: "all" }
                )
        )
        .addStringOption(option =>
            option
                .setName("roles")
                .setDescription("Mention roles to remove (only for 'Remove Specific Roles')")
                .setRequired(false)
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .setDMPermission(false),

    async execute(interaction) {
        await interaction.deferReply({ ephemeral: true });

        // Check if user is server owner or admin
        if (interaction.user.id !== interaction.guild.ownerId && 
            !interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
            const errorEmbed = new EmbedBuilder()
                .setColor("#fe8200")
                .setDescription("<:TuZhi_Utility_UnTick:1433864956226572370> Only the server owner or administrators can use this command!");
            return interaction.editReply({ embeds: [errorEmbed] });
        }

        const action = interaction.options.getString("action");
        const data = loadData();

        if (!data[interaction.guild.id] || !data[interaction.guild.id].roles || data[interaction.guild.id].roles.length === 0) {
            const errorEmbed = new EmbedBuilder()
                .setColor("#fe8200")
                .setDescription("<:TuZhi_Utility_UnTick:1433864956226572370> No auto-roles are currently configured for this server!");
            return interaction.editReply({ embeds: [errorEmbed] });
        }

        if (action === "all") {
            const removedCount = data[interaction.guild.id].roles.length;
            delete data[interaction.guild.id];
            saveData(data);

            const embed = new EmbedBuilder()
                .setColor("#fe8200")
                .setTitle("<:TuZhi_Utility_Tick:1433864870775885897> Auto-Role System Disabled")
                .setDescription(`Successfully removed **${removedCount}** auto-role(s) from the system.\n\nNew members will no longer receive automatic roles.`)
                .setTimestamp();

            return interaction.editReply({ embeds: [embed] });
        }

        if (action === "specific") {
            const rolesInput = interaction.options.getString("roles");
            
            if (!rolesInput) {
                const errorEmbed = new EmbedBuilder()
                    .setColor("#fe8200")
                    .setDescription("<:TuZhi_Utility_UnTick:1433864956226572370> Please provide roles to remove!");
                return interaction.editReply({ embeds: [errorEmbed] });
            }

            // Extract role IDs
            const roleIds = [];
            const rolePattern = /<@&(\d+)>/g;
            let match;
            
            while ((match = rolePattern.exec(rolesInput)) !== null) {
                roleIds.push(match[1]);
            }

            const parts = rolesInput.split(/[,\s]+/);
            for (const part of parts) {
                const cleanId = part.replace(/[<@&>]/g, "");
                if (/^\d+$/.test(cleanId) && !roleIds.includes(cleanId)) {
                    roleIds.push(cleanId);
                }
            }

            if (roleIds.length === 0) {
                const errorEmbed = new EmbedBuilder()
                    .setColor("#fe8200")
                    .setDescription("<:TuZhi_Utility_UnTick:1433864956226572370> No valid roles found! Please mention roles properly.");
                return interaction.editReply({ embeds: [errorEmbed] });
            }

            const currentRoles = data[interaction.guild.id].roles;
            const removedRoles = [];
            const notFoundRoles = [];

            for (const roleId of roleIds) {
                if (currentRoles.includes(roleId)) {
                    currentRoles.splice(currentRoles.indexOf(roleId), 1);
                    removedRoles.push(roleId);
                } else {
                    notFoundRoles.push(roleId);
                }
            }

            if (removedRoles.length === 0) {
                const errorEmbed = new EmbedBuilder()
                    .setColor("#fe8200")
                    .setDescription("<:TuZhi_Utility_UnTick:1433864956226572370> None of the provided roles were in the auto-role list!");
                return interaction.editReply({ embeds: [errorEmbed] });
            }

            data[interaction.guild.id].roles = currentRoles;
            
            if (currentRoles.length === 0) {
                delete data[interaction.guild.id];
            }
            
            saveData(data);

            const embed = new EmbedBuilder()
                .setColor("#fe8200")
                .setTitle("<:TuZhi_Utility_Tick:1433864870775885897> Auto-Roles Removed")
                .setTimestamp();

            if (removedRoles.length > 0) {
                embed.addFields({
                    name: "<:TuZhi_Utility_Delete:1433864232910196856> Removed Roles:",
                    value: removedRoles.map(r => `<@&${r}>`).join(", ")
                });
            }

            if (notFoundRoles.length > 0) {
                embed.addFields({
                    name: "<:TuZhi_Utility_Search:1433861958108581910> Not Found:",
                    value: notFoundRoles.map(r => `<@&${r}>`).join(", ")
                });
            }

            embed.addFields({
                name: "<:TuZhi_Utility_Users:1433852173430558910> Remaining Roles:",
                value: currentRoles.length > 0 ? `${currentRoles.length} role(s)` : "None (System Disabled)"
            });

            await interaction.editReply({ embeds: [embed] });
        }
    }
};