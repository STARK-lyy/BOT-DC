import { SlashCommandBuilder, EmbedBuilder } from "discord.js";

export default {
    data: new SlashCommandBuilder()
        .setName("say")
        .setDescription("Say something as bot")
        .addStringOption(opt =>
            opt.setName("embed")
                .setDescription("Embed on/off")
                .setRequired(true)
                .addChoices(
                    { name: "on", value: "on" },
                    { name: "off", value: "off" }
                )
        )
        .addStringOption(opt =>
            opt.setName("message")
                .setDescription("Message to send")
                .setRequired(true)
        ),

    // ✅ Slash Command
    async execute(interaction) {
        const embedChoice = interaction.options.getString("embed");
        const msg = interaction.options.getString("message");

        // Success ephemeral message
        await interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor("Green")
                    .setDescription("✅ Message sent successfully!")
            ],
            ephemeral: true
        });

        if (embedChoice === "on") {
            const embed = new EmbedBuilder()
                .setColor("#ff0000")
                .setDescription(msg);
            await interaction.channel.send({
                embeds: [embed],
                allowedMentions: { parse: [] }
            });
        } else {
            await interaction.channel.send({
                content: msg,
                allowedMentions: { parse: [] }
            });
        }
    },

    // ✅ Prefix version → only text
    async runPrefix(message, args) {
        if (!args.length) return message.reply("❌ Provide a message!");
        const msg = args.join(" ");

        await message.channel.send({
            content: msg,
            allowedMentions: { parse: [] } // no pings
        });
    }
};