import { 
    SlashCommandBuilder,
    TextDisplayBuilder,
    ContainerBuilder,
    SeparatorBuilder,
    MessageFlags
} from "discord.js";

const cooldowns = new Map();

export default {
    data: new SlashCommandBuilder()
        .setName("serverinfo")
        .setDescription("Shows detailed information about this server"),

    cooldown: 5,
    aliases: ["si"],

    async execute(interaction) {
        const userId = interaction.user.id;
        
        // Cooldown check
        if (cooldowns.has(userId)) {
            const expirationTime = cooldowns.get(userId);
            const timeLeft = (expirationTime - Date.now()) / 1000;
            
            if (timeLeft > 0) {
                const reply = await interaction.reply({ 
                    content: `<:TuZhi_Utility_Cooldown:1433852369799745761> **Slow down!** Try again <t:${Math.floor(expirationTime / 1000)}:R>`, 
                    ephemeral: true 
                });
                setTimeout(() => reply.delete().catch(() => {}), 10000);
                return;
            }
        }

        cooldowns.set(userId, Date.now() + 5000);
        setTimeout(() => cooldowns.delete(userId), 5000);

        const guild = interaction.guild;
        if (!guild) {
            return interaction.reply({ 
                content: "<:TuZhi_Utility_UnTick:1433864956226572370> Guild not found.", 
                ephemeral: true 
            });
        }

        const owner = await guild.fetchOwner().catch(() => null);

        // Server description
        const description = guild.description 
            ? guild.description.substring(0, 80) 
            : "No Description Set For This Server";

        // Member stats
        const bots = guild.members.cache.filter(m => m.user.bot).size;
        const humans = guild.memberCount - bots;

        // Role stats
        const dangerousRoles = guild.roles.cache.filter(r => 
            r.permissions.has("Administrator") || 
            r.permissions.has("BanMembers") ||
            r.permissions.has("KickMembers")
        ).size;
        const managedRoles = guild.roles.cache.filter(r => r.managed).size;

        // Channel stats
        const textChannels = guild.channels.cache.filter(c => c.type === 0).size;
        const voiceChannels = guild.channels.cache.filter(c => c.type === 2).size;
        const categories = guild.channels.cache.filter(c => c.type === 4).size;
        const stageChannels = guild.channels.cache.filter(c => c.type === 13).size;
        const forumChannels = guild.channels.cache.filter(c => c.type === 15).size;

        // Boost info
        const boostLevel = guild.premiumTier;
        const boostCount = guild.premiumSubscriptionCount || 0;

        // Timestamps
        const createdTimestamp = Math.floor(guild.createdTimestamp / 1000);

        // Ban count
        let banCount = 0;
        try {
            const bans = await guild.bans.fetch();
            banCount = bans.size;
        } catch (e) {
            banCount = 0;
        }

        // Verification level
        const verificationLevels = {
            0: "None",
            1: "Low",
            2: "Medium", 
            3: "High",
            4: "Very High"
        };
        const verificationLevel = verificationLevels[guild.verificationLevel] || "Unknown";

        // Server features
        const features = guild.features.length > 0 
            ? guild.features.slice(0, 3).map(f => f.replace(/_/g, ' ')).join(", ")
            : "No Special Features";

        // Title Section
        const titleText = new TextDisplayBuilder().setContent(
            `<:TuZhi_Utility:1434040425760428103> Welcome To **${guild.name}** InfoBoard <:TuZhi_Utility:1434040425760428103>`
        );

        // Main Information Section
        const mainInfoText = new TextDisplayBuilder().setContent(
            `**${description}**\n\n` +
            `<:TuZhi_Utility_User:1433852028207104145> **Server Owner**\n` +
            `> Owner: ${owner ? `<@${owner.id}>` : "Unknown"}\n` +
            `> Server ID: \`${guild.id}\`\n` +
            `> Created: <t:${createdTimestamp}:R>\n\n` +
            
            `<:TuZhi_Utility_Users:1433852173430558910> **Members & Roles**\n` +
            `> Total Members: ${guild.memberCount}\n` +
            `> Humans: ${humans}\n` +
            `> Bots: ${bots}\n` +
            `> Total Roles: ${guild.roles.cache.size}\n\n` +
            
            `<:TuZhi_Utility_Boost:1433861701232492614> **Boost Status**\n` +
            `> Boost Level: ${boostLevel}\n` +
            `> Boost Count: ${boostCount}\n` +
            `> AFK Timeout: ${guild.afkTimeout || 0} seconds\n\n` +
            
            `<:TuZhi_Utility_Chatting:1433851392820383806> **Channels**\n` +
            `> Text Channels: ${textChannels}\n` +
            `> Voice Channels: ${voiceChannels}\n` +
            `> Categories: ${categories}\n` +
            `> Stage Channels: ${stageChannels}\n` +
            `> Forum Channels: ${forumChannels}\n\n` +
            
            `<:TuZhi_Utility_Secured:1433861508328329349> **Security & Moderation**\n` +
            `> Verification Level: ${verificationLevel}\n` +
            `> Dangerous Roles: ${dangerousRoles}\n` +
            `> Managed Roles: ${managedRoles}\n` +
            `> Total Banned: ${banCount}\n\n` +
            
            `<:TuZhi_Utility_Setting:1433855987626020925> **Additional Info**\n` +
            `> Features: ${features}\n` +
            `> Emoji Count: ${guild.emojis.cache.size}\n` +
            `> Sticker Count: ${guild.stickers.cache.size}`
        );

        // Footer Section
        const footerText = new TextDisplayBuilder().setContent(
            `<:TuZhi_Utility_Heart:1433852435973144636> **Thanks For Using TuZhi Utility!** <:TuZhi_Utility_Heart:1433852435973144636>`
        );

        // Build Container
        const container = new ContainerBuilder()
            .setAccentColor(0xFE8200)
            .addTextDisplayComponents(titleText)
            .addSeparatorComponents(s => s)
            .addTextDisplayComponents(mainInfoText)
            .addSeparatorComponents(s => s)
            .addTextDisplayComponents(footerText);

        // Send reply
        await interaction.reply({
            components: [container],
            flags: MessageFlags.IsComponentsV2
        });
    },

    async runPrefix(message, args) {
        const userId = message.author.id;
        
        // Cooldown check
        if (cooldowns.has(userId)) {
            const expirationTime = cooldowns.get(userId);
            const timeLeft = (expirationTime - Date.now()) / 1000;
            
            if (timeLeft > 0) {
                const reply = await message.reply(
                    `<:TuZhi_Utility_Cooldown:1433852369799745761> **Slow down!** Try again in ${timeLeft.toFixed(1)}s`
                );
                setTimeout(() => reply.delete().catch(() => {}), 10000);
                return;
            }
        }

        cooldowns.set(userId, Date.now() + 5000);
        setTimeout(() => cooldowns.delete(userId), 5000);

        const guild = message.guild;
        if (!guild) {
            return message.reply("<:TuZhi_Utility_UnTick:1433864956226572370> Guild not found.");
        }

        const owner = await guild.fetchOwner().catch(() => null);

        // Server description
        const description = guild.description 
            ? guild.description.substring(0, 80) 
            : "No Description Set For This Server";

        // Member stats
        const bots = guild.members.cache.filter(m => m.user.bot).size;
        const humans = guild.memberCount - bots;

        // Role stats
        const dangerousRoles = guild.roles.cache.filter(r => 
            r.permissions.has("Administrator") || 
            r.permissions.has("BanMembers") ||
            r.permissions.has("KickMembers")
        ).size;
        const managedRoles = guild.roles.cache.filter(r => r.managed).size;

        // Channel stats
        const textChannels = guild.channels.cache.filter(c => c.type === 0).size;
        const voiceChannels = guild.channels.cache.filter(c => c.type === 2).size;
        const categories = guild.channels.cache.filter(c => c.type === 4).size;
        const stageChannels = guild.channels.cache.filter(c => c.type === 13).size;
        const forumChannels = guild.channels.cache.filter(c => c.type === 15).size;

        // Boost info
        const boostLevel = guild.premiumTier;
        const boostCount = guild.premiumSubscriptionCount || 0;

        // Timestamps
        const createdTimestamp = Math.floor(guild.createdTimestamp / 1000);

        // Ban count
        let banCount = 0;
        try {
            const bans = await guild.bans.fetch();
            banCount = bans.size;
        } catch (e) {
            banCount = 0;
        }

        // Verification level
        const verificationLevels = {
            0: "None",
            1: "Low",
            2: "Medium",
            3: "High",
            4: "Very High"
        };
        const verificationLevel = verificationLevels[guild.verificationLevel] || "Unknown";

        // Server features
        const features = guild.features.length > 0 
            ? guild.features.slice(0, 3).map(f => f.replace(/_/g, ' ')).join(", ")
            : "No Special Features";

        // Title Section
        const titleText = new TextDisplayBuilder().setContent(
            `<:TuZhi_Utility:1434040425760428103> Welcome To **${guild.name}** InfoBoard <:TuZhi_Utility:1434040425760428103>`
        );

        // Main Information Section
        const mainInfoText = new TextDisplayBuilder().setContent(
            `**${description}**\n\n` +
            `<:TuZhi_Utility_User:1433852028207104145> **Server Owner**\n` +
            `> Owner: ${owner ? `<@${owner.id}>` : "Unknown"}\n` +
            `> Server ID: \`${guild.id}\`\n` +
            `> Created: <t:${createdTimestamp}:R>\n\n` +
            
            `<:TuZhi_Utility_Users:1433852173430558910> **Members & Roles**\n` +
            `> Total Members: ${guild.memberCount}\n` +
            `> Humans: ${humans}\n` +
            `> Bots: ${bots}\n` +
            `> Total Roles: ${guild.roles.cache.size}\n\n` +
            
            `<:TuZhi_Utility_Boost:1433861701232492614> **Boost Status**\n` +
            `> Boost Level: ${boostLevel}\n` +
            `> Boost Count: ${boostCount}\n` +
            `> AFK Timeout: ${guild.afkTimeout || 0} seconds\n\n` +
            
            `<:TuZhi_Utility_Chatting:1433851392820383806> **Channels**\n` +
            `> Text Channels: ${textChannels}\n` +
            `> Voice Channels: ${voiceChannels}\n` +
            `> Categories: ${categories}\n` +
            `> Stage Channels: ${stageChannels}\n` +
            `> Forum Channels: ${forumChannels}\n\n` +
            
            `<:TuZhi_Utility_Secured:1433861508328329349> **Security & Moderation**\n` +
            `> Verification Level: ${verificationLevel}\n` +
            `> Dangerous Roles: ${dangerousRoles}\n` +
            `> Managed Roles: ${managedRoles}\n` +
            `> Total Banned: ${banCount}\n\n` +
            
            `<:TuZhi_Utility_Setting:1433855987626020925> **Additional Info**\n` +
            `> Features: ${features}\n` +
            `> Emoji Count: ${guild.emojis.cache.size}\n` +
            `> Sticker Count: ${guild.stickers.cache.size}`
        );

        // Footer Section
        const footerText = new TextDisplayBuilder().setContent(
            `<:TuZhi_Utility_Heart:1433852435973144636> **Thanks For Using TuZhi Utility!** <:TuZhi_Utility_Heart:1433852435973144636>`
        );

        // Build Container
        const container = new ContainerBuilder()
            .setAccentColor(0xFE8200)
            .addTextDisplayComponents(titleText)
            .addSeparatorComponents(s => s)
            .addTextDisplayComponents(mainInfoText)
            .addSeparatorComponents(s => s)
            .addTextDisplayComponents(footerText);

        // Send reply
        await message.channel.send({
            components: [container],
            flags: MessageFlags.IsComponentsV2
        });
    }
};