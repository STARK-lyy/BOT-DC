import {
    SlashCommandBuilder,
    TextDisplayBuilder,
    ContainerBuilder,
    SeparatorBuilder,
    MessageFlags,
    PermissionFlagsBits
} from "discord.js";

const cooldowns = new Map();

export default {
    data: new SlashCommandBuilder()
        .setName("emojis-list")
        .setDescription("Show all emojis of this server (Admin Only)")
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    cooldown: 5,

    async execute(interaction) {
        const userId = interaction.user.id;

        // 🟠 Utility Function - Styled Error/Warning/Info Containers
        const buildMessageContainer = (title, message, color, emoji) => {
            const header = new TextDisplayBuilder().setContent(`${emoji} **${title}**`);
            const body = new TextDisplayBuilder().setContent(`> ${message}`);
            return new ContainerBuilder()
                .setAccentColor(color)
                .addTextDisplayComponents(header)
                .addSeparatorComponents(new SeparatorBuilder())
                .addTextDisplayComponents(body);
        };

        // 🟠 Cooldown Check
        if (cooldowns.has(userId)) {
            const expirationTime = cooldowns.get(userId);
            const timeLeft = (expirationTime - Date.now()) / 1000;

            if (timeLeft > 0) {
                const cooldownContainer = buildMessageContainer(
                    "Slow Down",
                    `You can use this command again <t:${Math.floor(expirationTime / 1000)}:R>`,
                    0xFE8200,
                    "<:TuZhi_Utility_Cooldown:1433852369799745761>"
                );

                const reply = await interaction.reply({
                    components: [cooldownContainer],
                    flags: MessageFlags.IsComponentsV2
                });

                setTimeout(() => reply.delete().catch(() => {}), 10000);
                return;
            }
        }

        cooldowns.set(userId, Date.now() + 5000);
        setTimeout(() => cooldowns.delete(userId), 5000);

        const guild = interaction.guild;
        if (!guild) {
            const errorContainer = buildMessageContainer(
                "Error",
                "Guild not found or interaction not from a server.",
                0xFE8200,
                "<:TuZhi_Utility_UnTick:1433864956226572370>"
            );

            const reply = await interaction.reply({
                components: [errorContainer],
                flags: MessageFlags.IsComponentsV2
            });

            setTimeout(() => reply.delete().catch(() => {}), 10000);
            return;
        }

        // 🟠 Permission Check
        if (
            !interaction.member.permissions.has(PermissionFlagsBits.ManageGuild) &&
            guild.ownerId !== userId
        ) {
            const warnContainer = buildMessageContainer(
                "Warn",
                "Only **Server Admins or Owner** can use this command!",
                0xFE8200,
                "<:TuZhi_Utility_Winn:1433861769528479794>"
            );

            const reply = await interaction.reply({
                components: [warnContainer],
                flags: MessageFlags.IsComponentsV2
            });

            setTimeout(() => reply.delete().catch(() => {}), 10000);
            return;
        }

        // 🟠 Fetch Emojis
        const emojis = guild.emojis.cache;
        if (!emojis.size) {
            const warnContainer = buildMessageContainer(
                "Warn",
                "This server has no custom emojis!",
                0xFE8200,
                "<:TuZhi_Utility_Confused:1433865082193842349>"
            );

            const reply = await interaction.reply({
                components: [warnContainer],
                flags: MessageFlags.IsComponentsV2
            });

            setTimeout(() => reply.delete().catch(() => {}), 10000);
            return;
        }

        // 🟠 Emoji List Display
        const emojiText =
            emojis.map(e => `${e}`).join(" ")?.substring(0, 3500) || "No Emojis Found";

        // Header Section
        const header = new TextDisplayBuilder().setContent(
            `<:TuZhi_Utility:1434040425760428103> **${guild.name}** Emoji Pack <:TuZhi_Utility:1434040425760428103>\n` +
            `<:TuZhi_Utility_EmojiPlus:1433853283545518324> **Total Emojis:** ${emojis.size}`
        );

        // Emoji Section
        const emojiDisplay = new TextDisplayBuilder().setContent(
            `<:TuZhi_Utility_Two_Arrow:1433864767570706605> **All Emojis:**\n${emojiText}`
        );

        // Footer Section
        const footer = new TextDisplayBuilder().setContent(
            `<:TuZhi_Utility_Tick:1433864870775885897> **Requested by:** ${interaction.user}`
        );

        // Final Container
        const container = new ContainerBuilder()
            .setAccentColor(0xFE8200)
            .addTextDisplayComponents(header)
            .addSeparatorComponents(new SeparatorBuilder())
            .addTextDisplayComponents(emojiDisplay)
            .addSeparatorComponents(new SeparatorBuilder())
            .addTextDisplayComponents(footer);

        // 🟠 Final Reply (not ephemeral, not deleted)
        await interaction.reply({
            components: [container],
            flags: MessageFlags.IsComponentsV2
        });
    }
};