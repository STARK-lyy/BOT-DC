import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';

const cooldowns = new Map();

// --- 1. Helper Function: URL Validation and Formatting ---
function formatUrl(inputUrl) {
    let url = inputUrl.trim();
    
    // Remove any markdown or extra characters
    url = url.replace(/[<>]/g, '');
    
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
        url = `https://${url}`;
    }
    return url;
}

function isValidUrl(url) {
    try {
        const urlObj = new URL(url);
        return urlObj.protocol === 'http:' || urlObj.protocol === 'https:';
    } catch (e) {
        return false;
    }
}

// Advanced URL/Domain Detection
function isLikelyURL(input) {
    if (!input) return false;
    
    const str = input.trim().toLowerCase();
    
    // Already has protocol
    if (str.startsWith('http://') || str.startsWith('https://')) {
        return true;
    }
    
    // Common domain patterns
    const domainPatterns = [
        /^[a-z0-9-]+\.[a-z]{2,}$/i,           // example.com
        /^www\.[a-z0-9-]+\.[a-z]{2,}/i,       // www.example.com
        /^[a-z0-9-]+\.[a-z0-9-]+\.[a-z]{2,}/i, // sub.example.com
        /\.(com|org|net|edu|gov|mil|co|io|xyz|app|dev|me|tech|store|online|site|website|blog|info|tv|cc|in|uk|us|ca|de|fr|jp|cn|ru|br|au)\b/i
    ];
    
    // Check if matches any domain pattern
    for (const pattern of domainPatterns) {
        if (pattern.test(str)) {
            return true;
        }
    }
    
    // Contains dot and valid characters (simple domain check)
    if (/^[a-z0-9.-]+\.[a-z]{2,}$/i.test(str)) {
        return true;
    }
    
    return false;
}

function getInvalidInputMessage(input) {
    const examples = [
        '`google.com`',
        '`https://discord.com`',
        '`github.com`',
        '`youtube.com`'
    ];
    
    return new EmbedBuilder()
        .setColor(0xFF0000)
        .setAuthor({
            name: 'Invalid URL Format',
            iconURL: 'https://cdn.discordapp.com/emojis/1433864956226572370.png'
        })
        .setDescription(
            `<:TuZhi_Utility_UnTick:1433864956226572370> **The input provided is not a valid URL or domain.**\n\n` +
            `**You provided:** \`${input}\`\n\n` +
            `<:TuZhi_Utility_Links:1433871554323939348> **Valid Examples:**\n` +
            examples.map(e => `> ${e}`).join('\n') + '\n\n' +
            `<:TuZhi_Utility_Reason:1433871443082608695> **Common Issues:**\n` +
            `> • Missing domain extension (.com, .net, etc.)\n` +
            `> • Typos in the URL\n` +
            `> • Invalid characters\n` +
            `> • Not a website URL`
        )
        .setFooter({ 
            text: 'Please provide a valid website URL or domain',
            iconURL: 'https://cdn.discordapp.com/emojis/1433852369799745761.png'
        })
        .setTimestamp();
}

// --- 2. Multiple API Endpoints (Fallback System) ---
function getScreenshotAPIs(url) {
    const encodedUrl = encodeURIComponent(url);
    return [
        `https://api.popcat.xyz/screenshot?url=${encodedUrl}`,
        `https://image.thum.io/get/width/1200/crop/900/maxAge/1/noanimate/${url}`,
        `https://api.apiflash.com/v1/urltoimage?access_key=demo&url=${encodedUrl}&format=png&width=1280&height=720`,
    ];
}

// --- 3. Test if API is working ---
async function testAPI(apiUrl) {
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 10000); // 10 second timeout
        
        const response = await fetch(apiUrl, {
            signal: controller.signal,
            method: 'HEAD'
        });
        
        clearTimeout(timeoutId);
        return response.ok;
    } catch (error) {
        return false;
    }
}

// --- 4. Get Working API ---
async function getWorkingAPI(url) {
    const apis = getScreenshotAPIs(url);
    
    for (const api of apis) {
        const isWorking = await testAPI(api);
        if (isWorking) {
            return api;
        }
    }
    
    // If all fail, return first one anyway
    return apis[0];
}

// --- 5. Shared Embed Creation Logic ---
function createScreenshotEmbed(rawUrl, apiUrl, client) {
    const botAvatar = client.user.displayAvatarURL(); 

    return new EmbedBuilder()
        .setColor(0xFE8200) 
        .setAuthor({
            name: `Thanx For Use TuZhi Utility!`, 
            iconURL: botAvatar,
        })
        .setDescription(
            `<:TuZhi_Utility_Search:1433861958108581910> **URL Searched:** ${rawUrl}\n`
        )
        .setImage(apiUrl) 
        .setTimestamp()
        .setFooter({ 
            text: 'Screenshot may take a moment to load',
            iconURL: botAvatar
        });
}

export default {
    data: new SlashCommandBuilder()
        .setName('wss')
        .setDescription('Takes a screenshot of a website (Web Screenshot).')
        .addStringOption(option =>
            option.setName('url')
                .setDescription('The full URL to screenshot (e.g., google.com or https://example.com)')
                .setRequired(true)
        ),
    
    cooldown: 10,
    aliases: ['web', 'screenshot', 'ss'],

    // --- 6. Slash Command Execution (/wss) ---
    async execute(interaction) {
        const client = interaction.client;
        const userId = interaction.user.id;
        
        // Cooldown Check
        if (cooldowns.has(userId)) {
            const expirationTime = cooldowns.get(userId);
            const timeLeft = (expirationTime - Date.now()) / 1000;
            
            if (timeLeft > 0) {
                return interaction.reply({ 
                    content: `<:TuZhi_Utility_Cooldown:1433852369799745761> **Slow down!** Try again <t:${Math.floor(expirationTime / 1000)}:R>`, 
                    ephemeral: true 
                });
            }
        }
        cooldowns.set(userId, Date.now() + 10000); 
        setTimeout(() => cooldowns.delete(userId), 10000);

        await interaction.deferReply();

        try {
            const rawUrl = interaction.options.getString('url');
            
            // First check if input looks like a URL at all
            if (!isLikelyURL(rawUrl)) {
                const errorEmbed = getInvalidInputMessage(rawUrl);
                return interaction.followUp({ 
                    embeds: [errorEmbed],
                    ephemeral: true 
                });
            }
            
            const formattedUrl = formatUrl(rawUrl);
            
            // Validate URL
            if (!isValidUrl(formattedUrl)) {
                const errorEmbed = getInvalidInputMessage(rawUrl);
                return interaction.followUp({ 
                    embeds: [errorEmbed],
                    ephemeral: true 
                });
            }
            
            // Get working API
            const apiUrl = await getWorkingAPI(formattedUrl);
            
            const embed = createScreenshotEmbed(rawUrl, apiUrl, client);
            
            await interaction.followUp({ embeds: [embed] });

        } catch (error) {
            console.error(`❌ Error in /wss command:`, error.message);
            
            try {
                await interaction.followUp({ 
                    content: '<:TuZhi_Utility_UnTick:1433864956226572370> An error occurred while fetching the screenshot. The website might be unavailable or blocking screenshots.', 
                    ephemeral: true 
                });
            } catch (e) {
                console.error('Failed to send error message:', e.message);
            }
        }
    },

    // --- 7. Prefix Command Execution (.wss) ---
    async runPrefix(message, args) {
        const client = message.client;
        const userId = message.author.id;
        
        // Cooldown Check
        if (cooldowns.has(userId)) {
            const expirationTime = cooldowns.get(userId);
            const timeLeft = (expirationTime - Date.now()) / 1000;
            
            if (timeLeft > 0) {
                const reply = await message.reply(
                    `<:TuZhi_Utility_Cooldown:1433852369799745761> **Slow down!** Try again in ${timeLeft.toFixed(1)}s`
                );
                setTimeout(() => reply.delete().catch(() => {}), 10000);
                return;
            }
        }
        cooldowns.set(userId, Date.now() + 10000); 
        setTimeout(() => cooldowns.delete(userId), 10000);

        const rawUrl = args[0];
        
        if (!rawUrl) {
            const helpEmbed = new EmbedBuilder()
                .setColor(0xFE8200)
                .setAuthor({
                    name: 'Website Screenshot - Help',
                    iconURL: client.user.displayAvatarURL()
                })
                .setDescription(
                    `<:TuZhi_Utility_Search:1433861958108581910> **Usage:** \`.wss <url>\`\n\n` +
                    `<:TuZhi_Utility_Links:1433871554323939348> **Examples:**\n` +
                    `> \`.wss google.com\`\n` +
                    `> \`.wss https://discord.com\`\n` +
                    `> \`.wss github.com\`\n` +
                    `> \`.wss youtube.com\``
                )
                .setFooter({ 
                    text: 'Provide a valid website URL',
                    iconURL: client.user.displayAvatarURL()
                })
                .setTimestamp();
                
            const replyMsg = await message.reply({ embeds: [helpEmbed] });
            setTimeout(() => { replyMsg.delete().catch(() => {}); }, 15000);
            return;
        }

        // Check if input looks like a URL
        if (!isLikelyURL(rawUrl)) {
            const errorEmbed = getInvalidInputMessage(rawUrl);
            const replyMsg = await message.reply({ embeds: [errorEmbed] });
            setTimeout(() => { replyMsg.delete().catch(() => {}); }, 15000);
            return;
        }

        // Send processing message
        const processingMsg = await message.reply({
            content: '<:TuZhi_Utility_Search:1433861958108581910> Capturing screenshot, please wait...'
        });

        try {
            const formattedUrl = formatUrl(rawUrl);
            
            // Validate URL
            if (!isValidUrl(formattedUrl)) {
                await processingMsg.edit({ 
                    content: null,
                    embeds: [getInvalidInputMessage(rawUrl)]
                });
                setTimeout(() => { processingMsg.delete().catch(() => {}); }, 15000);
                return;
            }
            
            // Get working API
            const apiUrl = await getWorkingAPI(formattedUrl);
            
            const embed = createScreenshotEmbed(rawUrl, apiUrl, client);
            
            await processingMsg.edit({ 
                content: null,
                embeds: [embed] 
            });

        } catch (error) {
            console.error(`❌ Error in prefix command .wss:`, error.message);
            
            try {
                await processingMsg.edit({ 
                    content: '<:TuZhi_Utility_UnTick:1433864956226572370> An error occurred while capturing the screenshot. The website might be unavailable or blocking screenshots.' 
                });
                setTimeout(() => { processingMsg.delete().catch(() => {}); }, 10000);
            } catch (e) {
                console.error('Failed to send error message:', e.message);
            }
        }
    }
};