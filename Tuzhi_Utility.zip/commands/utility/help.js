import { 
    SlashCommandBuilder, 
    EmbedBuilder, 
    ActionRowBuilder, 
    StringSelectMenuBuilder, 
    ButtonBuilder, 
    ButtonStyle 
} from "discord.js";
import fs from "fs";
import dotenv from "dotenv";

dotenv.config();

const cooldowns = new Map();

// Load configurations
function loadConfig() {
    try {
        const helpCommands = JSON.parse(fs.readFileSync("./data/helpCommands.json", "utf-8"));
        const helpConfig = JSON.parse(fs.readFileSync("./config/helpConfig.json", "utf-8"));
        return { helpCommands, helpConfig };
    } catch (error) {
        console.error("❌ Error loading help config:", error.message);
        return null;
    }
}

export default {
    data: new SlashCommandBuilder()
        .setName("help")
        .setDescription("View all bot commands and features"),

    cooldown: 5,
    aliases: ["h"],

    async execute(interaction) {
        const userId = interaction.user.id;
        
        // Cooldown check
        if (cooldowns.has(userId)) {
            const expirationTime = cooldowns.get(userId);
            const timeLeft = (expirationTime - Date.now()) / 1000;
            
            if (timeLeft > 0) {
                const embed = new EmbedBuilder()
                    .setColor(0xFE8200)
                    .setDescription(`⏱️ **Slow down!** You can use this command again <t:${Math.floor(expirationTime / 1000)}:R>`)
                    .setFooter({ text: `Cooldown: ${timeLeft.toFixed(1)}s remaining` });
                
                const reply = await interaction.reply({ embeds: [embed], ephemeral: true });
                
                setTimeout(async () => {
                    try {
                        await reply.delete();
                    } catch (e) {}
                }, 10000);
                
                return;
            }
        }

        // Set cooldown
        const cooldownTime = Date.now() + (this.cooldown * 1000);
        cooldowns.set(userId, cooldownTime);
        setTimeout(() => cooldowns.delete(userId), this.cooldown * 1000);

        // Load configs
        const config = loadConfig();
        if (!config) {
            return interaction.reply({ 
                content: "❌ Error loading help menu configuration.", 
                ephemeral: true 
            });
        }

        const { helpCommands, helpConfig } = config;

        // Get server stats
        const serverCount = interaction.client.guilds.cache.size;
        const memberCount = interaction.client.guilds.cache.reduce((a, g) => a + g.memberCount, 0);

        // Get guild prefix
        const prefixes = JSON.parse(fs.readFileSync("./data/prefixes.json", "utf-8"));
        const guildPrefix = prefixes[interaction.guildId] || helpConfig.bot.defaultPrefix;

        // Create home embed
        const homeEmbed = createHomeEmbed(helpConfig, helpCommands, guildPrefix, serverCount, memberCount);

        // Create dropdown menu
        const selectMenu = createSelectMenu(helpCommands, helpConfig);

        // Create buttons
        const buttons = createButtons(helpConfig);

        await interaction.reply({ 
            embeds: [homeEmbed], 
            components: [selectMenu, buttons] 
        });

        // Create collector for interactions
        const collector = interaction.channel.createMessageComponentCollector({
            filter: i => i.user.id === interaction.user.id,
            time: 300000
        });

        collector.on('collect', async i => {
            if (i.isStringSelectMenu()) {
                const selectedCategory = i.values[0];

                if (selectedCategory === 'home') {
                    await i.update({ 
                        embeds: [homeEmbed], 
                        components: [selectMenu, buttons] 
                    });
                } else {
                    const categoryEmbed = createCategoryEmbed(
                        selectedCategory, 
                        helpCommands, 
                        helpConfig, 
                        guildPrefix
                    );
                    await i.update({ 
                        embeds: [categoryEmbed], 
                        components: [selectMenu, buttons] 
                    });
                }
            } else if (i.isButton()) {
                await i.deferUpdate();
            }
        });

        collector.on('end', () => {
            // Optional: disable components
        });
    },

    async runPrefix(message, args) {
        const userId = message.author.id;
        
        // Cooldown check
        if (cooldowns.has(userId)) {
            const expirationTime = cooldowns.get(userId);
            const timeLeft = (expirationTime - Date.now()) / 1000;
            
            if (timeLeft > 0) {
                const embed = new EmbedBuilder()
                    .setColor(0xFE8200)
                    .setDescription(`⏱️ **Slow down!** You can use this command again <t:${Math.floor(expirationTime / 1000)}:R>`)
                    .setFooter({ text: `Cooldown: ${timeLeft.toFixed(1)}s remaining` });
                
                const reply = await message.reply({ embeds: [embed] });
                
                setTimeout(async () => {
                    try {
                        await reply.delete();
                    } catch (e) {}
                }, 10000);
                
                return;
            }
        }

        // Set cooldown
        const cooldownTime = Date.now() + (this.cooldown * 1000);
        cooldowns.set(userId, cooldownTime);
        setTimeout(() => cooldowns.delete(userId), this.cooldown * 1000);

        // Load configs
        const config = loadConfig();
        if (!config) {
            return message.reply("❌ Error loading help menu configuration.");
        }

        const { helpCommands, helpConfig } = config;

        // Get server stats
        const serverCount = message.client.guilds.cache.size;
        const memberCount = message.client.guilds.cache.reduce((a, g) => a + g.memberCount, 0);

        // Get guild prefix
        const prefixes = JSON.parse(fs.readFileSync("./data/prefixes.json", "utf-8"));
        const guildPrefix = prefixes[message.guildId] || helpConfig.bot.defaultPrefix;

        // Create home embed
        const homeEmbed = createHomeEmbed(helpConfig, helpCommands, guildPrefix, serverCount, memberCount);

        // Create dropdown menu
        const selectMenu = createSelectMenu(helpCommands, helpConfig);

        // Create buttons
        const buttons = createButtons(helpConfig);

        const msg = await message.channel.send({ 
            embeds: [homeEmbed], 
            components: [selectMenu, buttons] 
        });

        // Create collector for interactions
        const collector = message.channel.createMessageComponentCollector({
            filter: i => i.user.id === message.author.id,
            time: 300000
        });

        collector.on('collect', async i => {
            if (i.isStringSelectMenu()) {
                const selectedCategory = i.values[0];

                if (selectedCategory === 'home') {
                    await i.update({ 
                        embeds: [homeEmbed], 
                        components: [selectMenu, buttons] 
                    });
                } else {
                    const categoryEmbed = createCategoryEmbed(
                        selectedCategory, 
                        helpCommands, 
                        helpConfig, 
                        guildPrefix
                    );
                    await i.update({ 
                        embeds: [categoryEmbed], 
                        components: [selectMenu, buttons] 
                    });
                }
            } else if (i.isButton()) {
                await i.deferUpdate();
            }
        });
    }
};

// Helper function to create home embed
function createHomeEmbed(config, commands, guildPrefix, serverCount, memberCount) {
    const { bot, emojis, links } = config;
    
    let description = `# ${bot.icon}  ${bot.name}  ${bot.icon}\n\n`;
    description += `    ${emojis.confused} Use \`${bot.statusCommand}\` Bot Information\n\n`;
    description += `> ${emojis.dot} Server Prefix \`${guildPrefix}\`\n`;
    description += `> ${emojis.dot} Default Prefix \`${bot.defaultPrefix}\`\n\n`;
    description += `**__ Menu Categories __**\n`;
    description += `${emojis.home} **: Home**\n`;

    // Add all categories
    for (const [key, category] of Object.entries(commands.categories)) {
        description += `${category.emoji} **: ${category.name}**\n`;
    }

    description += `\n${emojis.arrow} [Term Service](${links.termsOfService})\n`;
    description += `${emojis.arrow} [Privacy Policy](${links.privacyPolicy})\n\n`;
    description += `**       \`${serverCount} Server | ${memberCount.toLocaleString()} Members\`**\n`;
    description += `Need more help? Come join our [**Guild**](${links.supportServer})`;

    const embed = new EmbedBuilder()
        .setColor(bot.color)
        .setDescription(description)
        .setImage(bot.image)
        .setTimestamp();

    return embed;
}

// Helper function to create category embed - FIXED: Only show command names
function createCategoryEmbed(categoryKey, commands, config, guildPrefix) {
    const category = commands.categories[categoryKey];
    const { bot } = config;

    let description = `# ${category.emoji} ${category.name} Cmnds\n\n`;
    description += `**${category.description}**\n\n`;
    description += `**__ Available Commands __**\n`;

    // FIXED: Only show command names, no info text
    const commandNames = category.commands
        .map(cmd => cmd.name)
        .filter(name => name && name.trim() !== ""); // Filter empty names

    if (commandNames.length > 0) {
        // Format: avatar, meme, banner, ping
        description += `${commandNames.join(', ')}\n`;
    } else {
        description += `*No commands available yet*\n`;
    }

    description += `\n**Total Commands:** \`${commandNames.length}\``;

    const embed = new EmbedBuilder()
        .setColor(bot.color)
        .setDescription(description)
        .setImage(bot.image)
        .setFooter({ text: `Use the dropdown menu to view other categories` })
        .setTimestamp();

    return embed;
}

// Helper function to create select menu
function createSelectMenu(commands, config) {
    const { emojis } = config;
    
    const options = [
        {
            label: 'Home',
            description: 'Go back to the main menu',
            value: 'home',
            emoji: emojis.home
        }
    ];

    // Add all categories
    for (const [key, category] of Object.entries(commands.categories)) {
        options.push({
            label: category.name,
            description: category.description,
            value: key,
            emoji: category.emoji
        });
    }

    const selectMenu = new StringSelectMenuBuilder()
        .setCustomId('help_menu')
        .setPlaceholder('Click And Select a category')
        .addOptions(options);

    return new ActionRowBuilder().addComponents(selectMenu);
}

// Helper function to create buttons
function createButtons(config) {
    const { emojis, links } = config;

    const supportButton = new ButtonBuilder()
        .setLabel('Support Server')
        .setStyle(ButtonStyle.Link)
        .setURL(links.supportServer)
        .setEmoji(emojis.links);

    return new ActionRowBuilder().addComponents(supportButton);
}