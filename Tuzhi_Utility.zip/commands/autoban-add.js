import { SlashCommandBuilder, EmbedBuilder } from "discord.js";
import fs from "fs";

const dataPath = "./data/autoban.json";
const cooldowns = new Set();

export default {
    data: new SlashCommandBuilder()
        .setName("ban-for-left")
        .setDescription("Enable or disable Auto-Ban system for users who leave.")
        .addStringOption(option =>
            option.setName("action")
                .setDescription("Enable or disable the system")
                .setRequired(true)
                .addChoices(
                    { name: "Enable", value: "on" },
                    { name: "Disable", value: "off" }
                )
        )
        .addChannelOption(option =>
            option.setName("channel")
                .setDescription("Optional log channel for autoban embeds")
                .setRequired(false)
        ),

    cooldown: 5, // 5s per user

    async execute(interaction) {
        // Owner only
        if (interaction.user.id !== interaction.guild.ownerId) {
            return interaction.reply({ content: "❌ Only the server owner can use this command.", ephemeral: true });
        }

        // Cooldown check
        if (cooldowns.has(interaction.user.id)) {
            const reply = await interaction.reply({ content: "⏳ Command is on cooldown. Try again in 5 seconds.", ephemeral: true });
            setTimeout(() => interaction.deleteReply().catch(() => {}), 10000); // auto delete after 10s
            return;
        }
        cooldowns.add(interaction.user.id);
        setTimeout(() => cooldowns.delete(interaction.user.id), this.cooldown * 1000);

        // Load JSON
        let json = fs.existsSync(dataPath) ? JSON.parse(fs.readFileSync(dataPath)) : {};

        const action = interaction.options.getString("action");
        const channel = interaction.options.getChannel("channel");

        // Ensure server entry exists
        if (!json[interaction.guild.id]) {
            json[interaction.guild.id] = {
                autoban: false,
                members: [],
                autobanChannel: null
            };
        }

        const guildData = json[interaction.guild.id];

        if (action === "on") {
            if (guildData.autoban) {
                return interaction.reply({
                    embeds: [
                        new EmbedBuilder()
                            .setColor("#ff0000")
                            .setTitle("⚠️ Already Enabled")
                            .setDescription("Auto-Ban system is already enabled for this server.")
                            .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
                            .setFooter({ text: `Server: ${interaction.guild.name}`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                            .setTimestamp()
                    ],
                    ephemeral: true
                });
            }

            guildData.autoban = true;
            guildData.members = interaction.guild.members.cache.filter(m => !m.user.bot).map(m => m.id);
            if (channel) guildData.autobanChannel = channel.id;

            fs.writeFileSync(dataPath, JSON.stringify(json, null, 4));

            const embed = new EmbedBuilder()
                .setColor("#ff0000")
                .setTitle("✅ Auto-Ban Enabled")
                .setDescription(`Auto-Ban system has been **enabled**.\n> **Members added:** ${guildData.members.length}`)
                .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
                .setFooter({ text: `Server: ${interaction.guild.name}`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                .setTimestamp();

            return interaction.reply({ embeds: [embed] });
        }

        if (action === "off") {
            if (!guildData.autoban) {
                return interaction.reply({
                    embeds: [
                        new EmbedBuilder()
                            .setColor("#ff0000")
                            .setTitle("⚠️ Already Disabled")
                            .setDescription("Auto-Ban system is already disabled for this server.")
                            .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
                            .setFooter({ text: `Server: ${interaction.guild.name}`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                            .setTimestamp()
                    ],
                    ephemeral: true
                });
            }

            guildData.autoban = false;
            fs.writeFileSync(dataPath, JSON.stringify(json, null, 4));

            const embed = new EmbedBuilder()
                .setColor("#ff0000")
                .setTitle("❌ Auto-Ban Disabled")
                .setDescription("Auto-Ban system has been **disabled**.")
                .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
                .setFooter({ text: `Server: ${interaction.guild.name}`, iconURL: interaction.guild.iconURL({ dynamic: true }) })
                .setTimestamp();

            return interaction.reply({ embeds: [embed] });
        }
    },
};