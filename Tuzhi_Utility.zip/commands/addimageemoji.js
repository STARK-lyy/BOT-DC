import { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } from "discord.js";

export default {
    data: new SlashCommandBuilder()
        .setName("add-image-emoji")
        .setDescription("Add a custom emoji/sticker to this server")
        .addAttachmentOption(option =>
            option.setName("image")
                .setDescription("Upload an image (PNG, JPG, or GIF)")
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName("name")
                .setDescription("Name for the emoji (2-32 characters, no spaces)")
                .setRequired(true)
                .setMinLength(2)
                .setMaxLength(32)
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageEmojisAndStickers),
    
    cooldown: 5, // 5 seconds cooldown
    
    async execute(interaction) {
        // Permission check
        if (!interaction.member.permissions.has(PermissionFlagsBits.ManageEmojisAndStickers)) {
            const errorReply = await interaction.reply({
                embeds: [{
                    color: 0xFE8200,
                    title: "❌ Permission Denied",
                    description: "You need **Manage Emojis and Stickers** permission to use this command.",
                    timestamp: new Date().toISOString()
                }],
                ephemeral: false
            });
            
            // Delete after 5 seconds
            setTimeout(async () => {
                try {
                    await errorReply.delete();
                } catch (e) {
                    // Ignore if already deleted
                }
            }, 5000);
            
            return;
        }

        // Check bot permissions
        if (!interaction.guild.members.me.permissions.has(PermissionFlagsBits.ManageEmojisAndStickers)) {
            const errorReply = await interaction.reply({
                embeds: [{
                    color: 0xFE8200,
                    title: "❌ Bot Missing Permissions",
                    description: "I need **Manage Emojis and Stickers** permission to add emojis!",
                    timestamp: new Date().toISOString()
                }],
                ephemeral: false
            });
            
            setTimeout(async () => {
                try {
                    await errorReply.delete();
                } catch (e) {}
            }, 5000);
            
            return;
        }

        const attachment = interaction.options.getAttachment("image");
        const emojiName = interaction.options.getString("name");

        // Validate emoji name (no spaces, alphanumeric + underscore only)
        if (!/^[a-zA-Z0-9_]+$/.test(emojiName)) {
            const errorReply = await interaction.reply({
                embeds: [{
                    color: 0xFE8200,
                    title: "❌ Invalid Emoji Name",
                    description: "Emoji name can only contain letters, numbers, and underscores.\nNo spaces or special characters allowed!",
                    fields: [
                        {
                            name: "❌ Invalid Examples",
                            value: "`my emoji`, `emoji-1`, `emoji!`, `my@emoji`",
                            inline: true
                        },
                        {
                            name: "✅ Valid Examples",
                            value: "`myemoji`, `emoji_1`, `cool_emoji`, `emoji2024`",
                            inline: true
                        }
                    ],
                    timestamp: new Date().toISOString()
                }],
                ephemeral: false
            });
            
            setTimeout(async () => {
                try {
                    await errorReply.delete();
                } catch (e) {}
            }, 5000);
            
            return;
        }

        // Validate file type
        const allowedTypes = ['image/png', 'image/jpeg', 'image/jpg', 'image/gif'];
        const fileExtension = attachment.name.split('.').pop().toLowerCase();
        const allowedExtensions = ['png', 'jpg', 'jpeg', 'gif'];

        if (!allowedTypes.includes(attachment.contentType) && !allowedExtensions.includes(fileExtension)) {
            const errorReply = await interaction.reply({
                embeds: [{
                    color: 0xFE8200,
                    title: "❌ Invalid File Type",
                    description: "Only **PNG**, **JPG**, and **GIF** files are supported!",
                    fields: [
                        {
                            name: "Uploaded File",
                            value: `\`${attachment.name}\`\nType: \`${attachment.contentType || 'Unknown'}\``,
                            inline: false
                        },
                        {
                            name: "Supported Formats",
                            value: "✅ `.png`\n✅ `.jpg` / `.jpeg`\n✅ `.gif`",
                            inline: false
                        }
                    ],
                    timestamp: new Date().toISOString()
                }],
                ephemeral: false
            });
            
            setTimeout(async () => {
                try {
                    await errorReply.delete();
                } catch (e) {}
            }, 5000);
            
            return;
        }

        // Validate file size (max 256KB for emojis)
        if (attachment.size > 256 * 1024) {
            const fileSizeMB = (attachment.size / 1024 / 1024).toFixed(2);
            
            const errorReply = await interaction.reply({
                embeds: [{
                    color: 0xFE8200,
                    title: "❌ File Too Large",
                    description: "Image file must be **smaller than 256 KB** for emojis.",
                    fields: [
                        {
                            name: "Your File Size",
                            value: `${fileSizeMB} MB (${attachment.size.toLocaleString()} bytes)`,
                            inline: true
                        },
                        {
                            name: "Maximum Size",
                            value: "0.25 MB (256 KB)",
                            inline: true
                        },
                        {
                            name: "💡 Tip",
                            value: "Use an image compressor to reduce file size:\n• [TinyPNG](https://tinypng.com)\n• [Compressor.io](https://compressor.io)",
                            inline: false
                        }
                    ],
                    timestamp: new Date().toISOString()
                }],
                ephemeral: false
            });
            
            setTimeout(async () => {
                try {
                    await errorReply.delete();
                } catch (e) {}
            }, 15000);
            
            return;
        }

        // Check emoji slots
        const emojiLimit = interaction.guild.premiumTier >= 1 ? 100 : 50;
        const staticEmojis = interaction.guild.emojis.cache.filter(e => !e.animated).size;
        const animatedEmojis = interaction.guild.emojis.cache.filter(e => e.animated).size;
        const isAnimated = attachment.contentType === 'image/gif' || fileExtension === 'gif';

        if (isAnimated && animatedEmojis >= emojiLimit) {
            const errorReply = await interaction.reply({
                embeds: [{
                    color: 0xFE8200,
                    title: "❌ Animated Emoji Slots Full",
                    description: `This server has reached its animated emoji limit!`,
                    fields: [
                        {
                            name: "Current Animated Emojis",
                            value: `${animatedEmojis} / ${emojiLimit}`,
                            inline: true
                        },
                        {
                            name: "Server Boost Level",
                            value: `Tier ${interaction.guild.premiumTier}`,
                            inline: true
                        },
                        {
                            name: "💡 Solutions",
                            value: "• Delete unused animated emojis\n• Boost the server for more slots\n• Use a static image instead",
                            inline: false
                        }
                    ],
                    timestamp: new Date().toISOString()
                }],
                ephemeral: false
            });
            
            setTimeout(async () => {
                try {
                    await errorReply.delete();
                } catch (e) {}
            }, 15000);
            
            return;
        }

        if (!isAnimated && staticEmojis >= emojiLimit) {
            const errorReply = await interaction.reply({
                embeds: [{
                    color: 0xFE8200,
                    title: "❌ Static Emoji Slots Full",
                    description: `This server has reached its static emoji limit!`,
                    fields: [
                        {
                            name: "Current Static Emojis",
                            value: `${staticEmojis} / ${emojiLimit}`,
                            inline: true
                        },
                        {
                            name: "Server Boost Level",
                            value: `Tier ${interaction.guild.premiumTier}`,
                            inline: true
                        },
                        {
                            name: "💡 Solutions",
                            value: "• Delete unused emojis\n• Boost the server for more slots",
                            inline: false
                        }
                    ],
                    timestamp: new Date().toISOString()
                }],
                ephemeral: false
            });
            
            setTimeout(async () => {
                try {
                    await errorReply.delete();
                } catch (e) {}
            }, 15000);
            
            return;
        }

        // Defer reply for processing
        await interaction.deferReply();

        try {
            // Create the emoji
            const emoji = await interaction.guild.emojis.create({
                attachment: attachment.url,
                name: emojiName,
                reason: `Added by ${interaction.user.tag}`
            });

            // Success embed with new components v2 style
            const successEmbed = new EmbedBuilder()
                .setColor(0xFE8200)
                .setTitle("✅ Emoji Added Successfully!")
                .setThumbnail(attachment.url)
                .addFields(
                    {
                        name: "<:TuZhi_Utility_EmojiPlus:1433853283545518324>  Emoji",
                        value: `> \`:${emoji.name}:\``,
                        inline: true
                    },
                    {
                        name: "<:TuZhi_Utility_Managements:1433852901884825632>  Added By",
                        value: `> ${interaction.user}`,
                        inline: true
                    },
                    {
                        name: "<:TuZhi_Utility_Repaire:1433853017911857236>  Emoji Slots",
                        value: emoji.animated 
                            ? `> Animated: ${animatedEmojis + 1}/${emojiLimit}`
                            : `> Static: ${staticEmojis + 1}/${emojiLimit}`,
                        inline: true
                    }
                )
                .setFooter({ 
                    text: `Server: ${interaction.guild.name}`,
                    iconURL: interaction.guild.iconURL()
                })
                .setTimestamp();

            // Success message - DO NOT delete
            await interaction.editReply({ embeds: [successEmbed] });

            console.log(`✅ Emoji "${emoji.name}" added to ${interaction.guild.name} by ${interaction.user.tag}`);

        } catch (error) {
            console.error('❌ Error adding emoji:', error);

            let errorMessage = "Failed to add emoji. Please try again.";
            
            if (error.code === 30008) {
                errorMessage = "Maximum number of emojis reached for this server!";
            } else if (error.code === 50035) {
                errorMessage = "Invalid emoji name or image format!";
            } else if (error.message.includes('dimensions')) {
                errorMessage = "Image dimensions are invalid. Emojis should be 128x128 or smaller.";
            }

            const errorEmbed = new EmbedBuilder()
                .setColor(0xFE8200)
                .setTitle("❌ Failed to Add Emoji")
                .setDescription(errorMessage)
                .addFields(
                    {
                        name: "Error Details",
                        value: `\`\`\`${error.message}\`\`\``,
                        inline: false
                    },
                    {
                        name: "💡 Common Issues",
                        value: "• File too large (max 256KB)\n• Invalid image format\n• Image dimensions too large\n• No available emoji slots",
                        inline: false
                    }
                )
                .setTimestamp();

            const errorReply = await interaction.editReply({ embeds: [errorEmbed] });
            
            // Delete error after 5 seconds
            setTimeout(async () => {
                try {
                    await errorReply.delete();
                } catch (e) {}
            }, 15000);
        }
    }
};