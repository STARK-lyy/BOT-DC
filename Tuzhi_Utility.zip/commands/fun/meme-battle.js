import { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } from "discord.js";
import https from "https";

const activeBattles = new Map();

// Get random meme - FIXED with single retry and better validation
function getRandomMeme(retryCount = 0) {
    return new Promise((resolve, reject) => {
        const options = {
            hostname: 'meme-api.com',
            path: '/gimme',
            method: 'GET',
            headers: {
                'User-Agent': 'Mozilla/5.0'
            },
            timeout: 8000
        };

        const req = https.request(options, (res) => {
            let data = '';
            
            res.on('data', chunk => {
                data += chunk;
            });
            
            res.on('end', () => {
                try {
                    const json = JSON.parse(data);
                    
                    // Strict validation
                    if (!json || !json.url || !json.title || json.nsfw === true) {
                        // Only retry ONCE
                        if (retryCount < 1) {
                            setTimeout(() => {
                                getRandomMeme(retryCount + 1).then(resolve).catch(reject);
                            }, 1000);
                        } else {
                            reject(new Error('Invalid meme data after retry'));
                        }
                        return;
                    }
                    
                    // Valid meme found
                    resolve({
                        title: json.title.substring(0, 150),
                        url: json.url,
                        author: json.author || "Unknown",
                        subreddit: json.subreddit || "memes",
                        ups: json.ups || 0
                    });
                } catch (e) {
                    reject(new Error('Failed to parse meme data'));
                }
            });
        });

        req.on('error', (e) => {
            reject(e);
        });

        req.on('timeout', () => {
            req.destroy();
            reject(new Error('Request timeout'));
        });

        req.end();
    });
}

const battleIntros = [
    "🥊 **MEME BATTLE ROYALE!**",
    "⚔️ **CLASH OF THE MEMES!**",
    "🎮 **ULTIMATE MEME SHOWDOWN!**",
    "🔥 **MEME WAR INITIATED!**",
    "💥 **BATTLE OF THE CENTURY!**"
];

const commentaries = [
    "This one is absolutely legendary!",
    "A classic move from the archives!",
    "Bringing the heat!",
    "This could be a game changer!",
    "The crowd goes wild!",
    "Straight fire! 🔥",
    "Absolutely unhinged!",
    "Top tier comedy right here!",
    "This is peak internet!",
    "Chef's kiss! 👌"
];

export default {
    data: new SlashCommandBuilder()
        .setName("meme-battle")
        .setDescription("⚔️ Two random memes battle! You decide the winner!")
        .setDMPermission(true),

    cooldown: 40,

    async execute(interaction) {
        await interaction.deferReply();

        const battleId = `${interaction.user.id}_${Date.now()}`;

        if (activeBattles.has(interaction.user.id)) {
            return interaction.editReply({
                content: "⚠️ You already have an active meme battle! Finish it first!"
            });
        }

        try {
            console.log('Starting meme battle...');
            
            // Get two memes with controlled retry
            let meme1, meme2;
            
            try {
                meme1 = await getRandomMeme();
                console.log('Meme 1 fetched:', meme1.title.substring(0, 30));
            } catch (err) {
                console.error('Failed to fetch meme 1:', err.message);
                throw new Error('Could not load first meme');
            }

            try {
                meme2 = await getRandomMeme();
                console.log('Meme 2 fetched:', meme2.title.substring(0, 30));
            } catch (err) {
                console.error('Failed to fetch meme 2:', err.message);
                throw new Error('Could not load second meme');
            }

            const intro = battleIntros[Math.floor(Math.random() * battleIntros.length)];
            const commentary1 = commentaries[Math.floor(Math.random() * commentaries.length)];
            const commentary2 = commentaries[Math.floor(Math.random() * commentaries.length)];

            const embed = new EmbedBuilder()
                .setColor("#fe8200")
                .setTitle(intro)
                .setDescription("**Two memes enter, one meme wins!**\n\nClick the buttons below to vote for your favorite!\n\n*Battle ends in 60 seconds*")
                .addFields(
                    {
                        name: "🔵 MEME #1",
                        value: `**${meme1.title}**\n*${commentary1}*\n👍 ${meme1.ups.toLocaleString()} upvotes\nr/${meme1.subreddit}`,
                        inline: false
                    },
                    {
                        name: "🔴 MEME #2",
                        value: `**${meme2.title}**\n*${commentary2}*\n👍 ${meme2.ups.toLocaleString()} upvotes\nr/${meme2.subreddit}`,
                        inline: false
                    }
                )
                .setImage(meme1.url)
                .setFooter({ text: "🎮 Meme Battle Arena • Cast your vote!" })
                .setTimestamp();

            // Create voting buttons
            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId(`vote_meme1_${battleId}`)
                        .setLabel("Vote Meme #1")
                        .setStyle(ButtonStyle.Primary)
                        .setEmoji("🔵"),
                    new ButtonBuilder()
                        .setCustomId(`vote_meme2_${battleId}`)
                        .setLabel("Vote Meme #2")
                        .setStyle(ButtonStyle.Danger)
                        .setEmoji("🔴"),
                    new ButtonBuilder()
                        .setCustomId(`view_meme2_${battleId}`)
                        .setLabel("View Meme #2")
                        .setStyle(ButtonStyle.Secondary)
                        .setEmoji("👁️")
                );

            await interaction.editReply({ embeds: [embed], components: [row] });

            // Store battle data
            activeBattles.set(interaction.user.id, {
                battleId,
                meme1,
                meme2,
                votes: { meme1: new Set(), meme2: new Set() },
                currentView: 1,
                intro,
                commentary1,
                commentary2
            });

            // Create collector for all users
            const filter = i => i.customId.endsWith(battleId);
            const collector = interaction.channel.createMessageComponentCollector({ 
                filter, 
                time: 60000
            });

            collector.on('collect', async i => {
                const battle = activeBattles.get(interaction.user.id);
                if (!battle) return;

                try {
                    if (i.customId.startsWith('vote_meme1')) {
                        battle.votes.meme1.add(i.user.id);
                        battle.votes.meme2.delete(i.user.id);
                        await i.reply({ content: "🔵 You voted for Meme #1!", ephemeral: true });
                    } else if (i.customId.startsWith('vote_meme2')) {
                        battle.votes.meme2.add(i.user.id);
                        battle.votes.meme1.delete(i.user.id);
                        await i.reply({ content: "🔴 You voted for Meme #2!", ephemeral: true });
                    } else if (i.customId.startsWith('view_meme2')) {
                        // Toggle view between meme 1 and meme 2
                        battle.currentView = battle.currentView === 1 ? 2 : 1;
                        const meme = battle.currentView === 1 ? battle.meme1 : battle.meme2;
                        
                        const viewEmbed = new EmbedBuilder()
                            .setColor("#fe8200")
                            .setTitle(battle.intro)
                            .setDescription("**Two memes enter, one meme wins!**\n\nClick the buttons below to vote for your favorite!\n\n*Battle ends in 60 seconds*")
                            .addFields(
                                {
                                    name: "🔵 MEME #1",
                                    value: `**${battle.meme1.title}**\n*${battle.commentary1}*\n👍 ${battle.meme1.ups.toLocaleString()} upvotes\nr/${battle.meme1.subreddit}`,
                                    inline: false
                                },
                                {
                                    name: "🔴 MEME #2",
                                    value: `**${battle.meme2.title}**\n*${battle.commentary2}*\n👍 ${battle.meme2.ups.toLocaleString()} upvotes\nr/${battle.meme2.subreddit}`,
                                    inline: false
                                }
                            )
                            .setImage(meme.url)
                            .setFooter({ text: `🎮 Currently viewing: Meme #${battle.currentView}` })
                            .setTimestamp();

                        await i.update({ embeds: [viewEmbed] });
                    }
                } catch (error) {
                    console.error('Button interaction error:', error.message);
                }
            });

            collector.on('end', async () => {
                const battle = activeBattles.get(interaction.user.id);
                if (!battle) return;

                const votes1 = battle.votes.meme1.size;
                const votes2 = battle.votes.meme2.size;
                const totalVotes = votes1 + votes2;

                let winner, winnerMeme, winnerVotes;
                let resultText;

                if (votes1 > votes2) {
                    winner = "🔵 MEME #1";
                    winnerMeme = battle.meme1;
                    winnerVotes = votes1;
                    resultText = "Meme #1 takes the crown! 👑";
                } else if (votes2 > votes1) {
                    winner = "🔴 MEME #2";
                    winnerMeme = battle.meme2;
                    winnerVotes = votes2;
                    resultText = "Meme #2 claims victory! 👑";
                } else {
                    winner = "🤝 IT'S A TIE!";
                    winnerMeme = battle.meme1;
                    resultText = "Both memes are equally legendary! 🏆";
                }

                const resultEmbed = new EmbedBuilder()
                    .setColor(votes1 > votes2 ? "#0099ff" : votes2 > votes1 ? "#ff0000" : "#ffaa00")
                    .setTitle("⚔️ BATTLE RESULTS!")
                    .setDescription(`**${resultText}**\n\n${winner} WINS!`)
                    .addFields(
                        {
                            name: "📊 Final Score",
                            value: `🔵 Meme #1: **${votes1}** vote(s)\n🔴 Meme #2: **${votes2}** vote(s)\n\nTotal Votes: **${totalVotes}**`,
                            inline: false
                        },
                        {
                            name: "🏆 Winning Meme",
                            value: `**${winnerMeme.title}**\nFrom r/${winnerMeme.subreddit}`,
                            inline: false
                        }
                    )
                    .setImage(winnerMeme.url)
                    .setFooter({ text: "🎮 Battle Ended • Thanks for participating!" })
                    .setTimestamp();

                try {
                    await interaction.editReply({ embeds: [resultEmbed], components: [] });
                } catch (error) {
                    console.error("Error showing results:", error.message);
                }

                activeBattles.delete(interaction.user.id);
            });

        } catch (error) {
            console.error("Meme battle error:", error.message);
            
            const errorEmbed = new EmbedBuilder()
                .setColor("#ff0000")
                .setTitle("⚠️ Battle Cancelled")
                .setDescription("Failed to load memes from the meme API!\n\n**Possible reasons:**\n• API is currently down\n• Network timeout\n• Invalid response from server\n\n**Try using `/emoji-slots` instead!** 🎰")
                .setFooter({ text: `Error: ${error.message}` });

            try {
                await interaction.editReply({ embeds: [errorEmbed], components: [] });
            } catch (err) {
                console.error("Failed to send error message:", err.message);
            }
            
            activeBattles.delete(interaction.user.id);
        }
    }
};