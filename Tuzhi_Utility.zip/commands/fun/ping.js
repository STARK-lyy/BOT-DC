// commands/fun/ping.js
import djs from 'discord.js';
import dotenv from 'dotenv';
dotenv.config();

const {
  SlashCommandBuilder,
  TextDisplayBuilder,
  ContainerBuilder,
  SeparatorBuilder,
  MessageFlags
} = djs;

function formatUptime(ms) {
  const seconds = Math.floor(ms / 1000) % 60;
  const minutes = Math.floor(ms / (1000 * 60)) % 60;
  const hours = Math.floor(ms / (1000 * 60 * 60)) % 24;
  const days = Math.floor(ms / (1000 * 60 * 60 * 24)) % 30;
  const months = Math.floor(ms / (1000 * 60 * 60 * 24 * 30)) % 12;
  const years = Math.floor(ms / (1000 * 60 * 60 * 24 * 365));
  let str = '';
  if (years) str += `${years}y `;
  if (months) str += `${months}m `;
  if (days) str += `${days}d `;
  if (hours) str += `${hours}h `;
  if (minutes) str += `${minutes}m `;
  if (seconds) str += `${seconds}s`;
  return str.trim() || '0s';
}

const cooldowns = new Map();

export default {
  data: new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Shows bot uptime, latency, and server stats'),

  aliases: ['pong'],
  cooldown: 5,

  buildMessageContainer(title, message, color, emoji) {
    const header = new TextDisplayBuilder().setContent(`${emoji} **${title}**`);
    const body = new TextDisplayBuilder().setContent(`> ${message}`);
    return new ContainerBuilder()
      .setAccentColor(color)
      .addTextDisplayComponents(header)
      .addSeparatorComponents(new SeparatorBuilder())
      .addTextDisplayComponents(body);
  },

  async execute(interaction) {
    const userId = interaction.user.id;

    // Cooldown
    if (cooldowns.has(userId)) {
      const expirationTime = cooldowns.get(userId);
      const timeLeft = (expirationTime - Date.now()) / 1000;
      if (timeLeft > 0) {
        const cooldownContainer = this.buildMessageContainer(
          'Slow Down',
          `You can use this command again <t:${Math.floor(expirationTime / 1000)}:R>`,
          0xFE8200,
          '<:TuZhi_Utility_Cooldown:1433852369799745761>'
        );
        const reply = await interaction.reply({
          components: [cooldownContainer],
          flags: MessageFlags.IsComponentsV2
        });
        setTimeout(() => reply.delete().catch(() => {}), 10000);
        return;
      }
    }
    cooldowns.set(userId, Date.now() + 5000);
    setTimeout(() => cooldowns.delete(userId), 5000);

    const t0 = Date.now();
    await interaction.deferReply({ flags: MessageFlags.IsComponentsV2 });
    const botLatency = Date.now() - t0;

    const uptime = formatUptime(interaction.client.uptime ?? 0);
    const wsLatency = Math.round(interaction.client.ws.ping ?? 0);
    const totalGuilds = interaction.client.guilds.cache.size;
    const botVersion = process.env.BOT_VERSION || '1.0.0';

    const titleSection = new TextDisplayBuilder().setContent(
      `### <:TuZhi_Utility_Life:1433864150832123997> **TuZhi Utility Statistics** 🌿🥀`
    );

    const statsSection = new TextDisplayBuilder().setContent(
      `> <:TuZhi_Utility_Dote:1433864555066425436> **Uptime:** \`${uptime}\`\n` +
      `> <:TuZhi_Utility_Dote:1433864555066425436> **WebSocket Latency:** \`${wsLatency}ms\`\n` +
      `> <:TuZhi_Utility_Dote:1433864555066425436> **Bot Latency:** \`${botLatency}ms\`\n` +
      `> <:TuZhi_Utility_Dote:1433864555066425436> **Total Servers:** \`${totalGuilds}\`\n` +
      `> <:TuZhi_Utility_Dote:1433864555066425436> **Bot Version:** \`${botVersion}\``
    );

    const container = new ContainerBuilder()
      .setAccentColor(0xFE8200)
      .addTextDisplayComponents(titleSection)
      .addSeparatorComponents(new SeparatorBuilder())
      .addTextDisplayComponents(statsSection)
      .addSeparatorComponents(new SeparatorBuilder())

    await interaction.editReply({
      components: [container],
      flags: MessageFlags.IsComponentsV2
    });
  },

  async runPrefix(message, args, client) {
    const userId = message.author.id;

    if (cooldowns.has(userId)) {
      const expirationTime = cooldowns.get(userId);
      const timeLeft = (expirationTime - Date.now()) / 1000;
      if (timeLeft > 0) {
        const cooldownContainer = this.buildMessageContainer(
          'Slow Down',
          `You can use this command again <t:${Math.floor(expirationTime / 1000)}:R>`,
          0xFE8200,
          '<:TuZhi_Utility_Cooldown:1433852369799745761>'
        );
        const reply = await message.reply({
          components: [cooldownContainer],
          flags: MessageFlags.IsComponentsV2
        });
        setTimeout(() => reply.delete().catch(() => {}), 10000);
        return;
      }
    }
    cooldowns.set(userId, Date.now() + 5000);
    setTimeout(() => cooldowns.delete(userId), 5000);

    const t0 = Date.now();
    const placeholder = await message.reply({ content: '🏓 Pinging............' });
    const botLatency = Date.now() - t0;

    const uptime = formatUptime(client.uptime ?? 0);
    const wsLatency = Math.round(client.ws.ping ?? 0);
    const totalGuilds = client.guilds.cache.size;
    const botVersion = process.env.BOT_VERSION || '1.0.0';

    const titleSection = new TextDisplayBuilder().setContent(
      `### <:TuZhi_Utility_Life:1433864150832123997> **TuZhi Utility Statistics** 🌿🥀`
    );

    const statsSection = new TextDisplayBuilder().setContent(
      `> <:TuZhi_Utility_Dote:1433864555066425436> **Uptime:** \`${uptime}\`\n` +
      `> <:TuZhi_Utility_Dote:1433864555066425436> **WebSocket Latency:** \`${wsLatency}ms\`\n` +
      `> <:TuZhi_Utility_Dote:1433864555066425436> **Bot Latency:** \`${botLatency}ms\`\n` +
      `> <:TuZhi_Utility_Dote:1433864555066425436> **Total Servers:** \`${totalGuilds}\`\n` +
      `> <:TuZhi_Utility_Dote:1433864555066425436> **Bot Version:** \`${botVersion}\``
    );


    const container = new ContainerBuilder()
      .setAccentColor(0xFE8200)
      .addTextDisplayComponents(titleSection)
      .addSeparatorComponents(new SeparatorBuilder())
      .addTextDisplayComponents(statsSection)
      .addSeparatorComponents(new SeparatorBuilder())


    await placeholder.edit({
      content: null,
      components: [container],
      flags: MessageFlags.IsComponentsV2
    });
  }
};