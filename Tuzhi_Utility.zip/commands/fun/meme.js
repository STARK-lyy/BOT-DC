// commands/meme.js
import fs from "fs";
import fetch from "node-fetch";
import { SlashCommandBuilder, EmbedBuilder, Collection } from "discord.js";

const cooldowns = new Collection();

// -------------------- Meme APIs --------------------
const memeAPIs = [
  { name: "DankMemes", url: "https://meme-api.com/gimme/dankmemes" },
  { name: "Memes", url: "https://meme-api.com/gimme/memes" },
  { name: "Animemes", url: "https://meme-api.com/gimme/Animemes" },
  { name: "PrequelMemes", url: "https://meme-api.com/gimme/PrequelMemes" },
];

function getRandomAPI() {
  return memeAPIs[Math.floor(Math.random() * memeAPIs.length)];
}

export default {
  data: new SlashCommandBuilder()
    .setName("meme")
    .setDescription("Get a meme from different APIs")
    .addStringOption((opt) =>
      opt
        .setName("source")
        .setDescription("Select meme source")
        .addChoices(...memeAPIs.map((api) => ({ name: api.name, value: api.url })))
        .setRequired(true)
    ),

  cooldown: 5, // 5s cooldown

  async execute(interaction) {
    const userId = interaction.user.id;

    if (cooldowns.has(userId)) {
      return interaction.reply({
        content: `⏳ Cooldown active! Try again later.`,
        ephemeral: true,
      }).then((msg) => setTimeout(() => msg.delete().catch(() => {}), 10000));
    }

    cooldowns.set(userId, true);
    setTimeout(() => cooldowns.delete(userId), 5000);

    const apiUrl = interaction.options.getString("source");

    try {
      const res = await fetch(apiUrl);
      const data = await res.json();
      if (!data || !data.url) throw new Error("API returned invalid data");

      const embed = new EmbedBuilder()
        .setColor("#fe8200")
        .setDescription(`<:TuZhi_Utility_Search:1433861958108581910> **${data.title || "Meme"}**`)
        .setImage(data.url)
        .setFooter({ text: interaction.user.tag, iconURL: interaction.user.displayAvatarURL() })
        .setAuthor({
          name: "TuZhi Utility Parfect",
          iconURL: interaction.client.user.displayAvatarURL(),
        });

      await interaction.reply({ embeds: [embed] });
    } catch (err) {
      console.error(err);
      await interaction.reply({ content: "❌ Failed to fetch meme. Try again.", ephemeral: true });
    }
  },

  // ------------------- Prefix Version -------------------
  runPrefix: async (message) => {
    const userId = message.author.id;
    if (cooldowns.has(userId)) {
      return message.reply(`⏳ Cooldown active! Try again later.`)
        .then((msg) => setTimeout(() => msg.delete().catch(() => {}), 10000));
    }

    cooldowns.set(userId, true);
    setTimeout(() => cooldowns.delete(userId), 5000);

    const api = getRandomAPI();

    try {
      const res = await fetch(api.url);
      const data = await res.json();
      if (!data || !data.url) throw new Error("API returned invalid data");

      const embed = new EmbedBuilder()
        .setColor("#fe8200")
        .setDescription(`<:TuZhi_Utility_Search:1433861958108581910> **${data.title || "Meme"}**`)
        .setImage(data.url)
        .setFooter({ text: message.author.tag, iconURL: message.author.displayAvatarURL() })
        .setAuthor({
          name: "TuZhi Utility  Parfect",
          iconURL: message.client.user.displayAvatarURL(),
        });

      await message.channel.send({ embeds: [embed] });
    } catch (err) {
      console.error(err);
      message.reply("❌ Failed to fetch meme. Try again.")
        .then((msg) => setTimeout(() => msg.delete().catch(() => {}), 10000));
    }
  },
};