import { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } from "discord.js";

const cooldowns = new Map();

const e = {
    cooldown: "<:TuZhi_Utility_Cooldown:1433852369799745761>",
    cross: "<:TuZhi_Utility_UnTick:1433864956226572370>",
    tick: "<:TuZhi_Utility_Tick:1433864870775885897>",
    score: "<:TuZhi_Utility_Star_mod:1433861404699660421>",
    tie: "<:TuZhi_Utility_Confused:1433865082193842349>",
    win: "<:TuZhi_Utility_Winn:1433861769528479794>",
    battle: "🕊️ ",
    round: "<:TuZhi_Utility_Two_Arrow:1433864767570706605>",
    user: "<:TuZhi_Utility_User:1433852028207104145>",
    bot: "<:TuZhi_Utility_Managements:1433852901884825632>"
};

const choices = ["rock", "paper", "scissors"];
const choiceEmojis = { rock: "🪨", paper: "📄", scissors: "✂️" };

export default {
    data: new SlashCommandBuilder()
        .setName("rps")
        .setDescription("Play Rock Paper Scissors!")
        .addUserOption(opt => opt.setName("opponent").setDescription("Optional opponent")),

    cooldown: 3,
    aliases: ["rockpaperscissors"],

    async execute(interaction) {
        await runRPS(interaction.user, interaction, interaction.options.getUser("opponent"));
    },

    async runPrefix(message, args) {
        const opponent = message.mentions.users.first() || null;
        await runRPS(message.author, message, opponent, true);
    }
};

async function runRPS(user1, context, user2 = null, isPrefix = false) {
    const userId = user1.id;

    // Cooldown
    if (cooldowns.has(userId)) {
        const remaining = ((cooldowns.get(userId) - Date.now()) / 1000).toFixed(1);
        const msg = `${e.cooldown} Wait ${remaining}s before playing again!`;
        if (isPrefix) return context.reply(msg).then(m => setTimeout(() => m.delete().catch(() => {}), 5000));
        else return context.reply({ content: msg, ephemeral: true });
    }

    cooldowns.set(userId, Date.now() + 3000);
    setTimeout(() => cooldowns.delete(userId), 3000);

    const player2 = user2 || context.client.user;
    const isPvP = !!user2;

    const statusEmbed = new EmbedBuilder()
        .setColor(0xFE8200)
        .setAuthor({ name: `${e.battle} Rock Paper Scissors`, iconURL: user1.displayAvatarURL() })
        .setDescription(`${e.round} **Click to choose:**\n${user1} ⚔️ ${player2}\n\n${e.score} Ready Status\n${e.user} ${user1.username}: ${e.cross}\n${e.bot} ${player2.username || context.client.user.username}: ${e.cross}`);

    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("rock").setStyle(ButtonStyle.Secondary).setEmoji(choiceEmojis.rock),
        new ButtonBuilder().setCustomId("paper").setStyle(ButtonStyle.Secondary).setEmoji(choiceEmojis.paper),
        new ButtonBuilder().setCustomId("scissors").setStyle(ButtonStyle.Secondary).setEmoji(choiceEmojis.scissors)
    );

    let msg;
    if (isPrefix) msg = await context.channel.send({ embeds: [statusEmbed], components: [row] });
    else msg = await context.reply({ embeds: [statusEmbed], components: [row], fetchReply: true });

    const players = new Map();
    players.set(user1.id, null);
    if (isPvP) players.set(player2.id, null);

    const collector = msg.createMessageComponentCollector({
        filter: i => players.has(i.user.id),
        componentType: ComponentType.Button,
        time: 60000
    });

    async function updateStatus() {
        const newEmbed = EmbedBuilder.from(statusEmbed).setDescription(`${e.round} **Click to choose:**\n${user1} ⚔️ ${player2}\n\n${e.score} Ready Status\n${e.user} ${user1.username}: ${players.get(user1.id) ? e.tick : e.cross}\n${e.bot} ${player2.username || context.client.user.username}: ${players.get(player2.id) ? e.tick : e.cross}`);
        await msg.edit({ embeds: [newEmbed] });
    }

    collector.on("collect", async i => {
        players.set(i.user.id, i.customId);

        // If PvBot, bot auto choose
        if (!isPvP) players.set(player2.id, choices[Math.floor(Math.random() * choices.length)]);

        await updateStatus();

        // If both chose
        if (Array.from(players.values()).every(v => v !== null)) {
            const p1Choice = players.get(user1.id);
            const p2Choice = players.get(player2.id);

            let resultText = "";
            let color = 0xFE8200;

            if (p1Choice === p2Choice) {
                resultText = `${e.tie} Tie!\n${user1} **Chose:** ${choiceEmojis[p1Choice]}\n${player2} **Chose:** ${choiceEmojis[p2Choice]}`;
                color = 0xFE8200;
            } else if (
                (p1Choice === "rock" && p2Choice === "scissors") ||
                (p1Choice === "paper" && p2Choice === "rock") ||
                (p1Choice === "scissors" && p2Choice === "paper")
            ) {
                resultText = `${e.win} ${user1} You win!\n\n${user1} **Chose:** ${choiceEmojis[p1Choice]}\n${player2} **Chose:** ${choiceEmojis[p2Choice]}`;
                color = 0x7CFC00;
            } else {
                resultText = `${e.cross} ${user1} You lost!\n\n${user1} **Chose:** ${choiceEmojis[p1Choice]}\n${player2} **Chose:** ${choiceEmojis[p2Choice]}`;
                color = 0xFF0000;
            }

            const disabledRow = ActionRowBuilder.from(row);
            disabledRow.components.forEach(b => b.setDisabled(true));

            const resultEmbed = EmbedBuilder.from(statusEmbed).setDescription(resultText).setColor(color);
            await i.update({ embeds: [resultEmbed], components: [disabledRow] });
            collector.stop();
        } else {
            // If PvP, wait for 2nd player
            await i.reply({ content: `✅ Choice registered! Waiting for ${player2.username}'s turn...`, ephemeral: true });
        }
    });

    collector.on("end", async collected => {
        if (Array.from(players.values()).some(v => v === null)) {
            const disabledRow = ActionRowBuilder.from(row);
            disabledRow.components.forEach(b => b.setDisabled(true));
            const tieEmbed = EmbedBuilder.from(statusEmbed)
                .setDescription(`${e.tie} Time's up! It's a tie!\n\n${user1} **Chose:** ${players.get(user1.id) || "No choice"}\n${player2} **Chose:** ${players.get(player2.id) || "No choice"}`)
                .setColor(0xFE8200);

            await msg.edit({ embeds: [tieEmbed], components: [disabledRow] });
        }
    });
}