import fs from "fs";

const PREFIX_LOG_FILE = "./data/prefixLogs.json";

// Ensure prefix logs file exists
function ensurePrefixLogFile() {
    if (!fs.existsSync("./data")) {
        fs.mkdirSync("./data", { recursive: true });
    }
    if (!fs.existsSync(PREFIX_LOG_FILE)) {
        fs.writeFileSync(PREFIX_LOG_FILE, JSON.stringify({}, null, 4));
    }
}

// Read prefix logs
export function readPrefixLogs() {
    ensurePrefixLogFile();
    return JSON.parse(fs.readFileSync(PREFIX_LOG_FILE, "utf-8"));
}

// Write prefix logs
export function writePrefixLogs(data) {
    ensurePrefixLogFile();
    fs.writeFileSync(PREFIX_LOG_FILE, JSON.stringify(data, null, 4));
}

// Log prefix change
export function logPrefixChange(guildId, guildName, newPrefix, userId, userName, timestamp) {
    const logs = readPrefixLogs();
    
    if (!logs[guildId]) {
        logs[guildId] = {
            guildName: guildName,
            currentPrefix: newPrefix,
            history: []
        };
    }
    
    // Update current prefix
    logs[guildId].currentPrefix = newPrefix;
    logs[guildId].guildName = guildName;
    
    // Add to history
    logs[guildId].history.push({
        prefix: newPrefix,
        setBy: userId,
        setByName: userName,
        timestamp: timestamp
    });
    
    writePrefixLogs(logs);
}

// Get prefix info for a guild
export function getPrefixInfo(guildId) {
    const logs = readPrefixLogs();
    return logs[guildId] || null;
}

// Get last prefix change
export function getLastPrefixChange(guildId) {
    const info = getPrefixInfo(guildId);
    if (!info || !info.history || info.history.length === 0) {
        return null;
    }
    return info.history[info.history.length - 1];
}