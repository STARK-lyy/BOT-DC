import fs from 'fs';
const dataPath = './data/autoban.json';

export default {
    name: 'guildMemberAdd',
    async execute(member) {
        if (!member || member.user.bot) return;

        // Load JSON
        let json = fs.existsSync(dataPath) ? JSON.parse(fs.readFileSync(dataPath)) : {};

        // Ensure server exists
        if (!json[member.guild.id]) {
            json[member.guild.id] = { autoban: false, members: [], autobanChannel: null };
        }

        const guildData = json[member.guild.id];

        // Only if autoban enabled
        if (!guildData.autoban) return;

        // Add member to members list if not present
        if (!guildData.members.includes(member.id)) {
            guildData.members.push(member.id);
            fs.writeFileSync(dataPath, JSON.stringify(json, null, 4));
            console.log(`📥 Added ${member.user.tag} to autoban list in ${member.guild.name}`);
        }
    }
};