import { Events } from "discord.js";
import fs from "fs";
import path from "path";

const dataPath = path.join(process.cwd(), "data", "utility", "joinAutorole.json");

function loadData() {
    try {
        if (!fs.existsSync(dataPath)) return {};
        return JSON.parse(fs.readFileSync(dataPath, "utf-8"));
    } catch (error) {
        return {};
    }
}

function saveData(data) {
    try {
        const dir = path.dirname(dataPath);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
        fs.writeFileSync(dataPath, JSON.stringify(data, null, 4));
    } catch (error) {
        console.error("Error saving join autorole data:", error);
    }
}

export default {
    name: Events.GuildRoleDelete,
    
    async execute(role) {
        try {
            const data = loadData();
            
            // Check if guild has auto-roles configured
            if (!data[role.guild.id] || !data[role.guild.id].roles) {
                return;
            }

            const roleIds = data[role.guild.id].roles;
            
            // Check if deleted role was in auto-role list
            if (roleIds.includes(role.id)) {
                // Remove the deleted role from the list
                data[role.guild.id].roles = roleIds.filter(id => id !== role.id);
                
                // If no roles left, remove the guild entry
                if (data[role.guild.id].roles.length === 0) {
                    delete data[role.guild.id];
                }
                
                saveData(data);
                console.log(`[Auto-Role Cleanup] Removed deleted role ${role.name} (${role.id}) from ${role.guild.name}`);
            }
        } catch (error) {
            console.error("[Auto-Role Cleanup] Error during role cleanup:", error.message);
        }
    }
};