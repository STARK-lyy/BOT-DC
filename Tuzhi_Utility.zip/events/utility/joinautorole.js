import { Events } from "discord.js";
import fs from "fs";
import path from "path";

const dataPath = path.join(process.cwd(), "data", "utility", "joinAutorole.json");

function loadData() {
    try {
        if (!fs.existsSync(dataPath)) return {};
        return JSON.parse(fs.readFileSync(dataPath, "utf-8"));
    } catch (error) {
        console.error("Error loading join autorole data:", error);
        return {};
    }
}

export default {
    name: Events.GuildMemberAdd,
    
    async execute(member) {
        try {
            // Ignore bots
            if (member.user.bot) return;

            const data = loadData();
            
            // Check if server has auto-roles configured
            if (!data[member.guild.id] || !data[member.guild.id].roles || data[member.guild.id].roles.length === 0) {
                return;
            }

            const roleIds = data[member.guild.id].roles;
            const rolesToAdd = [];
            const botMember = member.guild.members.me;

            // Check bot permissions
            if (!botMember.permissions.has("ManageRoles")) {
                console.warn(`[Auto-Role] Missing ManageRoles permission in ${member.guild.name}`);
                return;
            }

            const botRole = botMember.roles.highest;

            // Validate and collect roles
            for (const roleId of roleIds) {
                const role = member.guild.roles.cache.get(roleId);
                
                if (!role) {
                    console.warn(`[Auto-Role] Role ${roleId} not found in ${member.guild.name}`);
                    continue;
                }

                // Skip if role is managed (bot/integration role)
                if (role.managed) {
                    console.warn(`[Auto-Role] Role ${role.name} is managed, skipping`);
                    continue;
                }

                // Skip if role is higher than bot's highest role
                if (role.position >= botRole.position) {
                    console.warn(`[Auto-Role] Role ${role.name} is higher than bot's role in ${member.guild.name}`);
                    continue;
                }

                // Skip @everyone
                if (role.id === member.guild.id) {
                    continue;
                }

                rolesToAdd.push(role);
            }

            if (rolesToAdd.length === 0) {
                return;
            }

            // Add delay to avoid rate limits (especially for multiple roles)
            await new Promise(resolve => setTimeout(resolve, 1000));

            // Add roles to member
            await member.roles.add(rolesToAdd, "Auto-Role on Join");

            console.log(`[Auto-Role] Added ${rolesToAdd.length} role(s) to ${member.user.tag} in ${member.guild.name}`);

        } catch (error) {
            console.error(`[Auto-Role] Error assigning roles to ${member.user.tag}:`, error.message);
            
            // Don't send error messages to channels - keep it silent
            // This prevents spam and maintains clean server experience
        }
    }
};