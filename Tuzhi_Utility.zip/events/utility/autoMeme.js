import { Events, EmbedBuilder } from "discord.js";

// ===== MANUAL CONFIGURATION =====
// Add your server configurations here
const MEME_CONFIG = [
    {
        serverId: "1306987692571099216",  // Replace with actual server ID
        channelId: "1439084901893935156"  // Replace with actual channel ID
    }, 
    {
        serverId: "1420000949153566832",  // Replace with actual server ID
        channelId: "1449768093839786054"  // Replace with actual channel ID
    }, 
    // Add more servers as needed
    // {
    //     serverId: "YOUR_SERVER_ID",
    //     channelId: "YOUR_CHANNEL_ID"
    // },
];

// Multiple Meme APIs - Random selection
const MEME_APIS = [
    {
        name: "Reddit Memes",
        url: "https://meme-api.com/gimme",
        parse: (data) => ({
            title: data.title,
            url: data.url,
            postLink: data.postLink,
            isValid: !data.nsfw && !data.spoiler && isImageUrl(data.url)
        })
    },
    {
        name: "Meme API v2",
        url: "https://meme-api.com/gimme/memes",
        parse: (data) => ({
            title: data.title,
            url: data.url,
            postLink: data.postLink,
            isValid: !data.nsfw && !data.spoiler && isImageUrl(data.url)
        })
    },
    {
        name: "Dank Memes",
        url: "https://meme-api.com/gimme/dankmemes",
        parse: (data) => ({
            title: data.title,
            url: data.url,
            postLink: data.postLink,
            isValid: !data.nsfw && !data.spoiler && isImageUrl(data.url)
        })
    },
    {
        name: "Wholesome Memes",
        url: "https://meme-api.com/gimme/wholesomememes",
        parse: (data) => ({
            title: data.title,
            url: data.url,
            postLink: data.postLink,
            isValid: !data.nsfw && !data.spoiler && isImageUrl(data.url)
        })
    },
    {
        name: "Me IRL",
        url: "https://meme-api.com/gimme/meirl",
        parse: (data) => ({
            title: data.title,
            url: data.url,
            postLink: data.postLink,
            isValid: !data.nsfw && !data.spoiler && isImageUrl(data.url)
        })
    }
];

// Custom emojis for description
const CUSTOM_EMOJIS = [
    '<:TuZhi_Utility_like:1433851565608800347>',
    '<:TuZhi_Utility_Fire:1433856226441170944>',
    '<:TuZhi_Utility_Heart:1433852435973144636>',
    '<:TuZhi_Utility_Winn:1433861769528479794>',
    '<:TuZhi_Utility_Star_mod:1433861404699660421>',
    '<:TuZhi_Utility_Gift:1433871875645378904>',
    '<:TuZhi_Utility_Game:1433865149273604246>',
    '<:TuZhi_Utility_Artist:1433851488001851515>',
    '<:management:1433852743948439593>',
    '<:TuZhi_Utility_save:1433851972435316756>',
];

let memeIntervals = new Map();
let lastMemeTimes = new Map();

export default {
    name: Events.ClientReady,
    once: true,

    async execute(client) {

        // Validate configurations
        const validConfigs = [];
        for (const config of MEME_CONFIG) {
            try {
                const guild = client.guilds.cache.get(config.serverId);
                if (!guild) {
                    console.log(`⚠️ Server not found: ${config.serverId}`);
                    continue;
                }

                const channel = guild.channels.cache.get(config.channelId);
                if (!channel) {
                    console.log(`⚠️ Channel not found in ${guild.name}: ${config.channelId}`);
                    continue;
                }

                if (!channel.isTextBased()) {
                    console.log(`⚠️ Channel is not text-based in ${guild.name}`);
                    continue;
                }

                // Check bot permissions
                const permissions = channel.permissionsFor(client.user);
                if (!permissions.has(['SendMessages', 'EmbedLinks'])) {
                    console.log(`⚠️ Missing permissions in ${guild.name} -> #${channel.name}`);
                    continue;
                }

                validConfigs.push(config);
            } catch (error) {
                console.error(`❌ Error validating config:`, error.message);
            }
        }

        if (validConfigs.length === 0) {
            console.log("⚠️ No valid meme configurations found!");
            console.log("💡 Please add server and channel IDs in events/autoMeme.js");
            return;
        }

        console.log(`\n🚀 Starting meme senders for ${validConfigs.length} server(s)...\n`);

        // Start meme sending for each config with staggered delays
        validConfigs.forEach((config, index) => {
            const delay = index * 20000; // 20 second delay between each server start
            
            setTimeout(() => {
                startMemeSender(client, config);
            }, delay);
        });
    }
};

function startMemeSender(client, config) {
    const { serverId, channelId } = config;
    const key = `${serverId}-${channelId}`;

    // Clear existing interval if any
    if (memeIntervals.has(key)) {
        clearInterval(memeIntervals.get(key));
    }

    // Send first meme after 10 seconds
    setTimeout(() => {
        console.log(`🎭 Sending first meme to ${serverId}...`);
        sendMeme(client, serverId, channelId);
    }, 10000);

    // Set interval for every 1 minute (60000ms)
    const interval = setInterval(() => {
        sendMeme(client, serverId, channelId);
    }, 60000); // 1 minute

    memeIntervals.set(key, interval);
    console.log(`⏰ Meme timer started for ${serverId}`);
}

async function sendMeme(client, serverId, channelId) {
    try {
        const guild = client.guilds.cache.get(serverId);
        if (!guild) {
            console.log(`❌ Guild not found: ${serverId}`);
            return;
        }

        const channel = guild.channels.cache.get(channelId);
        if (!channel) {
            console.log(`❌ Channel not found: ${channelId}`);
            return;
        }

        // Rate limit protection
        const lastTime = lastMemeTimes.get(channelId) || 0;
        const now = Date.now();
        if (now - lastTime < 30000) { // Minimum 30 seconds between memes
            console.log(`⏰ Rate limit: Skipping meme for ${guild.name}`);
            return;
        }

        lastMemeTimes.set(channelId, now);


        // Fetch meme from random API
        const meme = await fetchMemeFromRandomAPI();
        
        if (!meme) {
            console.log(`❌ No meme fetched for ${guild.name}`);
            return;
        }


        // Random emoji for description
        const randomEmoji = CUSTOM_EMOJIS[Math.floor(Math.random() * CUSTOM_EMOJIS.length)];

        // Create embed
        const embed = new EmbedBuilder()
            .setColor("#fe8200")
            .setAuthor({ 
                name: guild.name, 
                iconURL: client.user.displayAvatarURL({ dynamic: true })
            })
            .setDescription(`${randomEmoji} **[${meme.title}](${meme.postLink})**`)
            .setImage(meme.url)
            .setTimestamp();

        const sentMessage = await channel.send({ embeds: [embed] });

        // Auto-publish if announcement channel
        if (channel.type === 5) { // 5 = GUILD_NEWS (Announcement Channel)
            try {
                await sentMessage.crosspost();
            } catch (publishError) {
                console.log(`⚠️ Could not publish: ${publishError.message}`);
            }
        }

    } catch (error) {
        console.error(`❌ Error sending meme to ${serverId}:`, error.message);
        
        // If error is rate limit, add extra delay
        if (error.message.includes("rate limit") || error.code === 429) {
            console.log(`⚠️ Rate limited on ${serverId}, adding 2 minute delay...`);
            lastMemeTimes.set(channelId, Date.now() + 120000); // Add 2 minute delay
        }
    }
}

async function fetchMemeFromRandomAPI() {
    // Select random API
    const randomAPI = MEME_APIS[Math.floor(Math.random() * MEME_APIS.length)];
    
    
    let attempts = 0;
    const maxAttempts = 3;

    while (attempts < maxAttempts) {
        try {
            const response = await fetch(randomAPI.url, {
                headers: {
                    'User-Agent': 'TuZhi-Bot/2.0'
                }
            });

            if (!response.ok) {
                throw new Error(`API error: ${response.status}`);
            }

            const data = await response.json();
            const parsed = randomAPI.parse(data);

            // Validate meme data
            if (!parsed.url || !parsed.title || !parsed.isValid) {
                console.log("⚠️ Invalid/NSFW meme, retrying...");
                attempts++;
                continue;
            }

            // Truncate long titles
            if (parsed.title.length > 200) {
                parsed.title = parsed.title.substring(0, 197) + "...";
            }

            return {
                title: parsed.title,
                url: parsed.url,
                postLink: parsed.postLink
            };

        } catch (error) {
            console.error(`❌ Fetch error (attempt ${attempts + 1}):`, error.message);
            attempts++;
            
            // If this API fails, try another random one
            if (attempts < maxAttempts) {
                const anotherAPI = MEME_APIS[Math.floor(Math.random() * MEME_APIS.length)];
                console.log(`🔄 Trying another API: ${anotherAPI.name}`);
                randomAPI.url = anotherAPI.url;
                randomAPI.name = anotherAPI.name;
                randomAPI.parse = anotherAPI.parse;
            }
            
            await new Promise(resolve => setTimeout(resolve, 2000)); // Wait 2s between attempts
        }
    }

    console.error("❌ All fetch attempts failed");
    return null;
}

function isImageUrl(url) {
    const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.webp'];
    const lowerUrl = url.toLowerCase();
    return imageExtensions.some(ext => lowerUrl.includes(ext)) || 
           lowerUrl.includes('i.redd.it') || 
           lowerUrl.includes('preview.redd.it');
}

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('\n⚠️ Stopping meme senders...');
    for (const interval of memeIntervals.values()) {
        clearInterval(interval);
    }
});

process.on('SIGTERM', () => {
    for (const interval of memeIntervals.values()) {
        clearInterval(interval);
    }
});