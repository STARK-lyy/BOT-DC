// events/messageCreate.js
import { Events } from "discord.js";
import fs from "fs";
import path from "path";

const dataDir = "./data";
const dataFile = path.join(dataDir, "count.json");

function loadData() {
  try { return JSON.parse(fs.readFileSync(dataFile)); } 
  catch { fs.writeFileSync(dataFile, "{}"); return {}; }
}

function saveData(json) { fs.writeFileSync(dataFile, JSON.stringify(json, null, 4)); }

export default {
  name: Events.MessageCreate,
  async execute(message) {
    if (message.author.bot) return;

    const guildId = message.guild.id;
    const allData = loadData();
    const cfg = allData[guildId];
    if (!cfg || !cfg.channelId || message.channel.id !== cfg.channelId) return;

    const expected = cfg.count;
    const lastUserId = cfg.lastUserId || null;
    const content = message.content.trim();

    if (parseInt(content) === expected) {
      if (message.author.id === lastUserId) {
        // Same user consecutively → delete + warn
        try {
          await message.delete();
          const warnMsg = await message.channel.send({
            content: `⚠️ ${message.author}, you cannot send the same count consecutively. Expected: **${expected}**`
          });
          setTimeout(() => warnMsg.delete().catch(() => {}), 4000);
        } catch (err) { console.error(err); }
        return;
      }

      // ✅ Correct count by different user
      try { await message.react("✅"); } catch {}
      cfg.count++;
      cfg.lastUserId = message.author.id;
      allData[guildId] = cfg;
      saveData(allData);

    } else {
      // Wrong number → delete + warn
      try {
        await message.delete();
        const warnMsg = await message.channel.send({
          content: `⚠️ ${message.author}, invalid number. Expected: **${expected}**`
        });
        setTimeout(() => warnMsg.delete().catch(() => {}), 5000);
      } catch (err) { console.error(err); }
    }
  }
};