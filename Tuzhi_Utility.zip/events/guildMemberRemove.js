import fs from 'fs';
import { EmbedBuilder } from 'discord.js';
const dataPath = './data/autoban.json';

export default {
    name: 'guildMemberRemove',
    async execute(member) {
        if (!member || member.user.bot) return;

        // Load JSON
        const json = fs.existsSync(dataPath) ? JSON.parse(fs.readFileSync(dataPath)) : {};
        const guildData = json[member.guild.id];
        if (!guildData || !guildData.autoban) return;

        // Agar member list me nahi hai to return
        if (!guildData.members.includes(member.id)) return;

        // Embed create
        const embed = new EmbedBuilder()
            .setTitle(`<:TuZhi_Utility_Secured:1433861508328329349> **\`${member.user.username}\`** Banned`)
            .setDescription(
                `<:TuZhi_Utility:1434040425760428103> **Server:** ${member.guild.name}\n\n` +
                `<:TuZhi_Utility_User:1433852028207104145> **User:**\n<@${member.id}>\n` +
                `<:TuZhi_Utility_HasTag:1433860789344800781> **UserID:**\n\`${member.id}\`\n` +
                `  <:TuZhi_Utility_Two_Arrow:1433864767570706605> **Reason:**\n\`Left Server\``
            )
            .setColor('#fe8200')
            .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
            .setImage('https://cdn.discordapp.com/attachments/1321820927930925136/1425824339130978324/standard_3.gif')
            .setFooter({ text: `${member.user.username} banned Don't Back Again`, iconURL: member.guild.iconURL({ dynamic: true }) })
            .setTimestamp();

        // DM user
        try {
            await member.send({ embeds: [embed] });
        } catch {}

        // Ban user using guild.bans.create with ID
        try {
            await member.guild.bans.create(member.id, { reason: 'Left while autoban active' });
            console.log(`✅ Banned ${member.user.tag}`);

            // Remove from JSON
            guildData.members = guildData.members.filter(id => id !== member.id);
            fs.writeFileSync(dataPath, JSON.stringify(json, null, 4));

            // Log channel
            if (guildData.autobanChannel) {
                const channel = member.guild.channels.cache.get(guildData.autobanChannel);
                if (channel && channel.isTextBased()) {
                    channel.send({ embeds: [embed] }).catch(() => {});
                }
            }
        } catch (err) {
            console.log(`❌ Could not ban ${member.user.tag}:`, err);
        }
    }
};