// ============================================
// events/ai/ai.js - AI Event Handler (Fixed)
// ============================================

import { Events, AttachmentBuilder } from "discord.js";
import { 
    isAIChannel, 
    generateAIResponse, 
    isStopCommand, 
    isOnCooldown, 
    setCooldown, 
    updateServerInfo 
} from "../../utils/aiHandler.js";

console.log("✅ AI Event Handler loaded!");

export default {
    name: Events.MessageCreate,
    
    async execute(message, client) {
        try {
            // Basic validation
            if (!message || message.author?.bot || !message.guild) return;
            
            // Check if AI enabled in channel
            if (!isAIChannel(message.channelId)) return;

            console.log(`📨 [MESSAGE] ${message.author.username}: "${message.content.substring(0, 50)}"`);

            const content = message.content?.trim() || "";
            
            // Extract attachments
            const attachments = [];
            if (message.attachments && message.attachments.size > 0) {
                message.attachments.forEach(att => {
                    attachments.push({
                        name: att.name,
                        url: att.url,
                        contentType: att.contentType,
                        size: att.size
                    });
                    console.log(`📎 Attachment: ${att.name}`);
                });
            }

            // Extract stickers
            const stickers = [];
            if (message.stickers && message.stickers.size > 0) {
                message.stickers.forEach(sticker => {
                    stickers.push({
                        name: sticker.name,
                        id: sticker.id,
                        url: sticker.url
                    });
                    console.log(`🎨 Sticker: ${sticker.name}`);
                });
            }

            // Get mentioned user (excluding bot)
            let mentionedUser = null;
            if (message.mentions?.users?.size > 0) {
                const mentions = Array.from(message.mentions.users.values());
                mentionedUser = mentions.find(u => u.id !== client.user.id);
                if (mentionedUser) {
                    console.log(`👤 Mentioned: ${mentionedUser.username}`);
                }
            }

            // Advanced reply handling
            let replyContext = null;
            if (message.reference) {
                try {
                    const replyToMessage = await message.channel.messages.fetch(message.reference.messageId);
                    
                    if (replyToMessage.author.id !== message.author.id) {
                        replyContext = {
                            authorId: replyToMessage.author.id,
                            authorUsername: replyToMessage.author.username,
                            content: replyToMessage.content,
                            isBot: replyToMessage.author.bot
                        };
                        console.log(`📧 Reply to: ${replyContext.authorUsername}`);
                    } else {
                        replyContext = {
                            authorId: message.author.id,
                            authorUsername: message.author.username,
                            content: replyToMessage.content,
                            isBot: false,
                            isSelf: true
                        };
                        console.log(`📧 User replied to self`);
                    }
                } catch (err) {
                    console.log("⚠️ Could not fetch replied message");
                }
            }

            // Update server info
            try {
                updateServerInfo(message.guild);
            } catch (err) {
                console.error("Server update error:", err.message);
            }

            // Stop command
            if (isStopCommand(content)) {
                await message.reply("Okay! I'll stop 👍").catch(() => {});
                return;
            }

            // Cooldown check
            const cooldown = isOnCooldown(message.author.id, message.channelId);
            if (cooldown > 0) {
                await message.react('⏰').catch(() => {});
                return;
            }

            setCooldown(message.author.id, message.channelId);

            // Typing indicator
            let typingInterval;
            try {
                typingInterval = setInterval(() => {
                    message.channel.sendTyping().catch(() => {});
                }, 5000);
                await message.channel.sendTyping().catch(() => {});
            } catch (err) {
                console.error("Typing error:", err.message);
            }

            try {
                console.log(`🤖 Generating AI response...`);
                
                const response = await generateAIResponse(
                    content,
                    message.author.id,
                    message.author.username,
                    client,
                    message.guild.id,
                    attachments,
                    stickers,
                    message.guild,
                    mentionedUser,
                    replyContext
                );

                if (typingInterval) clearInterval(typingInterval);

                if (!response || response.length === 0) {
                    throw new Error("Empty response");
                }

                console.log(`✅ Response generated (${response.length} chars)`);
                
                // Send response
                await handleResponse(message, response);
                
                console.log(`✅ Response sent successfully!`);

            } catch (error) {
                if (typingInterval) clearInterval(typingInterval);
                console.error(`❌ AI Error:`, error.message);
                
                try {
                    await message.reply({
                        content: "😅 Oops! Something went wrong. Try again?",
                        allowedMentions: { repliedUser: false }
                    });
                } catch (err) {
                    await message.react('😅').catch(() => {});
                }
            }

        } catch (error) {
            console.error(`❌ Fatal Error:`, error.message);
        }
    }
};

// ========== Response Handler ==========
async function handleResponse(message, response) {
    try {
        // Extract code blocks
        const codeBlocks = extractCodeBlocks(response);
        
        if (codeBlocks.length === 0) {
            // No code - send normal message
            await sendSplitMessage(message, response);
            return;
        }

        // Create file attachments
        const files = [];
        let textContent = response;

        for (let i = 0; i < codeBlocks.length; i++) {
            const block = codeBlocks[i];
            const fileName = block.fileName || `code_${i + 1}${getExtension(block.language)}`;
            
            const buffer = Buffer.from(block.code, 'utf-8');
            files.push(new AttachmentBuilder(buffer, { name: fileName }));
            
            textContent = textContent.replace(block.fullMatch, `\n📎 **File:** ${fileName}\n`);
        }

        // Remove FILE: lines
        textContent = textContent.replace(/FILE:\s*[^\n]+/gi, '').trim();
        textContent = textContent.replace(/\n{3,}/g, '\n\n');

        // Send with files
        if (textContent.length > 2000) {
            const chunks = splitMessage(textContent);
            
            await message.reply({
                content: chunks[0],
                files: files,
                allowedMentions: { repliedUser: false }
            });
            
            for (let i = 1; i < chunks.length; i++) {
                await message.channel.send(chunks[i]);
                await sleep(500);
            }
        } else {
            await message.reply({
                content: textContent || 'Here are your files:',
                files: files,
                allowedMentions: { repliedUser: false }
            });
        }
        
    } catch (error) {
        console.error('Response handling error:', error);
        await sendSplitMessage(message, response);
    }
}

// ========== Extract Code Blocks ==========
function extractCodeBlocks(text) {
    const blocks = [];
    const regex = /```(\w+)?\n([\s\S]+?)```/g;
    let match;
    
    while ((match = regex.exec(text)) !== null) {
        const language = match[1] || 'txt';
        const code = match[2].trim();
        const fullMatch = match[0];
        
        const fileRegex = /FILE:\s*([^\n]+)/i;
        const fileMatch = text.substring(match.index, match.index + 200).match(fileRegex);
        const fileName = fileMatch ? fileMatch[1].trim() : null;
        
        blocks.push({
            language,
            code,
            fileName,
            fullMatch
        });
    }
    
    return blocks;
}

// ========== Get File Extension ==========
function getExtension(language) {
    const extensions = {
        'javascript': '.js', 'js': '.js',
        'typescript': '.ts', 'ts': '.ts',
        'python': '.py', 'py': '.py',
        'java': '.java',
        'cpp': '.cpp', 'c++': '.cpp',
        'c': '.c',
        'csharp': '.cs', 'cs': '.cs',
        'html': '.html',
        'css': '.css',
        'json': '.json',
        'xml': '.xml',
        'sql': '.sql',
        'shell': '.sh', 'bash': '.sh',
        'powershell': '.ps1',
        'ruby': '.rb',
        'go': '.go',
        'rust': '.rs',
        'php': '.php',
        'swift': '.swift',
        'kotlin': '.kt',
        'txt': '.txt'
    };
    
    return extensions[language.toLowerCase()] || '.txt';
}

// ========== Split Message (2000 char limit) ==========
function splitMessage(text, maxLength = 2000) {
    if (text.length <= maxLength) return [text];
    
    const chunks = [];
    let currentChunk = '';
    
    const paragraphs = text.split('\n\n');
    
    for (const para of paragraphs) {
        if ((currentChunk + para).length > maxLength) {
            if (currentChunk) {
                chunks.push(currentChunk.trim());
                currentChunk = '';
            }
            
            if (para.length > maxLength) {
                const sentences = para.split('. ');
                for (const sentence of sentences) {
                    if ((currentChunk + sentence).length > maxLength) {
                        if (currentChunk) {
                            chunks.push(currentChunk.trim());
                            currentChunk = '';
                        }
                        if (sentence.length > maxLength) {
                            for (let i = 0; i < sentence.length; i += maxLength) {
                                chunks.push(sentence.substring(i, i + maxLength));
                            }
                        } else {
                            currentChunk = sentence + '. ';
                        }
                    } else {
                        currentChunk += sentence + '. ';
                    }
                }
            } else {
                currentChunk = para + '\n\n';
            }
        } else {
            currentChunk += para + '\n\n';
        }
    }
    
    if (currentChunk.trim()) {
        chunks.push(currentChunk.trim());
    }
    
    return chunks;
}

// ========== Send Split Message ==========
async function sendSplitMessage(message, text) {
    const chunks = splitMessage(text);
    
    await message.reply({
        content: chunks[0],
        allowedMentions: { repliedUser: false }
    });
    
    for (let i = 1; i < chunks.length; i++) {
        await message.channel.send(chunks[i]);
        await sleep(500);
    }
}

// ========== Sleep Utility ==========
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}