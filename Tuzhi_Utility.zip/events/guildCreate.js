// events/guildAdd.js
import { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } from "discord.js";

export default {
    name: "guildCreate",
    async execute(guild, client) {
        const botIcon = client.user.displayAvatarURL();
        const supportLink = "https://discord.gg/Zuaa5tH58y";
        const embedImage = "https://cdn.discordapp.com/attachments/1432379942447878288/1434071850517794938/standard_2.gif";

        // Embed construction
        const embed = new EmbedBuilder()
            .setColor("#fe8200")
            .setTitle(`Thank you for adding **TuZhi Utility**!`)
            .setDescription(
                `> <:TuZhi_Utility:1434040425760428103> **TuZhi Utility** has been added to \`${guild.name}\` successfully!\n\n` +
                `**TuZhi Utility is a lightweight bot providing fun and utility commands like memes, emoji stealing, moderation tools, and more!**`
            )
            .setImage(embedImage)
            .setFooter({ text: "Thanks for add TuZhi Utility!", iconURL: botIcon });

        // Support button
        const buttonRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setLabel("Support")
                .setStyle(ButtonStyle.Link)
                .setURL(supportLink)
        );

        // Try sending DM to server owner
        try {
            await guild.owner.send({ embeds: [embed], components: [buttonRow] });
        } catch (errOwner) {
            console.log(`🔴 Owner DM failed for guild "${guild.name}", attempting to DM adder...`);
            const meMember = guild.members.cache.get(client.user.id);
            if (meMember && meMember.joinedAt) {
                try {
                    await meMember.send({ embeds: [embed], components: [buttonRow] });
                } catch (errAdder) {
                    console.log(`❌ DM to bot adder failed in guild "${guild.name}".`);
                }
            } else {
                console.log(`❌ No suitable member to DM in guild "${guild.name}".`);
            }
        }

        // Send same embed to first available text channel in the server
        const targetChannel = guild.channels.cache
            .filter(ch => ch.isTextBased() && ch.permissionsFor(guild.members.me).has("SendMessages"))
            .first();
        if (targetChannel) {
            try {
                await targetChannel.send({ embeds: [embed], components: [buttonRow] });
            } catch (err) {
                console.log(`🚫 Failed to send embed in channel ${targetChannel.name} of guild "${guild.name}".`);
            }
        } else {
            console.log(`🚫 No suitable text channel to send welcome message in guild "${guild.name}".`);
        }
    }
};