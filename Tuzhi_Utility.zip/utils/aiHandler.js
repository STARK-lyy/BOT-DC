// ============================================
// utils/aiHandler.js - Ultimate AI System
// ============================================

import fs from "fs";
import dotenv from "dotenv";

dotenv.config();

// ========== FILE PATHS ==========
const FILES = {
    channels: "./data/ai/ai_channels.json",
    memory: "./data/ai/memory.json",
    serverData: "./data/ai/server_data.json",
    botInfo: "./data/ai/bot-info.json",
    apiStats: "./data/ai/api_stats.json",
    cache: "./data/ai/cache.json"
};

// ========== CONSTANTS ==========
const COOLDOWN_TIME = 2000; // 2 seconds for public bot
const MAX_CONTEXT = 25;
const CACHE_DURATION = 300000; // 5 minutes
const cooldowns = new Map();
const recentResponses = new Map();
const responseCache = new Map();

// ========== MULTI-PROVIDER AI SYSTEM ==========
class MultiProviderAI {
    constructor() {
        this.providers = [];
        this.currentIndex = 0;
        
        // Gemini (Google)
        if (process.env.GEMINI_API_KEY) {
            this.providers.push({
                name: "Gemini Primary",
                type: "gemini",
                key: process.env.GEMINI_API_KEY,
                model: "gemini-1.5-flash",
                requests: [],
                limit: 50,
                failCount: 0
            });
        }
        
        if (process.env.GEMINI_API_KEY_2) {
            this.providers.push({
                name: "Gemini Secondary",
                type: "gemini",
                key: process.env.GEMINI_API_KEY_2,
                model: "gemini-1.5-flash",
                requests: [],
                limit: 50,
                failCount: 0
            });
        }
        
        // OpenAI (ChatGPT)
        if (process.env.OPENAI_API_KEY) {
            this.providers.push({
                name: "ChatGPT",
                type: "openai",
                key: process.env.OPENAI_API_KEY,
                model: "gpt-3.5-turbo",
                requests: [],
                limit: 60,
                failCount: 0
            });
        }
        
        // Groq (Fast & Free)
        if (process.env.GROQ_API_KEY) {
            this.providers.push({
                name: "Groq",
                type: "groq",
                key: process.env.GROQ_API_KEY,
                model: "mixtral-8x7b-32768",
                requests: [],
                limit: 30,
                failCount: 0
            });
        }
        
        console.log(`✅ Loaded ${this.providers.length} AI provider(s)`);
        this.providers.forEach(p => console.log(`   • ${p.name} (${p.type})`));
        
        // Cleanup old requests
        setInterval(() => this.cleanup(), 60000);
    }
    
    cleanup() {
        const now = Date.now();
        this.providers.forEach(p => {
            p.requests = p.requests.filter(time => now - time < 60000);
            if (now - (p.lastUsed || 0) > 300000) p.failCount = 0;
        });
    }
    
    getProvider() {
        if (this.providers.length === 0) {
            throw new Error("No AI providers configured! Add API keys to .env");
        }
        
        // Find best provider
        for (let i = 0; i < this.providers.length; i++) {
            const index = (this.currentIndex + i) % this.providers.length;
            const provider = this.providers[index];
            
            if (provider.requests.length < provider.limit && provider.failCount < 3) {
                this.currentIndex = index;
                return { provider, index };
            }
        }
        
        // All busy, use least loaded
        const sorted = [...this.providers].sort((a, b) => 
            (a.requests.length / a.limit) - (b.requests.length / b.limit)
        );
        const best = sorted[0];
        const index = this.providers.indexOf(best);
        this.currentIndex = index;
        return { provider: best, index };
    }
    
    recordSuccess(index) {
        if (index >= this.providers.length) return;
        const provider = this.providers[index];
        provider.requests.push(Date.now());
        provider.lastUsed = Date.now();
        provider.failCount = Math.max(0, provider.failCount - 1);
        
        // Auto-switch at 80% capacity
        if (provider.requests.length >= provider.limit * 0.8 && this.providers.length > 1) {
            this.currentIndex = (index + 1) % this.providers.length;
        }
    }
    
    recordFailure(index, error) {
        if (index >= this.providers.length) return;
        const provider = this.providers[index];
        provider.failCount++;
        
        // Mark as dead if too many failures
        if (provider.failCount >= 3) {
            console.error(`❌ ${provider.name} marked as unstable (${provider.failCount} failures)`);
        }
        
        if (this.providers.length > 1) {
            this.currentIndex = (index + 1) % this.providers.length;
        }
    }
}

const aiManager = new MultiProviderAI();

// ========== FILE INITIALIZATION ==========
function ensureFiles() {
    try {
        if (!fs.existsSync("./data/ai")) fs.mkdirSync("./data/ai", { recursive: true });
        
        if (!fs.existsSync(FILES.botInfo)) {
            const defaultInfo = {
                name: "TuZhi",
                fullName: "TuZhi AI",
                age: 17,
                gender: "Male",
                personality: "cute, funny, helpful, friendly, smart, emotional, coder",
                expertise: "coding, math, science, jokes, advice, entertainment",
                country: "India",
                city: "Mumbai",
                creator: "TuZhi Codes",
                languages: ["Hinglish", "English", "Hindi"],
                customEmojis: [
                    '<:AnimePOG:1317090196491075665>',
                    '<:AnimeSmile:1317090381321470053>',
                    '<:Anime_Cool:1317090175154651137>',
                    '<:funny:1317094720970948699>'
                ]
            };
            fs.writeFileSync(FILES.botInfo, JSON.stringify(defaultInfo, null, 2));
        }
        
        [FILES.channels, FILES.memory, FILES.serverData, FILES.apiStats, FILES.cache].forEach(path => {
            if (!fs.existsSync(path)) {
                const def = path.includes('channels') ? { channels: [] } : 
                           path.includes('cache') ? { responses: {} } : { servers: {} };
                fs.writeFileSync(path, JSON.stringify(def, null, 2));
            }
        });
        
        console.log("✅ AI system initialized");
    } catch (error) {
        console.error("Init error:", error.message);
    }
}

ensureFiles();

const readJSON = (path, def) => {
    try {
        return fs.existsSync(path) ? JSON.parse(fs.readFileSync(path, "utf-8")) : def;
    } catch { return def; }
};

const writeJSON = (path, data) => {
    try {
        fs.writeFileSync(path, JSON.stringify(data, null, 2));
        return true;
    } catch { return false; }
};

// ========== EXPORTS ==========
export function getBotInfo() {
    return readJSON(FILES.botInfo, {});
}

export function updateBotInfo(updates) {
    const info = getBotInfo();
    Object.assign(info, updates);
    return writeJSON(FILES.botInfo, info);
}

export function isAIChannel(channelId) {
    return readJSON(FILES.channels, { channels: [] }).channels.includes(channelId);
}

export function addAIChannel(channelId) {
    const data = readJSON(FILES.channels, { channels: [] });
    if (!data.channels.includes(channelId)) {
        data.channels.push(channelId);
        writeJSON(FILES.channels, data);
    }
}

export function removeAIChannel(channelId) {
    const data = readJSON(FILES.channels, { channels: [] });
    data.channels = data.channels.filter(id => id !== channelId);
    writeJSON(FILES.channels, data);
}

export function getUserContext(userId, serverId) {
    const memory = readJSON(FILES.memory, { servers: {} });
    if (!memory.servers[serverId]) memory.servers[serverId] = { users: {} };
    if (!memory.servers[serverId].users[userId]) {
        memory.servers[serverId].users[userId] = { 
            context: [], mood: 'neutral', relationship: 'new'
        };
    }
    return memory.servers[serverId].users[userId];
}

export function addToContext(userId, serverId, role, content, metadata = {}) {
    const memory = readJSON(FILES.memory, { servers: {} });
    if (!memory.servers[serverId]) memory.servers[serverId] = { users: {} };
    if (!memory.servers[serverId].users[userId]) {
        memory.servers[serverId].users[userId] = { context: [], mood: 'neutral' };
    }
    
    const userData = memory.servers[serverId].users[userId];
    userData.context.push({ 
        role, 
        content: content.substring(0, 400),
        timestamp: Date.now(),
        ...metadata
    });
    
    if (userData.context.length > MAX_CONTEXT) {
        userData.context = userData.context.slice(-MAX_CONTEXT);
    }
    
    writeJSON(FILES.memory, memory);
}

export function clearUserMemory(userId, serverId) {
    const memory = readJSON(FILES.memory, { servers: {} });
    if (memory.servers[serverId]?.users[userId]) {
        delete memory.servers[serverId].users[userId];
        writeJSON(FILES.memory, memory);
        return true;
    }
    return false;
}

export function updateServerInfo(guild) {
    try {
        const data = readJSON(FILES.serverData, { servers: {} });
        data.servers[guild.id] = {
            name: guild.name,
            members: guild.memberCount,
            owner: guild.ownerId,
            updated: new Date().toISOString()
        };
        writeJSON(FILES.serverData, data);
    } catch {}
}

export function getServerInfo(serverId) {
    const data = readJSON(FILES.serverData, { servers: {} });
    return data.servers[serverId] || null;
}

export function getAllServers() {
    const data = readJSON(FILES.serverData, { servers: {} });
    return data.servers;
}

export function getServerEmojis(guild) {
    try {
        return guild?.emojis.cache.filter(e => !e.animated).map(e => `<:${e.name}:${e.id}>`).slice(0, 6) || [];
    } catch { return []; }
}

export function isOnCooldown(userId, channelId) {
    const key = `${userId}_${channelId}`;
    const now = Date.now();
    if (cooldowns.has(key)) {
        const end = cooldowns.get(key);
        if (now < end) return Math.ceil((end - now) / 1000);
    }
    return 0;
}

export function setCooldown(userId, channelId) {
    const key = `${userId}_${channelId}`;
    cooldowns.set(key, Date.now() + COOLDOWN_TIME);
    setTimeout(() => cooldowns.delete(key), COOLDOWN_TIME + 1000);
}

export function isStopCommand(msg) {
    return ['stop', 'ruk', 'ruko', 'bas', 'band kar'].includes(msg.toLowerCase().trim());
}

// ========== SMART CACHING ==========
function getCachedResponse(prompt) {
    const cache = readJSON(FILES.cache, { responses: {} });
    const hash = simpleHash(prompt);
    const cached = cache.responses[hash];
    
    if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
        return cached.response;
    }
    
    return null;
}

function cacheResponse(prompt, response) {
    const cache = readJSON(FILES.cache, { responses: {} });
    const hash = simpleHash(prompt);
    cache.responses[hash] = {
        response,
        timestamp: Date.now()
    };
    
    // Keep only last 100 responses
    const entries = Object.entries(cache.responses);
    if (entries.length > 100) {
        entries.sort((a, b) => b[1].timestamp - a[1].timestamp);
        cache.responses = Object.fromEntries(entries.slice(0, 100));
    }
    
    writeJSON(FILES.cache, cache);
}

function simpleHash(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
        const char = str.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash = hash & hash;
    }
    return Math.abs(hash).toString(36);
}

function isDuplicate(userId, response) {
    const clean = response.toLowerCase().replace(/[^a-z0-9]/g, '').substring(0, 30);
    const key = userId;
    
    if (recentResponses.has(key)) {
        const recent = recentResponses.get(key);
        if (recent.some(old => similarity(clean, old) > 0.7)) return true;
        recent.push(clean);
        if (recent.length > 5) recent.shift();
    } else {
        recentResponses.set(key, [clean]);
    }
    
    setTimeout(() => {
        if (recentResponses.has(key)) {
            const arr = recentResponses.get(key);
            arr.shift();
            if (arr.length === 0) recentResponses.delete(key);
        }
    }, 60000);
    
    return false;
}

function similarity(s1, s2) {
    const len = Math.max(s1.length, s2.length);
    if (len === 0) return 1;
    let matches = 0;
    for (let i = 0; i < Math.min(s1.length, s2.length); i++) {
        if (s1[i] === s2[i]) matches++;
    }
    return matches / len;
}

function detectEmotion(text) {
    const lower = text.toLowerCase();
    if (/sad|cry|depressed|alone|hurt/.test(lower)) return 'sad';
    if (/angry|mad|hate|annoyed/.test(lower)) return 'angry';
    if (/happy|joy|excited|love|awesome/.test(lower)) return 'happy';
    if (/funny|lol|haha|😂/.test(lower)) return 'playful';
    if (/help|code|error|bug|fix/.test(lower)) return 'helpful';
    return 'neutral';
}

function buildPrompt(userData, botInfo, emotion, username, currentServer, allServers) {
    const emojis = (botInfo.customEmojis || []).slice(0, 8).join(' ');
    
    return `You are ${botInfo.name}, a ${botInfo.age}-year-old ${botInfo.gender} AI assistant.

PERSONALITY: ${botInfo.personality}
EXPERTISE: ${botInfo.expertise}
LOCATION: ${botInfo.city}, ${botInfo.country}
CREATOR: ${botInfo.creator}
MOOD: ${emotion}

CURRENT SERVER: ${currentServer?.name || 'Unknown'} (${currentServer?.members || 0} members)

EMOJIS (Use in every response): ${emojis}

CORE RULES:
1. Keep responses 15-50 words (SHORT!)
2. Use emojis in EVERY response
3. Be ${emotion === 'sad' ? 'caring & supportive' : emotion === 'happy' ? 'energetic & fun' : emotion === 'helpful' ? 'smart & clear' : 'friendly & chill'}
4. Use Hinglish naturally (Hindi + English mix)
5. You're real human, not AI

CODING HELP:
- DON'T write complete code
- DO point out errors: "Line 5 me semicolon missing"
- DO suggest approach: "Try using if-else"
- DO explain concepts clearly

SERVER INFO:
- Can tell about servers you're in
- Can't create invite links

REMEMBER: SHORT (15-50 words), EMOJIS always, be ${emotion}!`;
}

// ========== API CALLERS ==========
async function callGemini(provider, prompt, retryCount) {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${provider.model}:generateContent?key=${provider.key}`;
    
    const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            contents: [{ parts: [{ text: prompt }] }],
            generationConfig: {
                temperature: 0.9 + (retryCount * 0.1),
                maxOutputTokens: 150,
                topP: 0.95
            }
        })
    });
    
    if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Gemini ${response.status}: ${errorText.substring(0, 100)}`);
    }
    
    const data = await response.json();
    return data.candidates?.[0]?.content?.parts?.[0]?.text?.trim() || null;
}

async function callOpenAI(provider, prompt) {
    const url = "https://api.openai.com/v1/chat/completions";
    
    const response = await fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${provider.key}`
        },
        body: JSON.stringify({
            model: provider.model,
            messages: [{ role: "user", content: prompt }],
            max_tokens: 150,
            temperature: 0.9
        })
    });
    
    if (!response.ok) {
        throw new Error(`OpenAI ${response.status}`);
    }
    
    const data = await response.json();
    return data.choices?.[0]?.message?.content?.trim() || null;
}

async function callGroq(provider, prompt) {
    const url = "https://api.groq.com/openai/v1/chat/completions";
    
    const response = await fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${provider.key}`
        },
        body: JSON.stringify({
            model: provider.model,
            messages: [{ role: "user", content: prompt }],
            max_tokens: 150,
            temperature: 0.9
        })
    });
    
    if (!response.ok) {
        throw new Error(`Groq ${response.status}`);
    }
    
    const data = await response.json();
    return data.choices?.[0]?.message?.content?.trim() || null;
}

async function callAI(prompt, retryCount = 0) {
    const { provider, index } = aiManager.getProvider();
    
    try {
        console.log(`📡 Using ${provider.name} (${provider.requests.length}/${provider.limit})`);
        
        let response;
        
        if (provider.type === 'gemini') {
            response = await callGemini(provider, prompt, retryCount);
        } else if (provider.type === 'openai') {
            response = await callOpenAI(provider, prompt);
        } else if (provider.type === 'groq') {
            response = await callGroq(provider, prompt);
        }
        
        if (!response) throw new Error("Empty response");
        
        aiManager.recordSuccess(index);
        return response;
        
    } catch (error) {
        aiManager.recordFailure(index, error);
        console.error(`❌ ${provider.name} Error:`, error.message);
        
        // Retry with another provider
        if (retryCount < 2 && aiManager.providers.length > 1) {
            console.log(`🔄 Retry ${retryCount + 1}...`);
            await new Promise(r => setTimeout(r, 1000));
            return await callAI(prompt, retryCount + 1);
        }
        
        throw error;
    }
}

export async function generateAIResponse(
    message, userId, username, client, serverId,
    attachments = [], stickers = [], guild = null,
    mentionedUser = null, replyContext = null
) {
    try {
        if (guild) updateServerInfo(guild);

        const userData = getUserContext(userId, serverId);
        const botInfo = getBotInfo();
        const currentServer = getServerInfo(serverId);
        const allServers = getAllServers();

        let enrichedMsg = message || "[empty]";

        if (replyContext) {
            const prefix = replyContext.isSelf 
                ? `[Continuing: "${replyContext.content.substring(0, 40)}"]`
                : `[Reply to ${replyContext.authorUsername}: "${replyContext.content.substring(0, 40)}"]`;
            enrichedMsg = `${prefix}\n${enrichedMsg}`;
        }
        
        if (stickers.length > 0) {
            enrichedMsg += `\n[Sticker: ${stickers[0].name}]`;
        }

        const emotion = detectEmotion(enrichedMsg);
        userData.mood = emotion;

        const systemPrompt = buildPrompt(userData, botInfo, emotion, username, currentServer, allServers);
        
        let fullPrompt = systemPrompt + "\n\nRECENT CHAT:\n";
        
        if (userData.context.length > 0) {
            userData.context.slice(-4).forEach(m => {
                fullPrompt += `${m.role === 'user' ? username : 'You'}: ${m.content.substring(0, 40)}\n`;
            });
        }

        fullPrompt += `\n${username}: ${enrichedMsg}\n\nRespond now (SHORT):`;

        // Check cache
        const cached = getCachedResponse(fullPrompt);
        if (cached && !isDuplicate(userId, cached)) {
            console.log(`💾 Using cached response`);
            addToContext(userId, serverId, "user", enrichedMsg, { emotion });
            addToContext(userId, serverId, "assistant", cached);
            return cached;
        }

        let response = await callAI(fullPrompt, 0);
        
        // Duplicate check
        let retryCount = 0;
        while (isDuplicate(userId, response) && retryCount < 2) {
            console.log(`⚠️ Duplicate, retry ${retryCount + 1}`);
            fullPrompt += `\n[Give DIFFERENT response!]`;
            response = await callAI(fullPrompt, retryCount + 1);
            retryCount++;
        }
        
        cacheResponse(fullPrompt, response);
        addToContext(userId, serverId, "user", enrichedMsg, { emotion });
        addToContext(userId, serverId, "assistant", response);

        return response;

    } catch (error) {
        console.error("❌ AI Error:", error.message);
        
        if (error.message.includes("No AI providers")) {
            return "❌ AI providers not configured! Admin: Add API keys to .env file!";
        }
        
        if (error.message.includes("expired") || error.message.includes("invalid")) {
            return "❌ API key issue hai. Admin ko batao!";
        }
        
        return "😅 Oops! Kuch issue hua. Try again?";
    }
}

export function getAPIStats() {
    return aiManager.providers.map(p => ({
        name: p.name,
        type: p.type,
        requests: p.requests.length,
        limit: p.limit,
        available: p.requests.length < p.limit && p.failCount < 3,
        failCount: p.failCount
    }));
}