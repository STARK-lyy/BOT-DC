require('dotenv').config();

module.exports = {
    // Discord Configuration
    token: process.env.DISCORD_TOKEN,
    clientId: process.env.CLIENT_ID,
    guildId: process.env.GUILD_ID,
    
    // Admin Configuration
    mainAdminIds: process.env.MAIN_ADMIN_IDS.split(','),
    
    // Pterodactyl Configuration
    pterodactyl: {
        url: process.env.PTERODACTYL_URL,
        apiKey: process.env.PTERODACTYL_API_KEY
    },
    
    // Database
    mongodbUri: process.env.MONGODB_URI,
    
    // Bot Settings
    prefix: process.env.BOT_PREFIX || '!',
    logChannelId: process.env.LOG_CHANNEL_ID,
    
    // Colors for embeds
    colors: {
        primary: 0x5865F2,
        success: 0x57F287,
        error: 0xED4245,
        warning: 0xFEE75C
    }
};