const mongoose = require('mongoose');
const config = require('../config');

const userSchema = new mongoose.Schema({
    discordId: { type: String, required: true, unique: true },
    username: { type: String, required: true },
    pterodactylUserId: { type: String },
    servers: [{
        serverId: String,
        name: String,
        createdAt: Date,
        status: String
    }],
    isAdmin: { type: Boolean, default: false },
    addedBy: { type: String },
    addedAt: { type: Date, default: Date.now }
});

const serverSchema = new mongoose.Schema({
    serverId: { type: String, required: true, unique: true },
    name: { type: String, required: true },
    ownerId: { type: String, required: true },
    node: { type: String },
    egg: { type: String },
    limits: {
        memory: Number,
        disk: Number,
        cpu: Number
    },
    createdAt: { type: Date, default: Date.now },
    status: { type: String, default: 'offline' }
});

const adminSchema = new mongoose.Schema({
    discordId: { type: String, required: true, unique: true },
    username: { type: String, required: true },
    addedBy: { type: String, required: true },
    addedAt: { type: Date, default: Date.now },
    permissions: [String]
});

const User = mongoose.model('User', userSchema);
const Server = mongoose.model('Server', serverSchema);
const Admin = mongoose.model('Admin', adminSchema);

class Database {
    constructor() {
        this.isConnected = false;
    }

    async connect() {
        try {
            await mongoose.connect(config.mongodbUri);
            this.isConnected = true;
            console.log('✅ Connected to MongoDB');
        } catch (error) {
            console.error('❌ MongoDB connection error:', error);
            throw error;
        }
    }

    async disconnect() {
        await mongoose.disconnect();
        this.isConnected = false;
    }

    // User methods
    async createUser(discordId, username, pterodactylUserId = null) {
        const user = new User({
            discordId,
            username,
            pterodactylUserId
        });
        return await user.save();
    }

    async getUser(discordId) {
        return await User.findOne({ discordId });
    }

    async deleteUser(discordId) {
        return await User.findOneAndDelete({ discordId });
    }

    async updateUserServers(discordId, servers) {
        return await User.findOneAndUpdate(
            { discordId },
            { servers },
            { new: true }
        );
    }

    // Admin methods
    async addAdmin(discordId, username, addedBy) {
        const admin = new Admin({
            discordId,
            username,
            addedBy,
            permissions: ['createuser', 'deleteserver', 'deleteuser', 'stop-all']
        });
        return await admin.save();
    }

    async getAdmin(discordId) {
        return await Admin.findOne({ discordId });
    }

    async removeAdmin(discordId) {
        return await Admin.findOneAndDelete({ discordId });
    }

    async getAllAdmins() {
        return await Admin.find({});
    }

    // Server methods
    async createServer(data) {
        const server = new Server(data);
        return await server.save();
    }

    async getServer(serverId) {
        return await Server.findOne({ serverId });
    }

    async deleteServer(serverId) {
        return await Server.findOneAndDelete({ serverId });
    }

    async getAllServers() {
        return await Server.find({});
    }

    async updateServerStatus(serverId, status) {
        return await Server.findOneAndUpdate(
            { serverId },
            { status },
            { new: true }
        );
    }

    async deleteAllServers() {
        return await Server.deleteMany({});
    }

    async deleteAllUsers() {
        return await User.deleteMany({});
    }
}

module.exports = new Database();