const axios = require('axios');
const config = require('../config');

class PterodactylAPI {
    constructor() {
        this.api = axios.create({
            baseURL: config.pterodactyl.url + '/api/application',
            headers: {
                'Authorization': `Bearer ${config.pterodactyl.apiKey}`,
                'Content-Type': 'application/json',
                'Accept': 'Application/vnd.pterodactyl.v1+json'
            }
        });
    }

    // User Management
    async createUser(email, username, first_name, last_name) {
        try {
            const response = await this.api.post('/users', {
                email,
                username,
                first_name,
                last_name
            });
            return response.data.attributes;
        } catch (error) {
            console.error('Error creating Pterodactyl user:', error.response?.data || error.message);
            throw error;
        }
    }

    async getUser(userId) {
        try {
            const response = await this.api.get(`/users/${userId}`);
            return response.data.attributes;
        } catch (error) {
            console.error('Error getting Pterodactyl user:', error.response?.data || error.message);
            throw error;
        }
    }

    async deleteUser(userId) {
        try {
            await this.api.delete(`/users/${userId}`);
            return true;
        } catch (error) {
            console.error('Error deleting Pterodactyl user:', error.response?.data || error.message);
            throw error;
        }
    }

    // Server Management
    async createServer(data) {
        try {
            const response = await this.api.post('/servers', data);
            return response.data.attributes;
        } catch (error) {
            console.error('Error creating server:', error.response?.data || error.message);
            throw error;
        }
    }

    async getServer(serverId) {
        try {
            const response = await this.api.get(`/servers/${serverId}`);
            return response.data.attributes;
        } catch (error) {
            console.error('Error getting server:', error.response?.data || error.message);
            throw error;
        }
    }

    async deleteServer(serverId) {
        try {
            await this.api.delete(`/servers/${serverId}`);
            return true;
        } catch (error) {
            console.error('Error deleting server:', error.response?.data || error.message);
            throw error;
        }
    }

    async getAllServers() {
        try {
            const response = await this.api.get('/servers');
            return response.data.data;
        } catch (error) {
            console.error('Error getting all servers:', error.response?.data || error.message);
            throw error;
        }
    }

    async reinstallServer(serverId) {
        try {
            await this.api.post(`/servers/${serverId}/reinstall`);
            return true;
        } catch (error) {
            console.error('Error reinstalling server:', error.response?.data || error.message);
            throw error;
        }
    }

    async stopServer(serverId) {
        try {
            await this.api.post(`/servers/${serverId}/power`, { signal: 'stop' });
            return true;
        } catch (error) {
            console.error('Error stopping server:', error.response?.data || error.message);
            throw error;
        }
    }

    async stopAllServers() {
        try {
            const servers = await this.getAllServers();
            const results = [];
            
            for (const server of servers) {
                try {
                    await this.stopServer(server.attributes.id);
                    results.push({
                        serverId: server.attributes.id,
                        name: server.attributes.name,
                        status: 'stopped'
                    });
                } catch (error) {
                    results.push({
                        serverId: server.attributes.id,
                        name: server.attributes.name,
                        status: 'error',
                        error: error.message
                    });
                }
            }
            
            return results;
        } catch (error) {
            console.error('Error stopping all servers:', error.response?.data || error.message);
            throw error;
        }
    }
}

module.exports = new PterodactylAPI();