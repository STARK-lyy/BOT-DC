const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const config = require('../config');
const db = require('../utils/database');
const pterodactyl = require('../utils/pterodactyl');

class AdminCommands {
    constructor() {
        this.commands = {
            'createuser': this.createUser.bind(this),
            'createserver': this.createServer.bind(this),
            'deleteserver': this.deleteServer.bind(this),
            'deleteuser': this.deleteUser.bind(this),
            'reinstall-all': this.reinstallAll.bind(this),
            'delete-all': this.deleteAll.bind(this),
            'stop-all': this.stopAll.bind(this),
            'addadmin': this.addAdmin.bind(this)
        };
    }

    async isMainAdmin(userId) {
        return config.mainAdminIds.includes(userId);
    }

    async isAdmin(userId) {
        if (await this.isMainAdmin(userId)) return true;
        const admin = await db.getAdmin(userId);
        return admin !== null;
    }

    async hasPermission(userId, command) {
        if (await this.isMainAdmin(userId)) return true;
        
        const admin = await db.getAdmin(userId);
        if (!admin) return false;
        
        return admin.permissions.includes(command);
    }

    async createUser(interaction) {
        if (!await this.hasPermission(interaction.user.id, 'createuser')) {
            return interaction.reply({ 
                content: '❌ You do not have permission to use this command.',
                ephemeral: true 
            });
        }

        const discordUser = interaction.options.getUser('user');
        const email = interaction.options.getString('email');
        const username = interaction.options.getString('username') || discordUser.username;

        await interaction.deferReply({ ephemeral: true });

        try {
            // Create Pterodactyl user
            const pteroUser = await pterodactyl.createUser(
                email,
                username,
                discordUser.username,
                'User'
            );

            // Create database record
            await db.createUser(
                discordUser.id,
                discordUser.username,
                pteroUser.id
            );

            const embed = new EmbedBuilder()
                .setColor(config.colors.success)
                .setTitle('✅ User Created Successfully')
                .addFields(
                    { name: 'Discord User', value: `<@${discordUser.id}>`, inline: true },
                    { name: 'Username', value: username, inline: true },
                    { name: 'Email', value: email, inline: true },
                    { name: 'Pterodactyl User ID', value: pteroUser.id, inline: true },
                    { name: 'Created At', value: new Date(pteroUser.created_at).toLocaleString(), inline: true }
                )
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });
        } catch (error) {
            const embed = new EmbedBuilder()
                .setColor(config.colors.error)
                .setTitle('❌ Error Creating User')
                .setDescription(`\`\`\`${error.message}\`\`\``)
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });
        }
    }

    async createServer(interaction) {
        if (!await this.hasPermission(interaction.user.id, 'createserver')) {
            return interaction.reply({ 
                content: '❌ You do not have permission to use this command.',
                ephemeral: true 
            });
        }

        const name = interaction.options.getString('name');
        const userId = interaction.options.getString('user_id');
        const node = interaction.options.getString('node') || '1';
        const egg = interaction.options.getString('egg') || '1';
        const memory = interaction.options.getInteger('memory') || 1024;
        const disk = interaction.options.getInteger('disk') || 1024;
        const cpu = interaction.options.getInteger('cpu') || 100;

        await interaction.deferReply({ ephemeral: true });

        try {
            const serverData = {
                name,
                user: userId,
                egg: parseInt(egg),
                docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
                startup: "npm start",
                environment: {
                    USER_UPLOAD: "0",
                    AUTO_UPDATE: "0"
                },
                limits: {
                    memory: memory,
                    swap: 0,
                    disk: disk,
                    io: 500,
                    cpu: cpu
                },
                feature_limits: {
                    databases: 5,
                    backups: 1,
                    allocations: 1
                },
                deploy: {
                    locations: [1],
                    dedicated_ip: false,
                    port_range: []
                }
            };

            const pteroServer = await pterodactyl.createServer(serverData);

            // Save to database
            await db.createServer({
                serverId: pteroServer.id,
                name: pteroServer.name,
                ownerId: userId,
                node: node,
                egg: egg,
                limits: {
                    memory: memory,
                    disk: disk,
                    cpu: cpu
                }
            });

            const embed = new EmbedBuilder()
                .setColor(config.colors.success)
                .setTitle('✅ Server Created Successfully')
                .addFields(
                    { name: 'Server Name', value: pteroServer.name, inline: true },
                    { name: 'Server ID', value: pteroServer.identifier, inline: true },
                    { name: 'Owner ID', value: userId, inline: true },
                    { name: 'Memory', value: `${memory} MB`, inline: true },
                    { name: 'Disk', value: `${disk} MB`, inline: true },
                    { name: 'CPU', value: `${cpu}%`, inline: true },
                    { name: 'Node', value: node, inline: true },
                    { name: 'Egg', value: egg, inline: true }
                )
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });
        } catch (error) {
            const embed = new EmbedBuilder()
                .setColor(config.colors.error)
                .setTitle('❌ Error Creating Server')
                .setDescription(`\`\`\`${error.message}\`\`\``)
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });
        }
    }

    async deleteServer(interaction) {
        if (!await this.hasPermission(interaction.user.id, 'deleteserver')) {
            return interaction.reply({ 
                content: '❌ You do not have permission to use this command.',
                ephemeral: true 
            });
        }

        const serverId = interaction.options.getString('server_id');

        await interaction.deferReply({ ephemeral: true });

        try {
            // Delete from Pterodactyl
            await pterodactyl.deleteServer(serverId);

            // Delete from database
            await db.deleteServer(serverId);

            const embed = new EmbedBuilder()
                .setColor(config.colors.success)
                .setTitle('✅ Server Deleted Successfully')
                .addFields(
                    { name: 'Server ID', value: serverId, inline: true }
                )
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });
        } catch (error) {
            const embed = new EmbedBuilder()
                .setColor(config.colors.error)
                .setTitle('❌ Error Deleting Server')
                .setDescription(`\`\`\`${error.message}\`\`\``)
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });
        }
    }

    async deleteUser(interaction) {
        if (!await this.hasPermission(interaction.user.id, 'deleteuser')) {
            return interaction.reply({ 
                content: '❌ You do not have permission to use this command.',
                ephemeral: true 
            });
        }

        const userId = interaction.options.getString('user_id');

        await interaction.deferReply({ ephemeral: true });

        try {
            // Delete from Pterodactyl
            await pterodactyl.deleteUser(userId);

            // Delete from database
            await db.deleteUser(userId);

            const embed = new EmbedBuilder()
                .setColor(config.colors.success)
                .setTitle('✅ User Deleted Successfully')
                .addFields(
                    { name: 'User ID', value: userId, inline: true }
                )
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });
        } catch (error) {
            const embed = new EmbedBuilder()
                .setColor(config.colors.error)
                .setTitle('❌ Error Deleting User')
                .setDescription(`\`\`\`${error.message}\`\`\``)
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });
        }
    }

    async reinstallAll(interaction) {
        if (!await this.isMainAdmin(interaction.user.id)) {
            return interaction.reply({ 
                content: '❌ Only main admins can use this command.',
                ephemeral: true 
            });
        }

        await interaction.deferReply({ ephemeral: true });

        try {
            const servers = await db.getAllServers();
            let successCount = 0;
            let errorCount = 0;

            for (const server of servers) {
                try {
                    await pterodactyl.reinstallServer(server.serverId);
                    successCount++;
                } catch (error) {
                    errorCount++;
                    console.error(`Error reinstalling server ${server.serverId}:`, error.message);
                }
            }

            const embed = new EmbedBuilder()
                .setColor(config.colors.success)
                .setTitle('🔄 Reinstallation Complete')
                .addFields(
                    { name: 'Total Servers', value: servers.length.toString(), inline: true },
                    { name: 'Successfully Reinstalled', value: successCount.toString(), inline: true },
                    { name: 'Failed', value: errorCount.toString(), inline: true }
                )
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });
        } catch (error) {
            const embed = new EmbedBuilder()
                .setColor(config.colors.error)
                .setTitle('❌ Error Reinstalling Servers')
                .setDescription(`\`\`\`${error.message}\`\`\``)
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });
        }
    }

    async deleteAll(interaction) {
        if (!await this.isMainAdmin(interaction.user.id)) {
            return interaction.reply({ 
                content: '❌ Only main admins can use this command.',
                ephemeral: true 
            });
        }

        await interaction.deferReply({ ephemeral: true });

        try {
            // Get all servers from database
            const servers = await db.getAllServers();
            let deleteCount = 0;

            // Delete each server from Pterodactyl
            for (const server of servers) {
                try {
                    await pterodactyl.deleteServer(server.serverId);
                    deleteCount++;
                } catch (error) {
                    console.error(`Error deleting server ${server.serverId}:`, error.message);
                }
            }

            // Delete all from database
            await db.deleteAllServers();
            await db.deleteAllUsers();

            const embed = new EmbedBuilder()
                .setColor(config.colors.success)
                .setTitle('🗑️ All Data Deleted Successfully')
                .addFields(
                    { name: 'Servers Deleted', value: deleteCount.toString(), inline: true },
                    { name: 'Database Cleared', value: 'All users and servers removed', inline: true }
                )
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });
        } catch (error) {
            const embed = new EmbedBuilder()
                .setColor(config.colors.error)
                .setTitle('❌ Error Deleting All Data')
                .setDescription(`\`\`\`${error.message}\`\`\``)
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });
        }
    }

    async stopAll(interaction) {
        if (!await this.hasPermission(interaction.user.id, 'stop-all')) {
            return interaction.reply({ 
                content: '❌ You do not have permission to use this command.',
                ephemeral: true 
            });
        }

        await interaction.deferReply({ ephemeral: true });

        try {
            const results = await pterodactyl.stopAllServers();
            
            const success = results.filter(r => r.status === 'stopped').length;
            const errors = results.filter(r => r.status === 'error').length;

            const embed = new EmbedBuilder()
                .setColor(success > 0 ? config.colors.success : config.colors.error)
                .setTitle('⏹️ Stop All Servers')
                .addFields(
                    { name: 'Total Servers', value: results.length.toString(), inline: true },
                    { name: 'Successfully Stopped', value: success.toString(), inline: true },
                    { name: 'Errors', value: errors.toString(), inline: true }
                )
                .setTimestamp();

            if (errors > 0) {
                const errorList = results
                    .filter(r => r.status === 'error')
                    .map(r => `• ${r.name}: ${r.error}`)
                    .join('\n');
                
                embed.addFields({ 
                    name: 'Error Details', 
                    value: `\`\`\`${errorList.substring(0, 1000)}\`\`\`` 
                });
            }

            await interaction.editReply({ embeds: [embed] });
        } catch (error) {
            const embed = new EmbedBuilder()
                .setColor(config.colors.error)
                .setTitle('❌ Error Stopping Servers')
                .setDescription(`\`\`\`${error.message}\`\`\``)
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });
        }
    }

    async addAdmin(interaction) {
        // Only main admins can add other admins
        if (!await this.isMainAdmin(interaction.user.id)) {
            return interaction.reply({ 
                content: '❌ Only main admins can add other admins.',
                ephemeral: true 
            });
        }

        const user = interaction.options.getUser('user');
        const permissions = interaction.options.getString('permissions') || 'all';

        await interaction.deferReply({ ephemeral: true });

        try {
            const permissionList = permissions === 'all' 
                ? ['createuser', 'createserver', 'deleteserver', 'deleteuser', 'stop-all']
                : permissions.split(',');

            await db.addAdmin(user.id, user.username, interaction.user.id);

            const embed = new EmbedBuilder()
                .setColor(config.colors.success)
                .setTitle('✅ Admin Added Successfully')
                .addFields(
                    { name: 'Admin Added', value: `<@${user.id}>`, inline: true },
                    { name: 'Added By', value: `<@${interaction.user.id}>`, inline: true },
                    { name: 'Permissions', value: permissionList.join(', '), inline: false }
                )
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });
        } catch (error) {
            const embed = new EmbedBuilder()
                .setColor(config.colors.error)
                .setTitle('❌ Error Adding Admin')
                .setDescription(`\`\`\`${error.message}\`\`\``)
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });
        }
    }
}

module.exports = new AdminCommands();