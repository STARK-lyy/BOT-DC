const { Client, GatewayIntentBits, Collection, ActivityType, EmbedBuilder } = require('discord.js');
const config = require('./config');
const db = require('./utils/database');
const adminCommands = require('./commands/admin');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers
    ]
});

client.commands = new Collection();
client.cooldowns = new Collection();

// Register slash commands
const commands = [
    {
        name: 'createuser',
        description: 'Create a new Pterodactyl user',
        options: [
            {
                name: 'user',
                description: 'Discord user to create account for',
                type: 6, // USER
                required: true
            },
            {
                name: 'email',
                description: 'Email for the Pterodactyl account',
                type: 3, // STRING
                required: true
            },
            {
                name: 'username',
                description: 'Username for Pterodactyl (defaults to Discord username)',
                type: 3,
                required: false
            }
        ]
    },
    {
        name: 'createserver',
        description: 'Create a new server',
        options: [
            {
                name: 'name',
                description: 'Server name',
                type: 3,
                required: true
            },
            {
                name: 'user_id',
                description: 'Pterodactyl user ID',
                type: 3,
                required: true
            },
            {
                name: 'memory',
                description: 'Memory in MB (default: 1024)',
                type: 4, // INTEGER
                required: false
            },
            {
                name: 'disk',
                description: 'Disk space in MB (default: 1024)',
                type: 4,
                required: false
            },
            {
                name: 'cpu',
                description: 'CPU limit in % (default: 100)',
                type: 4,
                required: false
            },
            {
                name: 'node',
                description: 'Node ID (default: 1)',
                type: 3,
                required: false
            },
            {
                name: 'egg',
                description: 'Egg ID (default: 1)',
                type: 3,
                required: false
            }
        ]
    },
    {
        name: 'deleteserver',
        description: 'Delete a server',
        options: [
            {
                name: 'server_id',
                description: 'Server ID to delete',
                type: 3,
                required: true
            }
        ]
    },
    {
        name: 'deleteuser',
        description: 'Delete a user',
        options: [
            {
                name: 'user_id',
                description: 'Pterodactyl user ID to delete',
                type: 3,
                required: true
            }
        ]
    },
    {
        name: 'reinstall-all',
        description: 'Reinstall all servers (Main Admin only)'
    },
    {
        name: 'delete-all',
        description: 'Delete all servers and users (Main Admin only)'
    },
    {
        name: 'stop-all',
        description: 'Stop all running servers'
    },
    {
        name: 'addadmin',
        description: 'Add an admin (Main Admin only)',
        options: [
            {
                name: 'user',
                description: 'User to make admin',
                type: 6,
                required: true
            },
            {
                name: 'permissions',
                description: 'Comma-separated permissions (or "all")',
                type: 3,
                required: false
            }
        ]
    }
];

client.once('ready', async () => {
    console.log(`✅ Logged in as ${client.user.tag}`);
    
    // Connect to database
    try {
        await db.connect();
        console.log('✅ Database connected');
    } catch (error) {
        console.error('❌ Failed to connect to database:', error);
        process.exit(1);
    }

    // Set bot status
    client.user.setPresence({
        activities: [{ name: 'Pterodactyl Servers', type: ActivityType.Watching }],
        status: 'online'
    });

    // Register commands
    try {
        await client.application.commands.set(commands);
        console.log(`✅ Registered ${commands.length} slash commands`);
    } catch (error) {
        console.error('❌ Error registering commands:', error);
    }
});

client.on('interactionCreate', async (interaction) => {
    if (!interaction.isChatInputCommand()) return;

    const { commandName } = interaction;
    
    if (adminCommands.commands[commandName]) {
        await adminCommands.commands[commandName](interaction);
    } else {
        await interaction.reply({
            content: '❌ Unknown command.',
            ephemeral: true
        });
    }
});

// Error handling
client.on('error', (error) => {
    console.error('Discord client error:', error);
});

process.on('unhandledRejection', (error) => {
    console.error('Unhandled promise rejection:', error);
});

// Graceful shutdown
process.on('SIGINT', async () => {
    console.log('Shutting down...');
    await db.disconnect();
    client.destroy();
    process.exit(0);
});

// Login
client.login(config.token).catch(error => {
    console.error('Failed to login:', error);
    process.exit(1);
});