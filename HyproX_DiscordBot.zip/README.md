
Hypro X Discord Bot
==================

Features:
- 100+ Commands
- Prefix + Slash Support
- discord.js v14

Setup:
1. Install Node.js 18+
2. Extract files
3. Run: npm install
4. Put your bot token in index.js
5. Run: node index.js
