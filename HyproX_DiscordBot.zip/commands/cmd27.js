
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd27',
    description: 'Hypro X command 27',
    slash: new SlashCommandBuilder()
        .setName('cmd27')
        .setDescription('Hypro X command 27'),
    prefixRun(message, args) {
        message.reply('Hypro X command 27 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 27 executed (slash)');
    }
};
