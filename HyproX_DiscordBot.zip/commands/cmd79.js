
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd79',
    description: 'Hypro X command 79',
    slash: new SlashCommandBuilder()
        .setName('cmd79')
        .setDescription('Hypro X command 79'),
    prefixRun(message, args) {
        message.reply('Hypro X command 79 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 79 executed (slash)');
    }
};
