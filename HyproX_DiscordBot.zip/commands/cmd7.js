
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd7',
    description: 'Hypro X command 7',
    slash: new SlashCommandBuilder()
        .setName('cmd7')
        .setDescription('Hypro X command 7'),
    prefixRun(message, args) {
        message.reply('Hypro X command 7 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 7 executed (slash)');
    }
};
