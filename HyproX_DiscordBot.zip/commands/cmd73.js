
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd73',
    description: 'Hypro X command 73',
    slash: new SlashCommandBuilder()
        .setName('cmd73')
        .setDescription('Hypro X command 73'),
    prefixRun(message, args) {
        message.reply('Hypro X command 73 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 73 executed (slash)');
    }
};
