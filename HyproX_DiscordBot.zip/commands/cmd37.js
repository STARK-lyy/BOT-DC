
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd37',
    description: 'Hypro X command 37',
    slash: new SlashCommandBuilder()
        .setName('cmd37')
        .setDescription('Hypro X command 37'),
    prefixRun(message, args) {
        message.reply('Hypro X command 37 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 37 executed (slash)');
    }
};
