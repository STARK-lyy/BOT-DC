
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd83',
    description: 'Hypro X command 83',
    slash: new SlashCommandBuilder()
        .setName('cmd83')
        .setDescription('Hypro X command 83'),
    prefixRun(message, args) {
        message.reply('Hypro X command 83 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 83 executed (slash)');
    }
};
