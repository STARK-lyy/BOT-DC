
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd43',
    description: 'Hypro X command 43',
    slash: new SlashCommandBuilder()
        .setName('cmd43')
        .setDescription('Hypro X command 43'),
    prefixRun(message, args) {
        message.reply('Hypro X command 43 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 43 executed (slash)');
    }
};
