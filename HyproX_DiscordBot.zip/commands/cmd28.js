
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd28',
    description: 'Hypro X command 28',
    slash: new SlashCommandBuilder()
        .setName('cmd28')
        .setDescription('Hypro X command 28'),
    prefixRun(message, args) {
        message.reply('Hypro X command 28 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 28 executed (slash)');
    }
};
