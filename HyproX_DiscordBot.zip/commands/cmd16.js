
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd16',
    description: 'Hypro X command 16',
    slash: new SlashCommandBuilder()
        .setName('cmd16')
        .setDescription('Hypro X command 16'),
    prefixRun(message, args) {
        message.reply('Hypro X command 16 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 16 executed (slash)');
    }
};
