
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd4',
    description: 'Hypro X command 4',
    slash: new SlashCommandBuilder()
        .setName('cmd4')
        .setDescription('Hypro X command 4'),
    prefixRun(message, args) {
        message.reply('Hypro X command 4 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 4 executed (slash)');
    }
};
