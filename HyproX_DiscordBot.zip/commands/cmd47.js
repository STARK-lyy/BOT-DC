
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd47',
    description: 'Hypro X command 47',
    slash: new SlashCommandBuilder()
        .setName('cmd47')
        .setDescription('Hypro X command 47'),
    prefixRun(message, args) {
        message.reply('Hypro X command 47 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 47 executed (slash)');
    }
};
