
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd11',
    description: 'Hypro X command 11',
    slash: new SlashCommandBuilder()
        .setName('cmd11')
        .setDescription('Hypro X command 11'),
    prefixRun(message, args) {
        message.reply('Hypro X command 11 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 11 executed (slash)');
    }
};
