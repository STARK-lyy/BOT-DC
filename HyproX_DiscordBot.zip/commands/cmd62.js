
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd62',
    description: 'Hypro X command 62',
    slash: new SlashCommandBuilder()
        .setName('cmd62')
        .setDescription('Hypro X command 62'),
    prefixRun(message, args) {
        message.reply('Hypro X command 62 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 62 executed (slash)');
    }
};
