
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd15',
    description: 'Hypro X command 15',
    slash: new SlashCommandBuilder()
        .setName('cmd15')
        .setDescription('Hypro X command 15'),
    prefixRun(message, args) {
        message.reply('Hypro X command 15 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 15 executed (slash)');
    }
};
