
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd80',
    description: 'Hypro X command 80',
    slash: new SlashCommandBuilder()
        .setName('cmd80')
        .setDescription('Hypro X command 80'),
    prefixRun(message, args) {
        message.reply('Hypro X command 80 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 80 executed (slash)');
    }
};
