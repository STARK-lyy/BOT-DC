
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd34',
    description: 'Hypro X command 34',
    slash: new SlashCommandBuilder()
        .setName('cmd34')
        .setDescription('Hypro X command 34'),
    prefixRun(message, args) {
        message.reply('Hypro X command 34 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 34 executed (slash)');
    }
};
