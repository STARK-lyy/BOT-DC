
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd24',
    description: 'Hypro X command 24',
    slash: new SlashCommandBuilder()
        .setName('cmd24')
        .setDescription('Hypro X command 24'),
    prefixRun(message, args) {
        message.reply('Hypro X command 24 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 24 executed (slash)');
    }
};
