
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd71',
    description: 'Hypro X command 71',
    slash: new SlashCommandBuilder()
        .setName('cmd71')
        .setDescription('Hypro X command 71'),
    prefixRun(message, args) {
        message.reply('Hypro X command 71 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 71 executed (slash)');
    }
};
