
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd76',
    description: 'Hypro X command 76',
    slash: new SlashCommandBuilder()
        .setName('cmd76')
        .setDescription('Hypro X command 76'),
    prefixRun(message, args) {
        message.reply('Hypro X command 76 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 76 executed (slash)');
    }
};
