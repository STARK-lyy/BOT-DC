
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd17',
    description: 'Hypro X command 17',
    slash: new SlashCommandBuilder()
        .setName('cmd17')
        .setDescription('Hypro X command 17'),
    prefixRun(message, args) {
        message.reply('Hypro X command 17 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 17 executed (slash)');
    }
};
