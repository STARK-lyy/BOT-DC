
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd25',
    description: 'Hypro X command 25',
    slash: new SlashCommandBuilder()
        .setName('cmd25')
        .setDescription('Hypro X command 25'),
    prefixRun(message, args) {
        message.reply('Hypro X command 25 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 25 executed (slash)');
    }
};
