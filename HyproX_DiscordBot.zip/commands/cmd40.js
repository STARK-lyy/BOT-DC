
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd40',
    description: 'Hypro X command 40',
    slash: new SlashCommandBuilder()
        .setName('cmd40')
        .setDescription('Hypro X command 40'),
    prefixRun(message, args) {
        message.reply('Hypro X command 40 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 40 executed (slash)');
    }
};
