
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd22',
    description: 'Hypro X command 22',
    slash: new SlashCommandBuilder()
        .setName('cmd22')
        .setDescription('Hypro X command 22'),
    prefixRun(message, args) {
        message.reply('Hypro X command 22 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 22 executed (slash)');
    }
};
