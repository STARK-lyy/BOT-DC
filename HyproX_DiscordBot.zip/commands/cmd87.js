
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd87',
    description: 'Hypro X command 87',
    slash: new SlashCommandBuilder()
        .setName('cmd87')
        .setDescription('Hypro X command 87'),
    prefixRun(message, args) {
        message.reply('Hypro X command 87 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 87 executed (slash)');
    }
};
