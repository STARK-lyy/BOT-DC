
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd26',
    description: 'Hypro X command 26',
    slash: new SlashCommandBuilder()
        .setName('cmd26')
        .setDescription('Hypro X command 26'),
    prefixRun(message, args) {
        message.reply('Hypro X command 26 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 26 executed (slash)');
    }
};
