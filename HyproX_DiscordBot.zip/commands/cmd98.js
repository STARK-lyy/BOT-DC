
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd98',
    description: 'Hypro X command 98',
    slash: new SlashCommandBuilder()
        .setName('cmd98')
        .setDescription('Hypro X command 98'),
    prefixRun(message, args) {
        message.reply('Hypro X command 98 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 98 executed (slash)');
    }
};
