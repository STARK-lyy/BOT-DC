
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd59',
    description: 'Hypro X command 59',
    slash: new SlashCommandBuilder()
        .setName('cmd59')
        .setDescription('Hypro X command 59'),
    prefixRun(message, args) {
        message.reply('Hypro X command 59 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 59 executed (slash)');
    }
};
