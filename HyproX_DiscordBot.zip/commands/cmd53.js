
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd53',
    description: 'Hypro X command 53',
    slash: new SlashCommandBuilder()
        .setName('cmd53')
        .setDescription('Hypro X command 53'),
    prefixRun(message, args) {
        message.reply('Hypro X command 53 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 53 executed (slash)');
    }
};
