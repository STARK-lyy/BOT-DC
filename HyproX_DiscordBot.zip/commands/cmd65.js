
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd65',
    description: 'Hypro X command 65',
    slash: new SlashCommandBuilder()
        .setName('cmd65')
        .setDescription('Hypro X command 65'),
    prefixRun(message, args) {
        message.reply('Hypro X command 65 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 65 executed (slash)');
    }
};
