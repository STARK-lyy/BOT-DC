
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd63',
    description: 'Hypro X command 63',
    slash: new SlashCommandBuilder()
        .setName('cmd63')
        .setDescription('Hypro X command 63'),
    prefixRun(message, args) {
        message.reply('Hypro X command 63 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 63 executed (slash)');
    }
};
