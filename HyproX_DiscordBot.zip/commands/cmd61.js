
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd61',
    description: 'Hypro X command 61',
    slash: new SlashCommandBuilder()
        .setName('cmd61')
        .setDescription('Hypro X command 61'),
    prefixRun(message, args) {
        message.reply('Hypro X command 61 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 61 executed (slash)');
    }
};
