
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd50',
    description: 'Hypro X command 50',
    slash: new SlashCommandBuilder()
        .setName('cmd50')
        .setDescription('Hypro X command 50'),
    prefixRun(message, args) {
        message.reply('Hypro X command 50 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 50 executed (slash)');
    }
};
