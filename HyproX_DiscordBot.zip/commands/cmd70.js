
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd70',
    description: 'Hypro X command 70',
    slash: new SlashCommandBuilder()
        .setName('cmd70')
        .setDescription('Hypro X command 70'),
    prefixRun(message, args) {
        message.reply('Hypro X command 70 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 70 executed (slash)');
    }
};
