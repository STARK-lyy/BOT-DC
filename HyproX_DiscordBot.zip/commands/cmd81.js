
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd81',
    description: 'Hypro X command 81',
    slash: new SlashCommandBuilder()
        .setName('cmd81')
        .setDescription('Hypro X command 81'),
    prefixRun(message, args) {
        message.reply('Hypro X command 81 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 81 executed (slash)');
    }
};
