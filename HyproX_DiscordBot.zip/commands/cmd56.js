
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd56',
    description: 'Hypro X command 56',
    slash: new SlashCommandBuilder()
        .setName('cmd56')
        .setDescription('Hypro X command 56'),
    prefixRun(message, args) {
        message.reply('Hypro X command 56 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 56 executed (slash)');
    }
};
