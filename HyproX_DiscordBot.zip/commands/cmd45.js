
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd45',
    description: 'Hypro X command 45',
    slash: new SlashCommandBuilder()
        .setName('cmd45')
        .setDescription('Hypro X command 45'),
    prefixRun(message, args) {
        message.reply('Hypro X command 45 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 45 executed (slash)');
    }
};
