
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd3',
    description: 'Hypro X command 3',
    slash: new SlashCommandBuilder()
        .setName('cmd3')
        .setDescription('Hypro X command 3'),
    prefixRun(message, args) {
        message.reply('Hypro X command 3 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 3 executed (slash)');
    }
};
