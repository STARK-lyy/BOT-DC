
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd19',
    description: 'Hypro X command 19',
    slash: new SlashCommandBuilder()
        .setName('cmd19')
        .setDescription('Hypro X command 19'),
    prefixRun(message, args) {
        message.reply('Hypro X command 19 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 19 executed (slash)');
    }
};
