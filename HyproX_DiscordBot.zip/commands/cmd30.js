
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd30',
    description: 'Hypro X command 30',
    slash: new SlashCommandBuilder()
        .setName('cmd30')
        .setDescription('Hypro X command 30'),
    prefixRun(message, args) {
        message.reply('Hypro X command 30 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 30 executed (slash)');
    }
};
