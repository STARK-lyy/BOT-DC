
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd96',
    description: 'Hypro X command 96',
    slash: new SlashCommandBuilder()
        .setName('cmd96')
        .setDescription('Hypro X command 96'),
    prefixRun(message, args) {
        message.reply('Hypro X command 96 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 96 executed (slash)');
    }
};
