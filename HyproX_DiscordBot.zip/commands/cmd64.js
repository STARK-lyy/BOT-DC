
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd64',
    description: 'Hypro X command 64',
    slash: new SlashCommandBuilder()
        .setName('cmd64')
        .setDescription('Hypro X command 64'),
    prefixRun(message, args) {
        message.reply('Hypro X command 64 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 64 executed (slash)');
    }
};
