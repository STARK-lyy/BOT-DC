
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd31',
    description: 'Hypro X command 31',
    slash: new SlashCommandBuilder()
        .setName('cmd31')
        .setDescription('Hypro X command 31'),
    prefixRun(message, args) {
        message.reply('Hypro X command 31 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 31 executed (slash)');
    }
};
