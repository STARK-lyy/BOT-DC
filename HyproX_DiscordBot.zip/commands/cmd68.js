
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd68',
    description: 'Hypro X command 68',
    slash: new SlashCommandBuilder()
        .setName('cmd68')
        .setDescription('Hypro X command 68'),
    prefixRun(message, args) {
        message.reply('Hypro X command 68 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 68 executed (slash)');
    }
};
