
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd57',
    description: 'Hypro X command 57',
    slash: new SlashCommandBuilder()
        .setName('cmd57')
        .setDescription('Hypro X command 57'),
    prefixRun(message, args) {
        message.reply('Hypro X command 57 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 57 executed (slash)');
    }
};
