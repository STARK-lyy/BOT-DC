
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd5',
    description: 'Hypro X command 5',
    slash: new SlashCommandBuilder()
        .setName('cmd5')
        .setDescription('Hypro X command 5'),
    prefixRun(message, args) {
        message.reply('Hypro X command 5 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 5 executed (slash)');
    }
};
