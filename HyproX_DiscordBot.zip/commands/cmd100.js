
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd100',
    description: 'Hypro X command 100',
    slash: new SlashCommandBuilder()
        .setName('cmd100')
        .setDescription('Hypro X command 100'),
    prefixRun(message, args) {
        message.reply('Hypro X command 100 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 100 executed (slash)');
    }
};
