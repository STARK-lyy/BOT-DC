
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd32',
    description: 'Hypro X command 32',
    slash: new SlashCommandBuilder()
        .setName('cmd32')
        .setDescription('Hypro X command 32'),
    prefixRun(message, args) {
        message.reply('Hypro X command 32 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 32 executed (slash)');
    }
};
