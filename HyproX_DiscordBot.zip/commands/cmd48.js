
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd48',
    description: 'Hypro X command 48',
    slash: new SlashCommandBuilder()
        .setName('cmd48')
        .setDescription('Hypro X command 48'),
    prefixRun(message, args) {
        message.reply('Hypro X command 48 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 48 executed (slash)');
    }
};
