
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd52',
    description: 'Hypro X command 52',
    slash: new SlashCommandBuilder()
        .setName('cmd52')
        .setDescription('Hypro X command 52'),
    prefixRun(message, args) {
        message.reply('Hypro X command 52 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 52 executed (slash)');
    }
};
