
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd75',
    description: 'Hypro X command 75',
    slash: new SlashCommandBuilder()
        .setName('cmd75')
        .setDescription('Hypro X command 75'),
    prefixRun(message, args) {
        message.reply('Hypro X command 75 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 75 executed (slash)');
    }
};
