
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd89',
    description: 'Hypro X command 89',
    slash: new SlashCommandBuilder()
        .setName('cmd89')
        .setDescription('Hypro X command 89'),
    prefixRun(message, args) {
        message.reply('Hypro X command 89 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 89 executed (slash)');
    }
};
