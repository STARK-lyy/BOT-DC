
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd35',
    description: 'Hypro X command 35',
    slash: new SlashCommandBuilder()
        .setName('cmd35')
        .setDescription('Hypro X command 35'),
    prefixRun(message, args) {
        message.reply('Hypro X command 35 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 35 executed (slash)');
    }
};
