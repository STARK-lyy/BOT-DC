
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd86',
    description: 'Hypro X command 86',
    slash: new SlashCommandBuilder()
        .setName('cmd86')
        .setDescription('Hypro X command 86'),
    prefixRun(message, args) {
        message.reply('Hypro X command 86 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 86 executed (slash)');
    }
};
