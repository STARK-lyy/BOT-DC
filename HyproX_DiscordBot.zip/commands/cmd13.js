
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd13',
    description: 'Hypro X command 13',
    slash: new SlashCommandBuilder()
        .setName('cmd13')
        .setDescription('Hypro X command 13'),
    prefixRun(message, args) {
        message.reply('Hypro X command 13 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 13 executed (slash)');
    }
};
