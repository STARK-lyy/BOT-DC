
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd66',
    description: 'Hypro X command 66',
    slash: new SlashCommandBuilder()
        .setName('cmd66')
        .setDescription('Hypro X command 66'),
    prefixRun(message, args) {
        message.reply('Hypro X command 66 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 66 executed (slash)');
    }
};
