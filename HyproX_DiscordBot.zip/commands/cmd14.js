
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd14',
    description: 'Hypro X command 14',
    slash: new SlashCommandBuilder()
        .setName('cmd14')
        .setDescription('Hypro X command 14'),
    prefixRun(message, args) {
        message.reply('Hypro X command 14 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 14 executed (slash)');
    }
};
