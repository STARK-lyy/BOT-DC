
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd60',
    description: 'Hypro X command 60',
    slash: new SlashCommandBuilder()
        .setName('cmd60')
        .setDescription('Hypro X command 60'),
    prefixRun(message, args) {
        message.reply('Hypro X command 60 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 60 executed (slash)');
    }
};
