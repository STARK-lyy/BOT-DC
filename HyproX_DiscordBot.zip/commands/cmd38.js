
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd38',
    description: 'Hypro X command 38',
    slash: new SlashCommandBuilder()
        .setName('cmd38')
        .setDescription('Hypro X command 38'),
    prefixRun(message, args) {
        message.reply('Hypro X command 38 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 38 executed (slash)');
    }
};
