
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd95',
    description: 'Hypro X command 95',
    slash: new SlashCommandBuilder()
        .setName('cmd95')
        .setDescription('Hypro X command 95'),
    prefixRun(message, args) {
        message.reply('Hypro X command 95 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 95 executed (slash)');
    }
};
