
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd67',
    description: 'Hypro X command 67',
    slash: new SlashCommandBuilder()
        .setName('cmd67')
        .setDescription('Hypro X command 67'),
    prefixRun(message, args) {
        message.reply('Hypro X command 67 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 67 executed (slash)');
    }
};
