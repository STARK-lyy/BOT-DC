
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd8',
    description: 'Hypro X command 8',
    slash: new SlashCommandBuilder()
        .setName('cmd8')
        .setDescription('Hypro X command 8'),
    prefixRun(message, args) {
        message.reply('Hypro X command 8 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 8 executed (slash)');
    }
};
