
const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    name: 'cmd39',
    description: 'Hypro X command 39',
    slash: new SlashCommandBuilder()
        .setName('cmd39')
        .setDescription('Hypro X command 39'),
    prefixRun(message, args) {
        message.reply('Hypro X command 39 executed (prefix)');
    },
    slashRun(interaction) {
        interaction.reply('Hypro X command 39 executed (slash)');
    }
};
